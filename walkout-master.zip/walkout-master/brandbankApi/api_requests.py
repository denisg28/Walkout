import os
import time
import urllib
from pathlib import Path
import multiprocessing
import zeep
import re

from utils.ProgressBar import ProgressBar

POOL_SIZE = 60

DEBUG_REQUEST_RESPONSE_VERBOSE_PRINT = False
PRODUCTS_DIR = os.path.join(str(Path.home()), "Desktop", "products")
# PRODUCTS_DIR = "/media/walkout02/DATA/products3"


def enable_requests_and_responses_verbose_print():
    import logging.config
    logging.config.dictConfig({
        'version': 1,
        'formatters': {
            'verbose': {
                'format': '%(name)s: %(message)s'
            }
        },
        'handlers': {
            'console': {
                'level': 'DEBUG',
                'class': 'logging.StreamHandler',
                'formatter': 'verbose',
            },
        },
        'loggers': {
            'zeep.transports': {
                'level': 'DEBUG',
                'propagate': True,
                'handlers': ['console'],
            },
        }
    })


if DEBUG_REQUEST_RESPONSE_VERBOSE_PRINT:
    enable_requests_and_responses_verbose_print()

extract_wsdl = 'https://api.brandbank.com/svc/feed/extractdata.asmx?WSDL'
devUserGuid = "{8910089F-585A-4962-A0E9-3D4F2CCBFF39}"
liveUserGuid = "{B36A240B-9CE6-4C69-831B-4D957A045142}"
brandbank_extract_data_endpoint = 'https://api.brandbank.com/svc/feed/extractdata.asmx'
client = zeep.Client(wsdl=extract_wsdl)

# header = client.get_type('ns0:ExternalCallerHeader')
# # header(ExternalCallerId= userGuid)
#
# header_ser = zeep.xsd.AnyObject(
#     header, header(ExternalCallerId= userGuid))


# response_element = client.get_element("ns0:GetUnsentProductDataResponse")

# res = client.service.GetUnsentProductData(_soapheaders={'ExternalCallerHeader': {'ExternalCallerId': userGuid}})

should_break = False
msgGuidAnswer = 'd69fcba2-91d2-4224-8957-aea9d459068d'
userGuid = liveUserGuid

print("Using userGuid={}".format(userGuid))

i=1


def parse_update_types_and_print():
    global should_break
    update_types = re.split("UpdateType=\"", str(res1.content))
    delete_types_counter = 0
    other_types_counter = 0
    for type in update_types:
        split = re.split("\"", type)
        if (split[0] == "b'<?xml version=" or split[0] == "Delete"):
            delete_types_counter += 1
        else:
            # print(split[0])
            other_types_counter += 1
    print("{} url length, {} other types, {} 'Delete' types".format(urls.__len__(), other_types_counter,
                                                                    delete_types_counter))


def handle_product_using_multiprocessing():
    images_for_download = []
    for product in products:
        product_urls = re.findall("<Url>.[^<]*</Url>", product)
        if product_urls.__len__() > 0:
            images_for_download += handle_single_product(product)
    print("Starting to download {} images".format(images_for_download.__len__()))
    with multiprocessing.Pool(processes=POOL_SIZE) as pool:
        results = pool.map(download_single_image, [args for args in images_for_download])


def handle_single_product(product):
    results = []
    bb_pvid = re.split("<Code Scheme=\"BRANDBANK:PVID\">(.*)</Code>", product)[1]
    bb_description = re.split("<DiagnosticDescription Code=.*?>(.*)</DiagnosticDescription>", product)[1]
    bb_description = bb_description.replace("/", " ")
    file_name = "{}:{}.xml".format(bb_pvid, bb_description)
    dir_name = "{}:{}".format(bb_pvid, bb_description)
    # save product:
    dir_path = os.path.join(PRODUCTS_DIR, dir_name)
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    file_path = os.path.join(PRODUCTS_DIR, dir_name, file_name)
    with open(file_path, "w") as text_file:
        print(product, file=text_file)
    product_images = re.findall("<Image .*?</Image>", product)
    for image in product_images:
        shot_type_id = re.split(".*ShotTypeId=\"(.*?)\".*", image)[1]
        shot_url = re.split("<Url>(.*?)<.Url>", image)[1]
        image_full_name = os.path.join(dir_path, "{}:{}".format(shot_type_id, bb_pvid))

        results.append((image_full_name, shot_url, bb_pvid, dir_path, shot_type_id))

    return results


def download_single_image(args):
    (image_full_name, shot_url, bb_pvid, dir_path, shot_type_id) = args
    try:
        urllib.request.urlretrieve(shot_url, image_full_name)
    except urllib.error.HTTPError as e:
        image_full_name = os.path.join(dir_path, "Error-{}-{}:{}".format(e.code, shot_type_id, bb_pvid))
        with open(image_full_name, "w") as file:
            print(shot_url, file=file)
    # finally:
    #     progress()


while (not should_break):

    ts = time.time()
    print("Iteration {} started, {}".format(i, time.ctime()))

    ack =client.service.AcknowledgeMessage(msgGuidAnswer, _soapheaders={'ExternalCallerHeader': {'ExternalCallerId': userGuid}})


    with client.settings(raw_response=True):
        res1=client.service.GetUnsentProductData(_soapheaders={'ExternalCallerHeader': {'ExternalCallerId': userGuid}})

    # import xml.etree.ElementTree as et

    # parser = et.XMLParser(encoding="utf-8")
    # tree = et.fromstring(res1.content, parser=parser)
    # string = et.parse('/home/walkout02/PycharmProjects/walkout/brandbankApi/Output.xml', parser=parser)
    # root = tree.getroot()

    # with open("Output.xml", "w") as text_file:
    #     print(res1.content, file=text_file)

    message = re.findall("<Message Id.[^>]*>", str(res1.content))
    msgGuidAnswer = re.split("<Message Id=\"(.*)\" DateTime", message[0])[1]
    print("msgGuidAnswer="+msgGuidAnswer)
    urls = re.findall("<Url>.[^<]*</Url>", str(res1.content))


    products = re.findall("<Product .*?</Product>", str(res1.content))

    parse_update_types_and_print()

    # progress = ProgressBar(urls.__len__(), fmt=ProgressBar.FULL)

    handle_product_using_multiprocessing()

    # progress.done()

    te = time.time()
    print("Iteration {} ended. took {:.3f} [sec] \n".format(i, te-ts))
    i += 1




# client.service.AcknowledgeMessage(msgGuidAnswer, _soapheaders={'ExternalCallerHeader': header_ser})
# client.service.GetUnsentProductData(_soapheaders={'ExternalCallerHeader': header})
# client.service.GetUnsentProductData(_soapheaders=[header_value])

# client.service.AcknowledgeMessage(msgGuidAnswer, _soapheaders= header)
