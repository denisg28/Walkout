import socket
import json
import time
import random
import Logger

CART_STATUS_OK = False
CART_STATUS_ERROR = True


class CartTest:
    def __init__(self, logger):
        self.logger = logger
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect('/tmp/unixSocket')
        self.stream_socket = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        self.stream_socket.connect('/tmp/unixSocketStream')

    def send_one_frame(self):
        self.logger.log('SENDING FRAME TO CANCEL LOADER')
        data = 'iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAQAAAAAYLlVAAAC6npUWHRSYXcgcHJvZmlsZSB0eXBlIGV4aWYAAHja7ZZdkuwmDIXfWUWWgCSExHIwP1XZQZafA7Z7umcmyb1170uq2pQNFliSzyfTHcZff87wBw4qOYak5rnkHHGkkgpXDDyeR9lXimlf95GuKdy/2MNjgmES9HLeWr3WV9j144E7Bh2v9uDXDPvl6Jq4HcqKzBj05yRh59NOVyahjHOQi9tzqgeffbtT9o/zuJzujOJ5H54NyaBSVwQS5iEkcV/TmYGcZ8UpuLIUrCO0Kkk47O7OBIK8vN7dx/gs0IvI9yh8Vv8x+iQ+18sun7TMl0YYfDtB+r34W+KnwPLIiF8njG9XX0Wes/uc43y7mjIUzVdFbbHpdoOFBySX/VhGM5yKse1W0DzW2IC8xxYPtEaFGFRmoESdKk0au2/UkGLiwUiNmRvLtrkYF26yOKXVaLJJkS4Ofo1HAErAe+RCO27Z8Ro5InfCUiY4Izzyjy382+TPtDBnWxJR9IdWyItXXSONRW5dsQpAaF7cdAt8twt/fKoflCoI6pbZ8YI1HqeLQ+mjtmRzFqxT9OcnRMH65QASIbYiGZR9ophJlDKhHtiIoKMDUEXmLIkPECBV7kiSk0jmYOy8YuMZo72WlTMvM/YmgFDJYmBTpAJWSor6seSooaqiSVWzmnrQojVLTllzzpbXJldNLJlaNjO3YtXFk6tnN3cvXgsXwR6oJRcrXkqplUNFoApfFesrLAcfcqRDj3zY4Uc5akP5tNS05WbNW2m1c5eObaLnbt176XVQGNgpRho68rDho4w6UWtTZpo687Tps8z6oHZR/dJ+ghpd1HiTWuvsQQ3WYHa7oLWd6GIGYpwIxG0RQEHzYhadUuJFbjGLhfFRKCNJXWxCp0UMCNMg1kkPdh/kfohbUP8hbvxf5MJC9zvIBaD7yu0ban39zrVN7PwKl6ZR8PW1WdlrwO9ZXINf7d+O3o7ejt6O3o7ejt6O/veOBH8dSvgbIrWc/IxOLaoAAAEkaUNDUElDQyBwcm9maWxlAAAokZ2QsUrDUBSGv7SiRXRSHEQhg4tDwcVMLlUhCBVirGB1SpMUi0kMSUrxDXwTfZgOguAT+AQKzv43OjiYxQuH/+Nwzv/fe6FlJ2FaLuxBmlWF6/eGl8Mre+mNNtt02MUKwjLveV6fxvP5imX0pWu8muf+PItRXIbSuSoL86IC60DszKrcsIr124F/JH4Q21GaReIn8U6URobNrp8m0/DH09xmJc4uzk1ftYXLCad42IyYMiGhoivN1DnGYV/qUhBwT0koTYjVm2mm4kZUysnlUDQQ6TYNeZt1nqeUkTwm8jIJd6TyNHmY//1e+zirN62NeR4UQd1qq1rjMbw/wuoQ1p5h+bohq/P7bQ0zTj3zzzd+AcsHUFYTuemHAAAAAmJLR0QAAKqNIzIAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAAHdElNRQfkAx0IKi2AdcdDAAAE6UlEQVRo3r2Zf0xVZRjHP/eAGIMQhUDUOShBCRIVYrbZ78UKh2PLHDFZlkGbbkXTzGqwNnKFxmprlTM3mVv8UX8UcQtCMzecNMwfa6aCpNRS6Ad2FSpJfvTH5cd9n/fce8893OP3n3uf57znfb7nfc9znud9HlcltlHEi+QDHdTxpd1JIlbavbOGD0kjiijSKMXg8M0l8Ch7FPl+2vnJzkSGzed/QdPY3Eu7BFZomtybSyBG08TamyjS75UZrGYRvbi5at9RmE0RyXTTxHBoBObxxfiiXqaIEzbNr6KROQAcZw2XrW9BFu2TezqPRmbaMh/NJ+PmIZd2sqwSuJcjLPSRF5Bvi8BKUnykhbSxygqBZbiJF7o4WwRitffBzdJgBNL4SjN3g3ZbBI5qL94sWkgNRCCWZmXZvKjlii0C/dRquhSa1ZVRCbzHYu2WN6i27YRV1Gi6Jbzrj8A6NojBw5RTxZhtAmNUU6FtxEbWmhFIZLd2+0b2Ml18RLn2CLsn3dOHQDWzxbCX2U84UM+rQpNA1cRf13gQu4MzRCmDPmVdgEkHtWjwj0l8mEIDTwrPyuK87wrUCPM9lBNObOJnEWle992CFN/XAoDyaYUgHR4qhGYtc6cIVDBDuejmIOFGK82KHOVdYwOIEMs9ynacwDbhDRUYXgL5zBdcf3SEwGkOKPIC8rwEHhMD38cpfCDkQi+BQkX5p9ircMItospqMIhhudiAEccIjPC1SG1jDO4UAcm559dnN8g0yBZDvneUwHEhZxtkKoohuh0l0MWQImcaJCiKbn/psxYpg2vMMCwOcAmGSMA8lrMdiT8s3vmXmqRJAtcsTnPQgsYcaoyJM0QUHLI4zVsMKvIAb1q88z9FmmmIiaye8Lop9vmo9FPMBVvJ+mCkIGD9BPAN6TxNHnCM+hDyZrHlkeKlSA3Bpa5QZ8MR09RX0hBukTSVLjqCOdymbqXBOTFkuaMEZGGj0+CsUD3oKAE5+1mDC1xSVI84SqBAkX7logF8qyjzTY5n4UI6ecKTMLw/CsocI7BBc2VclTCLXqIV90plwAHzMfSQ6CNfJwWPAVylSbjKc448/2bFPHyOZ+JcUC+GvkZy2M0n84p2Zpw8mLTwg3Ipnl1hJ/C2KPyconWKwJgWy8ooDav5J1gvNDu8KczE6TiCk9wlMoO76QqT+QyOiSB0ilxGfU/HI2wSSVUcLSb1IjtIwi3Mj7HZa963QHFEK0ek0UxSGMy3ki50+zhqViOq5KIYmEM7i6ZlPpU2coTuF14yL1J5KBEJE9xOuzi6hYKH+Y4MobtBiW/6op6KOtiiTZKImzobxfhY3uGAyffkebXsKVs2HdyiVXRd3EMZfZyxXLCLoJRGCnBpV3awUwzVekaHmG/SD5nF45TwL+e1TdKfvIwGyk2zyz36CrtMWj0udplshRd/8xnNHKLP5NpcHqKQYr/Vsp1s19fQ5afXtJXagO2cHrroZIBrwK3EsZiMgAntCFvVEm0wAvAADWH6EMHvlHm//Dr8P+VhVoSpVuBmqT/zgbtmfRSyRhQYQ8UlnqKI3/wPCNa2ayKLbYEmCIBetpARrN7sstTwjOYZnmVZCMZPsJd9XA8+0BVCxzWb9RSQE3DVRjlJKx9brzS6Qm75JnAfWSwhgwTiiQUG8dBPJ+c4TVuo7Z3/ARicElnZoFHQAAAAAElFTkSuQmCC'
        self.stream_socket.sendall(json.dumps(data).encode('utf-8'))

    def send(self, data):
        self.sock.sendall(json.dumps(data).encode('utf-8') + b'\n')

    def clear_list(self):
        self.logger.log('SEND CLEAR LIST')
        json_data = {'cmd': 'clear_list'}
        self.send(json_data)

    def insert_item(self, id, price, event_type, id2='22113344'):
        time.sleep(0.8)
        self.logger.log('INSERT ITEM-> {} PRICE-> {}'.format(id, price))
        item = {'cmd': 'insert_item', 'payload': {
            'top_products': {
                id: {'full_name': '{} full name'.format(id), 'score': 10, 'price': price},
                id2: {'full_name': '{} full name'.format(id2), 'score': 5, 'price': price},
                '7290102398065': {'full_name': '7290102398065 full name', 'score': 0.22, 'price': 0.99},
                '4901330740672': {'full_name': '4901330740672 full name', 'score': 2, 'price': 0.99},
                '8711000371251': {'full_name': '8711000371251 full name', 'score': 0.52, 'price': 0.99}},
            'event_ID': random.randrange(10000), 'itemCount': 1, 'event_type': event_type}}
        self.send(item)
        time.sleep(1)

    def make_cart_led_red(self, err):
        self.logger.log('SEND RED CART MSG: {}'.format(err))
        json_data = {'cmd': 'cart_status', 'payload': {
            'status': CART_STATUS_ERROR, 'message': err}}
        self.send(json_data)

    def make_cart_led_green(self):
        self.logger.log('SEND GREEN CART')
        json_data = {'cmd': 'cart_status', 'payload': {
            'status': CART_STATUS_OK, 'message': ''}}
        self.send(json_data)

    def remove_item(self, id, price, event_type, id2='22113344'):
        time.sleep(0.8)
        self.logger.log('REMOVE ITEM-> {} PRICE-> {}'.format(id, price))
        item = {'cmd': 'remove_item', 'payload': {
            'top_products': {
                id: {'full_name': '{} full name'.format(id), 'score': 10, 'price': price},
                id2: {'full_name': '{} full name'.format(id2), 'score': 5, 'price': price},
                '7290102398065': {'full_name': '7290102398065 full name', 'score': 0.22, 'price': 0.99},
                '4901330740672': {'full_name': '4901330740672 full name', 'score': 2, 'price': 0.99},
                '8711000371251': {'full_name': '8711000371251 full name', 'score': 0.52, 'price': 0.99}},
            'event_ID': random.randrange(10000), 'itemCount': -1, 'event_type': event_type}}
        self.send(item)
        time.sleep(0.3)

    def __del__(self):
        try:
            self.stream_socket.shutdown(socket.SHUT_WR)
            self.sock.shutdown(socket.SHUT_WR)
        except:
            pass
