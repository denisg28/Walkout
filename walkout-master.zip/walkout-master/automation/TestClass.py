import re
import json
import sh
import os
import datetime
from time import gmtime, strftime
from colorama import Fore
import time
import boto3
import traceback
import Logger
import sys
import shutil
from pathlib import Path
import CartConnector
import DatabaseConnector
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains

FAIL_PASS = 'innovation1!22'
SUCCESS_PASS = 'innovation1'
FPS = 10
IN_EVENTS = 5
OUT_EVENTS = 5
SIMPLE_MODE = '1946'
ADVANCED_MODE = '551946'


class Tester:
    def __init__(self, logger, db_path):
        self.logger = logger
        Path(str(Path.home()) + '/dataset').mkdir(exist_ok=True)
        self.record_path=str(Path.home()) + '/screenshots'
        Path(self.record_path).mkdir(exist_ok=True)
        self.MOVIE_PATH = str(Path.home()) + '/dataset'
        self.database = DatabaseConnector.SqliteConnector(db_path)
        self.cart = CartConnector.CartTest(logger)
        self.shop_mod_start = ''
        self.shop_mod_end = ''
        self.errors = []
        self.today = str(datetime.date.today())
        options = webdriver.ChromeOptions()
        options.add_argument("--window-size=1024,735")
        # options.add_argument('--auto-open-devtools-for-tabs')
        if len(sys.argv) == 2:
            # options.binary_location = r'/snap/bin/chromium'
            options.add_argument('--disable-extensions')
            options.add_argument('--headless')
            options.add_argument('--disable-gpu')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument("--remote-debugging-port=9222")
        self.browser = webdriver.Chrome(options=options)
        self.browser.get("http://localhost:3001")
        self.wait = WebDriverWait(self.browser, 2000)

    def close(self):
        self.browser.close()

    def check_loader(self):
        try:
            self.wait.until(EC.invisibility_of_element_located(
                (By.ID, "loader_page")))
        except:
            pass

    def wait_for_id(self, id):
        self.wait.until(EC.element_to_be_clickable(
            (By.ID, id)))
        return self.browser.find_element_by_id(id)

    def wait_for_tag_name(self, id):
        self.wait.until(EC.visibility_of_element_located(
            (By.TAG_NAME, id)))
        return self.browser.find_element_by_tag_name(id)

    def wait_for_class_name(self, class_name):
        self.wait.until(EC.presence_of_element_located(
            (By.CLASS_NAME, class_name)))
        return self.browser.find_element_by_class_name(class_name)

    def login(self, password):
        retailer_logo = self.wait_for_id('retailer-logo')
        retailer_logo.click()
        self.wait_for_class_name("swal2-container")
        swal = self.wait_for_class_name('swal2-confirm')
        swal.send_keys(Keys.ENTER)
        password_elem = self.wait_for_tag_name('input')
        password_elem.send_keys(password)
        password_elem.send_keys(Keys.ENTER)
        # here
        time.sleep(1)
        self.check_SW_updates_swal()
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))

    def login_webapp(self):
        """ try to login to webapp """
        self.logger.log('----- CHECK LOGIN -----')
        checker = []
        logged = False
        time.sleep(1)
        self.check_loader()
        try:
            self.login(FAIL_PASS)
        except:
            logged = True
        try:
            self.browser.find_element_by_id('shop_btn')
            checker.append(True if logged else False)
        except:
            checker.append(True)
            self.logger.log(
                '##### LOGIN WITH INCORRECT PASSWORD {} PASS #####'.format(FAIL_PASS))
        try:
            self.login(SUCCESS_PASS)
        except:
            pass
        try:
            self.browser.find_element_by_id('shop_btn')
            self.logger.log(
                '##### LOGIN WITH PASSWORD {} PASS #####'.format(SUCCESS_PASS))
            checker.append(True)
        except:
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        return all(checker)

    def check_insert_and_remove(self, products, prices, rm_one_more=False, insert_one_more=False):
        self.logger.log('----- CHECK INSERT AND REMOVE -----')
        checker = []
        excepted_prices = 0
        excepted_counts = 0
        excepted_sum = 0
        excepted_total = 0
        self.cart.insert_item(products[0], prices[0], 1)
        # self.wait_for_id('confirmquantity').click()
        excepted_sum += prices[0]
        excepted_total += 1
        excepted_prices += prices[0]
        excepted_counts += 1
        self.cart.insert_item(products[1], prices[1], 1)
        # self.wait_for_id('confirmquantity').click()
        excepted_sum += prices[1]
        excepted_total += 1
        excepted_prices += prices[1]
        excepted_counts += 1
        self.cart.remove_item(products[0], prices[0], 1)
        # self.wait_for_id('confirmquantity').click()
        excepted_sum -= prices[0]
        excepted_total -= 1
        excepted_prices -= prices[0]
        excepted_counts -= 1
        self.cart.insert_item(products[2], prices[2], 1)
        # self.wait_for_id('confirmquantity').click()
        excepted_sum += prices[2]
        excepted_total += 1
        excepted_prices += prices[2]
        excepted_counts += 1
        self.cart.remove_item(products[1], prices[1], 1)
        # self.wait_for_id('confirmquantity').click()
        self.cart.remove_item(products[2], prices[2], 1)
        # self.wait_for_id('confirmquantity').click()
        excepted_sum = 0
        excepted_total = 0
        excepted_prices = 0
        excepted_counts = 0
        if rm_one_more:
            self.cart.remove_item(products[2], prices[2], 1)
            # self.wait_for_id('confirmquantity').click()
            excepted_sum = 0
            excepted_total = 0
            excepted_prices = 0
            excepted_counts = 0
        if insert_one_more:
            self.cart.insert_item(products[2], prices[2], 1)
            # self.wait_for_id('confirmquantity').click()
            excepted_sum += prices[2]
            excepted_total += 1
            excepted_prices += prices[2]
            excepted_counts += 1

        try:
            self.logger.log('###### FINISH MINI TEST ######')
            self.logger.log(
                'TOTAL-> {} SUM-> {}'.format(excepted_total, excepted_sum))
            checker.append(self.check_present_item(
                excepted_counts, excepted_prices, 'insert_and_remove'))
            checker.append(True)
        except:
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        self.cart.clear_list()
        time.sleep(0.5)
        return all(checker)

    def check_cart_icon(self):
        self.logger.log('----- CHECK CART ICONS -----')
        self.errors.append('#### ERRORS_STATE ####')
        if self.browser.current_url.split('/')[-1] == '':
            self.check_loader()
            self.wait_for_id('shop_btn')
            self.browser.get("http://localhost:3001/shop")
            time.sleep(0.5)
        self.cart.send_one_frame()
        self.check_loader()
        checker = []
        ERR_MSG = 'Something does not seem right, Please go through a cashier on your way out'
        self.cart.make_cart_led_red('default')
        time.sleep(1)
        cart_image = self.wait_for_id(
            "cart_status_image").get_attribute("alt")
        if cart_image == "cart_error":
            checker.append(True)
        else:
            self.errors.append('cart image doesnt change to error')
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        cart_msg = self.wait_for_id("err_msg_cart")
        if cart_msg.text == ERR_MSG:
            checker.append(True)
        else:
            self.errors.append('error text != {}'.format(ERR_MSG))
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        self.cart.make_cart_led_green()
        time.sleep(1)
        cart_image = self.wait_for_id(
            "cart_status_image").get_attribute("alt")
        try:
            self.browser.find_element_by_id("err_msg_cart")
            self.errors.append('not change to error')
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        except:
            checker.append(True)
        if cart_image == "cart_ok":
            checker.append(True)
        else:
            self.errors.append('cart image != green')
            checker.append(False)
        return all(checker)

    def check_cart(self):
        """ for test product in cart """
        self.logger.log('----- CHECK CART -----')
        self.errors.append('#### CART ####')
        time.sleep(1)
        self.check_loader()
        self.wait_for_id('shop_btn')
        self.browser.get("http://localhost:3001/shop")
        time.sleep(1)
        checker = []
        if self.browser.current_url.split('/')[-1] == '':
            checker.append(False)
        self.cart.clear_list()
        self.cart.send_one_frame()
        self.check_loader()
        checker.append(
            self.check_insert_and_remove(['22115461', '22125118', '4061458003391'], [1.29, 2.69, 2.79]))
        checker.append(self.check_insert_and_remove(['22115461', '22125118', '4061458003391'], [1.29, 2.69, 2.79],
                                                    rm_one_more=True))
        checker.append(self.check_insert_and_remove(['22115461', '22125118', '4061458003391'], [1.29, 2.69, 2.79],
                                                    insert_one_more=True))
        self.cart.clear_list()
        return all(checker)

    def check_present_item(self, excepted_counts, excepted_prices, fromTest):
        for class_name in ['item_name', 'item_price', 'item_count']:
            self.wait_for_class_name(class_name)
        data = []
        prices = 0
        counts = 0
        for elm in self.browser.find_elements_by_css_selector(".item_name,.item_price,.item_count"):
            data.append(elm.text)
        data = [data[i:i + 3] for i in range(0, len(data), 3)]
        for item in data:
            counts += (int(item[1]))
            matches = re.findall("[+-]?\d+\.\d+", item[2])
            prices += (float(matches[0]))
        prices = float("{:.2f}".format(prices))
        if excepted_counts == counts and excepted_prices == prices:
            return True
        else:
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            self.errors.append('in {}: count: {} except: {}, prices: {} except: {}'.format(
                fromTest, counts, excepted_counts, prices, excepted_prices))
            return False

    def check_low_confidence_modal(self, products, prices):
        # depreceted test (we dont have low confidance mod)
        self.logger.log('----- LOW CONFIDENCE MODAL -----')
        self.errors.append('#### LOW CONFIDENCE MODAL ####')
        cururl = self.browser.current_url.split('/')[-1]
        names_list = ['Schoko-Waffeln', 'bio', 'Expressi']
        if cururl == '':
            self.check_loader()
            self.wait_for_id('shop_btn')
            self.browser.get("http://localhost:3001/shop")
            time.sleep(0.5)
        checker = []
        self.cart.send_one_frame()
        self.check_loader()
        self.cart.clear_list()
        time.sleep(0.5)
        self.cart.insert_item(products[0], prices[0], 2, products[1])
        items = self.picker()
        if len(items) == 0:
            self.errors.append('no items in modal (user interaction popup)')
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        for i, item in enumerate(items):
            name = item.text.split(" ")[0]
            if name == names_list[i]:
                checker.append(True)
            else:
                filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
                self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
                self.errors.append(
                    'name: {}, except: {}'.format(name, names_list[i]))
                checker.append(False)
        items[0].click()
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))
        self.cart.remove_item(products[0], prices[0], 2, products[1])
        items = self.picker()
        if len(items) == 0:
            checker.append(False)
        for i, item in enumerate(items):
            name = item.text.split(" ")[0]
            if name == names_list[i]:
                checker.append(True)
            else:
                filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
                self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
                self.errors.append(
                    'name: {}, except: {}'.format(name, names_list[i]))
                checker.append(False)
        items[1].click()
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))
        checker.append(self.check_present_item(
            [names_list[0], names_list[1]], [1, -1], [prices[0], prices[1]], 'item_picker'))
        self.cart.clear_list()
        sidebar = self.wait_for_id('openSideBar')
        sidebar.click()
        try:
            password_elem = self.wait_for_tag_name('input')
            password_elem.send_keys(SIMPLE_MODE)
            password_elem.send_keys(Keys.ENTER)
            time.sleep(0.5)
        except:
            pass
        self.browser.get("http://localhost:3001/")
        time.sleep(0.5)

        return all(checker)

    def picker(self):
        items = []
        try:
            self.wait_for_id('cart_picker_item')
            for i in range(2):
                items.append(self.wait_for_id(
                    'picker_{}'.format(i)))
        except:
            pass
        return items

    def check_images(self):
        self.logger.log('----- CHECK ALL PRODUCTS IMAGES -----')
        self.errors.append('#### PRODUCTS ####')
        cururl = self.browser.current_url.split('/')[-1]
        if cururl == '':
            self.check_loader()

            self.wait_for_id('shop_btn')
            self.browser.get("http://localhost:3001/shop")
            time.sleep(0.5)
        self.cart.send_one_frame()
        self.check_loader()
        self.cart.clear_list()
        time.sleep(0.5)
        products = self.database.get_products()
        if len(products) != 0:
            count = len(products) if len(products) < 30 else 30
            for item in range(count):
                self.cart.insert_item(products[item], 1, 1)
            # self.wait_for_id('confirmquantity').click()
            for class_name in ['cartImg', 'item_name']:
                self.wait_for_class_name(class_name)
            data = []
            ids = []
            for elm in self.browser.find_elements_by_css_selector(".item_name"):
                ids.append(elm.text.split(' ')[0])
            for elm in self.browser.find_elements_by_css_selector(".cartImg"):
                data.append(elm.get_attribute("alt"))
            self.cart.clear_list()
            for i in range(len(data)):
                if data[i] == 'unknown':
                    self.errors.append(
                        'IMAGE FOR {} IS MISSING'.format(ids[i]))
                    self.logger.log(
                        'IMAGE FOR {} IS MISSING'.format(ids[i]))
            return not any(item == 'unknown' for item in data)
        else:
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            return False

    def check_exit_from_shop_and_reenter(self):
        self.logger.log('----- CHECK EXIT AND ENTER SHOP MOD -----')
        self.errors.append('#### REENTER ####')
        cururl = self.browser.current_url.split('/')[-1]
        checker = []
        if cururl != '':
            self.browser.get("http://localhost:3001/")
            time.sleep(1)
            self.check_loader()
            self.login(SUCCESS_PASS)
            # time.sleep(3)
            # self.check_SW_updates_swal()
        try:
            self.enter_shop_mode()
        except Exception as e:
            self.errors.append('not get in shop mode' + str(e))
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        try:
            self.browser.find_element_by_id('shop_btn')
            checker.append(True)
        except:
            self.errors.append('not in home page')
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        return all(checker)

    def enter_shop_mode(self):
        # time.sleep(3)
        # self.check_SW_updates_swal()
        time.sleep(1)
        shop_btn = self.wait_for_id('shop_btn')
        shop_btn.click()
        time.sleep(0.5)
        self.check_loader()
        sidebar = self.wait_for_id('openSideBar')
        sidebar.click()
        password_elem = self.wait_for_tag_name('input')
        password_elem.send_keys(SIMPLE_MODE)
        password_elem.send_keys(Keys.ENTER)
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))
        quit = self.wait_for_id('quit')
        quit.send_keys(Keys.ENTER)
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))
        time.sleep(0.5)
        self.check_loader()

    def check_refresh(self, products, prices):
        self.logger.log('----- CHECK REFRESH PAGE -----')
        self.errors.append('#### REFRESH ####')
        try:
            self.browser.find_element_by_id('shop_btn')
            time.sleep(1)
            self.check_loader()
            self.browser.get("http://localhost:3001/shop")
            time.sleep(1)
        except:
            pass
        self.cart.send_one_frame()
        self.check_loader()
        for item in products:
            self.cart.insert_item(item, 0, 1)
            # self.wait_for_id('confirmquantity').click()
        self.logger.log('----- REFRESHING -----')
        self.browser.refresh()
        time.sleep(1)
        self.cart.send_one_frame()
        time.sleep(1)
        self.check_loader()
        time.sleep(8)
        prices_ = sum(prices)
        checker = self.check_present_item(
            len(products), prices_, 'refresh')
        self.cart.clear_list()
        return checker

    def remove_datasets_content(self):
        self.logger.log('----- remove {} content-----'.format(self.MOVIE_PATH))
        for filename in os.listdir(self.MOVIE_PATH):
            file_path = os.path.join(self.MOVIE_PATH, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                self.errors.append(
                    'Failed to delete {}. Reason: {}'.format(file_path, e))
                self.logger.log(
                    'Failed to delete {}. Reason: {}'.format(file_path, e))

    def check_data_acquisition(self, products):
        self.logger.log('----- CHECK DATA_ACQUISITION -----')
        self.errors.append('#### DATA_ACQUISITION ####')
        self.remove_datasets_content()
        s3_path = self.get_s3_bucket()
        s3_path.delete()  # remove folder from s3 if exists
        self.logger.log('CLEAR S3 TESTER FOLDER')
        cururl = self.browser.current_url.split('/')[-1]
        if cururl != '':
            self.browser.get("http://localhost:3001/")
            time.sleep(1)
            self.check_loader()
            self.login(SUCCESS_PASS)
            time.sleep(1)
            # self.check_loader()
            # self.check_SW_updates_swal()
            data_btn = self.wait_for_id('data_btn')
            data_btn.click()
            time.sleep(1)
        else:
            self.check_loader()
            self.login(SUCCESS_PASS)
            time.sleep(1)
            # self.check_SW_updates_swal()
            data_btn = self.wait_for_id('data_btn')
            data_btn.click()
            time.sleep(1)
        time.sleep(10)
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "disabled_btn")))
        calibration = self.wait_for_id('run_calibration')
        calibration.click()
        self.check_loader()
        self.scan_items(products)
        sidebar = self.wait_for_id('openSideBar')
        sidebar.click()
        quit = self.wait_for_id('quit')
        quit.send_keys(Keys.ENTER)
        self.check_loader()
        home = self.wait_for_id('home_page')
        home.click()
        return self.check_output_records_files(products)

    def check_output_records_files(self, expected_products):
        self.logger.log('----- CHECK OUTPUT FILES -----')
        contain_files = []
        checker = []
        check_cameras = []
        paths = []
        cameras = ['B', 'L', 'R', 'prop', 'script']
        time.sleep(5)
        for root, dirs, files in os.walk(self.MOVIE_PATH + "/{}".format(self.today)):
            for file in files:
                contain_files.append(file.split('_'))
                paths.append(os.path.join(root, file))
        script_location = 0
        for i, file in enumerate(contain_files):
            checker.append(file[0] == 'calibration')
            res = " ".join(re.findall("[a-zA-Z]+", file[-1].split(".")[0]))
            if res == 'script':
                script_location = i
            check_cameras.append(res)
        if cameras != sorted(check_cameras):
            self.errors.append('cameras: {} {} {}'.format(
                cameras == sorted(check_cameras), check_cameras, cameras))
        self.logger.log('cameras: {} {} {}'.format(
            cameras == sorted(check_cameras), check_cameras, cameras))
        checker.append(cameras == sorted(check_cameras))
        data = []
        try:
            with open(paths[script_location]) as f:
                data = json.load(f)
        except:
            logger.log('path to movies undefined')
            checker.append(False)
        products = []
        for lst in data:
            if lst[1] != '':
                products.append(lst[1])
        to_remove = []
        for i, path in enumerate(paths):
            if path.endswith('.avi'):
                to_remove.append(path)
        self.remove_files(to_remove)
        self.logger.log('products: {} {} {}'.format(sorted(products) == sorted(expected_products), sorted(products),
                                                    sorted(expected_products)))
        if sorted(products) != sorted(expected_products):
            self.errors.append(
                'products: {} {} {}'.format(sorted(products) == sorted(expected_products), sorted(products),
                                            sorted(expected_products)))
        checker.append(sorted(products) == sorted(expected_products))
        try:
            self.upload_data()
            checker.append(True)
        except:
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        checker.append(self.check_s3_bucket(paths))
        return all(checker)

    def remove_files(self, to_remove):
        checker = [False, False]
        for avi in to_remove:
            os.remove(avi)
        while all(checker):
            for i in range(2):
                if os.path.exists(to_remove[i]):
                    checker[i] = False
                else:
                    checker[i] = True

    def upload_data(self):
        self.logger.log('----- CHECK UPLOAD -----')
        upload_btn = self.wait_for_id('upload_btn')
        upload_btn.click()
        start_upload = self.wait_for_id('start_upload')
        start_upload.click()
        start_upload = self.wait_for_id('close_upload')
        start_upload.click()

    def get_s3_bucket(self):
        s3 = boto3.resource('s3')
        my_bucket = s3.Bucket('walkout-main')
        Prefix = "cart_data/{}/walkout/tester".format(self.today)
        return my_bucket.objects.filter(Prefix=Prefix)

    def check_s3_bucket(self, paths):
        s3_list = []
        excepted_list = []
        for path in paths:
            if not path.endswith('.avi'):
                excepted_list.append(path.split("/")[-1])
        s3_path = self.get_s3_bucket()
        for object_summary in s3_path:
            s3_list.append(object_summary.key.split('/')[-1])

        s3_path.delete()
        self.logger.log('CLEAR S3 TESTER FOLDER')
        self.logger.log(
            "s3: {} {} {}".format(sorted(excepted_list) == sorted(s3_list), sorted(excepted_list), sorted(s3_list)))
        if sorted(excepted_list) != sorted(s3_list):
            self.errors.append(
                "s3: {} {} {}".format(sorted(excepted_list) == sorted(s3_list), sorted(excepted_list), sorted(s3_list)))
        return sorted(excepted_list) == sorted(s3_list)

    def scan_items(self, products):
        for item in products:
            self.wait.until(EC.invisibility_of_element_located(
                (By.CLASS_NAME, "swal2-container")))
            scanner = self.wait_for_id('open_scanner')
            scanner.click()
            scan = self.wait_for_tag_name('input')
            self.logger.log('----- SCAN {} -----'.format(item))
            scan.send_keys(item)
            scan.send_keys(Keys.ENTER)
            self.wait.until(EC.invisibility_of_element_located(
                (By.CLASS_NAME, "swal2-container")))
            item = self.wait_for_id('item_0')
            item.click()

    def is_between(self, time):
        if self.shop_mod_end < self.shop_mod_start:
            return time >= self.shop_mod_start or time <= self.shop_mod_end
        return self.shop_mod_start <= time <= self.shop_mod_end

    def check_FPS(self, path):
        log_path = os.path.join(path, 'webapp/server/app.log')
        # log_file = reversed(list(open(log_path)))
        log_file = sh.tail("-n 50", log_path, _iter=True)
        for line in log_file:
            if line.find('==========AVERAGE FPS WAS ====>') > 1:
                date = line.split(' ')[0]
                time = line.split(' ')[1]
                if date == self.today and self.is_between(time):
                    avg = re.findall("\d+\.\d+", line)
                    average = '{0:.2f}'.format(float(avg[0]), '.2f')
                    self.logger.log(
                        '------ AVERAGE FPS {} ------'.format(average))
                    if float(average) > FPS:
                        return True
                    else:
                        self.errors.append(
                            'except FPS to be > {} but get {}'.format(FPS, average))
                        return False

    def employee_panel_test(self):
        self.logger.log('----- CHECK EMPLOYEE PANEL -----')
        self.errors.append('#### EMPLOYEE_PANEL ####')
        cururl = self.browser.current_url.split('/')[-1]
        if cururl == 'home':
            time.sleep(1)
            self.check_loader()
            self.wait_for_id('shop_btn')
            self.browser.get("http://localhost:3001/shop")
        checker = []
        if cururl == '':
            time.sleep(1)
            self.check_loader()
            self.login(SUCCESS_PASS)
            # time.sleep(3)
            # self.check_SW_updates_swal()
            time.sleep(1)
            self.wait_for_id('shop_btn')
            self.browser.get("http://localhost:3001/shop")
        self.cart.send_one_frame()
        self.check_loader()
        self.cart.clear_list()
        time.sleep(1)
        checker.append(self.check_employee_panel('Simple'))
        checker.append(self.check_employee_panel('Advanced'))
        return all(checker)

    def check_employee_panel(self, mode):
        checker = []
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))
        sidebar = self.wait_for_id('openSideBar')
        sidebar.click()
        password_elem = self.wait_for_tag_name('input')
        password_elem.send_keys(SIMPLE_MODE if mode ==
                                               'Simple' else ADVANCED_MODE)
        password_elem.send_keys(Keys.ENTER)
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))
        lock_menu = self.wait_for_id('lock_menu')
        if mode == 'Simple':
            checker.append(self.panel_checker('stream_on_off', mode))
            checker.append(self.panel_checker('phase', mode))
            checker.append(self.panel_checker('display_planes', mode))
            checker.append(self.panel_checker('hold_rec', mode))

        checker.append(self.panel_checker('change_camera_view', mode))
        checker.append(self.panel_checker('detail_lvl', mode))
        checker.append(self.panel_checker('keyboard_on_off', mode))
        checker.append(self.panel_checker('change_mod', mode))
        if mode == 'Advanced':
            self.browser.get("http://localhost:3001/")
            time.sleep(1)
            self.check_loader()
            self.login(SUCCESS_PASS)
            # time.sleep(3)
            # self.check_SW_updates_swal()
            time.sleep(1)
        else:
            lock_menu.send_keys(Keys.ENTER)
            time.sleep(1)
        return all(checker)

    def panel_checker(self, btn, mode):
        global error
        try:
            self.browser.find_element_by_id(btn)
            self.errors.append('{} btn show in {} Mode'.format(btn, mode))
            self.logger.log('{} btn show in {} Mode'.format(btn, mode))
            return False
        except:
            return True

    def start_integration(self):
        cururl = self.browser.current_url.split('/')[-1]
        if cururl != '':
            self.browser.get("http://localhost:3001/")
        time.sleep(0.5)
        self.check_loader()
        self.login(SUCCESS_PASS)
        # time.sleep(3)
        # self.check_SW_updates_swal()
        time.sleep(0.5)
        self.check_loader()
        self.check_SW_updates_swal()
        shop_btn = self.wait_for_id('shop_btn')
        shop_btn.click()
        time.sleep(1)
        self.cart.clear_list()
        self.check_loader()
        # else:
        #     self.check_loader()
        #     self.wait_for_class_name('swal2-cancel').click()
        #     shop_btn = self.wait_for_id('shop_btn')
        #     shop_btn.click()
        #     time.sleep(1)
        #     self.cart.clear_list()
        #     self.check_loader()

    def integration_employee_panel(self):
        self.logger.log('----- CHECK INTEGRATION_EMPLOYEE_PANEL -----')
        self.errors.append('#### INTEGRATION_EMPLOYEE_PANEL ####')
        ERR_MSG = 'Sorry, we have a problem with this cart. Please report to an associate'
        self.start_integration()
        checker = []
        sidebar = self.wait_for_id('openSideBar')
        sidebar.click()
        password_elem = self.wait_for_tag_name('input')
        password_elem.send_keys(SIMPLE_MODE)
        password_elem.send_keys(Keys.ENTER)
        time.sleep(0.5)
        green_btn = self.wait_for_id('green_cart')
        red_btn = self.wait_for_id('red_cart')
        red_btn.click()
        time.sleep(2)
        cart_image = self.wait_for_id(
            "cart_status_image").get_attribute("alt")
        if cart_image == "cart_error":
            checker.append(True)
        else:
            self.errors.append('cart image dosent change to error')
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        cart_msg = self.wait_for_id("err_msg_cart")
        if cart_msg.text == ERR_MSG:
            checker.append(True)
        else:
            self.errors.append('error text != {}'.format(ERR_MSG))
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            checker.append(False)
        green_btn.click()
        time.sleep(2)
        cart_image = self.wait_for_id(
            "cart_status_image").get_attribute("alt")
        try:
            self.browser.find_element_by_id("err_msg_cart")
            self.errors.append('not change to error')
            checker.append(False)
        except:
            checker.append(True)
        if cart_image == "cart_ok":
            checker.append(True)
        else:
            self.errors.append('cart image != green')
            checker.append(False)
        quit = self.wait_for_id('quit')
        quit.send_keys(Keys.ENTER)
        self.check_loader()
        return all(checker)

    def integration_shopping_list(self):
        self.logger.log('----- CHECK INTEGRATION_SHOPPING_LIST -----')
        self.errors.append('#### INTEGRATION_SHOPPING_LIST ####')
        self.shop_mod_start = str(datetime.datetime.now().time()).split('.')[0]
        self.start_integration()
        self.wait_until_md_finish()
        self.shop_mod_end = str(datetime.datetime.now().time()).split('.')[0]
        time.sleep(5)
        self.browser.get("http://localhost:3001/shop")
        time.sleep(3)
        self.cart.send_one_frame()
        self.check_loader()
        time.sleep(10)
        for class_name in ['item_name', 'item_price', 'item_count']:
            self.wait_for_class_name(class_name)
        data = []
        counts = 0
        for elm in self.browser.find_elements_by_css_selector(".item_name,.item_price,.item_count"):
            data.append(elm.text)
        data = [data[i:i + 3] for i in range(0, len(data), 3)]
        # for item in data:
        #     counts += (int(item[1].split('Quantity: ')[1]))
        # in_events = counts > 1
        # out_events = counts.count(-1)
        if len(data) > 0:
            return True
        else:
            # self.errors.append(
            #     'expected at least 10 in events and get {}, expected at least 1 out events and get {}'.format(
            #         in_events, out_events))
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
            return False

    def wait_until_md_finish(self):
        sidebar = self.wait_for_id('openSideBar')
        sidebar.click()
        password_elem = self.wait_for_tag_name('input')
        password_elem.send_keys(SIMPLE_MODE)
        password_elem.send_keys(Keys.ENTER)
        time.sleep(0.5)
        self.wait.until(EC.invisibility_of_element_located(
            (By.CLASS_NAME, "swal2-container")))
        call_stream_tab = self.wait_for_id('open_promotions')
        call_stream_tab.click()
        stream_tab = self.wait_for_id('show_stream')
        stream_tab.click()
        lock = self.wait_for_id('lock_menu')
        lock.click()
        while True:
            try:
                self.browser.find_element_by_id('cart_picker_item')
                item = self.browser.find_element_by_id('picker_0')
                item.click()
                self.wait.until(EC.invisibility_of_element_located(
                    (By.CLASS_NAME, "swal2-container")))
            except:
                pass
            try:
                src = self.browser.find_element_by_id(
                    'stream_view_img').get_attribute("src")
                time.sleep(10)
                new_src = self.browser.find_element_by_id(
                    'stream_view_img').get_attribute("src")
                if src == new_src:
                    time.sleep(1)
                    return
            except:
                time.sleep(1)
                return

    def get_errors(self):
        return self.errors

    def check_SW_updates_swal(self):
        try:
            if self.browser.find_element_by_class_name('swal2-cancel'):
                sw_upd = self.wait_for_class_name('swal2-cancel')
                sw_upd.click()
        except:
            pass

    def start_without_MD(self):
        cururl = self.browser.current_url.split('/')[-1]
        if cururl == 'home':
            time.sleep(1)
            self.check_loader()
            self.wait_for_id('shop_btn')
            self.browser.get("http://localhost:3001/shop")
        if cururl == '':
            time.sleep(1)
            self.check_loader()
            self.login(SUCCESS_PASS)
            # time.sleep(3)
            # self.check_SW_updates_swal()
            time.sleep(1)
            self.wait_for_id('shop_btn')
            self.browser.get("http://localhost:3001/shop")
        self.cart.send_one_frame()
        self.check_loader()
        self.cart.clear_list()
        return True

    def promotions_and_slide_check(self):
        self.logger.log('----- CHECK PROMOTIONS & DEALS -----')
        self.errors.append('#### PROMOTIONS_DEALS ####')
        ####START SHOP_MODE without MD####
        self.start_without_MD()
        checker = []
        ### Insert Promotion Items ###
        deals = self.database.get_deals()
        is_deals_here = False
        deal_id = ''
        if len(deals) != 0:
            for id, deal in deals.items():
                deal_products = deal['products']
                if deal['discount_type'] == 2:
                    continue
                else:
                    deal_id = id
                    index = 0
                    for item in deal_products:
                        if index < deal['parameter1'] + deal['parameter2']:
                            self.cart.insert_item(item, 1, 1)
                            index += 1
                            is_deals_here = True
        if is_deals_here != False:
            try:
                time.sleep(1)
                call_stream_tab = self.wait_for_id('close_promotions')
                self.wait_for_id('promotionImage')
                call_stream_tab.click()
                time.sleep(1)
                self.wait_for_id('red_line')
                checker.append(True)
            except:
                filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
                self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
                checker.append(False)
        #Finish Insert Promotion Item#
            #Check Screenshots test on Dev-board#
            # filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            # self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
        # Check "Slide to Remove"
            action_add = ActionChains(self.browser)
            key = self.database.get_deals_item_from_id(deal_id, 1)
            slide = self.wait_for_id('item_{}'.format(key))
            try:
                action_add.click_and_hold(slide).move_by_offset(400, 0).release().perform()
                time.sleep(1)
                checker.append(True)
            except:
                filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
                self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
                checker.append(False)
            # Check "Slide to Add"
            action_remove = ActionChains(self.browser)
            key = self.database.get_deals_item_from_id(deal_id, 1)
            slide = self.wait_for_id('item_{}'.format(key))
            try:
                action_remove.click_and_hold(slide).move_by_offset(400, 0).release().perform()
                time.sleep(1)
                checker.append(True)
            except:
                filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
                self.browser.save_screenshot('{}/{}.png'.format(self.record_path, filename))
                checker.append(False)
        self.cart.clear_list()
        if len(deals) == 0:
            filename = (strftime("%b %d %Y %H:%M:%S", time.gmtime()))
            self.browser.save_screenshot('{}/{}_NO_DEALS.png'.format(self.record_path, filename))
            checker.append(False)
        return all(checker)


if __name__ == '__main__':
    # args: 1. path to walkout
    automation_err = False
    errors = None
    logger = Logger.Logger()
    logger.print(
        Fore.MAGENTA, "--- Init Automation wait for Database to start ---")
    path = sys.argv[1]
    db_path = os.path.join(path, 'webapp/server/database.sqlite3')
    checker = {}
    errors_ = {}
    start_time = time.time()
    test = Tester(logger, db_path)
    logger.print(Fore.MAGENTA, "--- Start Testing ---")
    products = ['22115461', '22125118', '4061458003391']
    prices = [1.29, 2.69, 2.79]
    try:
        checker['LOGIN'] = test.login_webapp()
    except Exception as e:
        checker['LOGIN'] = False
        errors_['LOGIN'] = traceback.format_exc()
    try:
        checker['CART'] = test.check_cart()
    except Exception as e:
        checker['CART'] = False
        errors_['CART'] = traceback.format_exc()
    try:
        checker['PRODUCTS_IMAGES'] = test.check_images()
    except Exception as e:
        checker['PRODUCTS_IMAGES'] = False
        errors_['PRODUCTS_IMAGES'] = traceback.format_exc()
    try:
        checker['PROMOTIONS_AND_SLIDE'] = test.promotions_and_slide_check()
    except Exception as e:
        checker['PROMOTIONS_AND_SLIDE'] = False
        errors_['PROMOTIONS_AND_SLIDE'] = traceback.format_exc()
    # ## try:
    #     checker['ERRORS_STATE'] = test.check_cart_icon()
    # except Exception as e:
    #     checker['ERRORS_STATE'] = False
    #     errors_['ERRORS_STATE'] = traceback.format_exc()
    try:
        checker['REENTER'] = test.check_exit_from_shop_and_reenter()
    except Exception as e:
        checker['REENTER'] = False
        errors_['REENTER'] = traceback.format_exc()
    try:
        checker['REFRESH'] = test.check_refresh(products, prices)
    except Exception as e:
        checker['REFRESH'] = False
        errors_['REFRESH'] = traceback.format_exc()
    ### try:
    #     depreceted test
    #     checker['LOW_CONFIDENCE_MODAL'] = test.check_low_confidence_modal(
    #         products, prices)
    # except Exception as e:
    #     checker['LOW_CONFIDENCE_MODAL'] = False
    #     errors_['LOW_CONFIDENCE_MODAL'] = traceback.format_exc()
    try:
        checker['DATA_ACQUISITION'] = test.check_data_acquisition(products)
    except Exception as e:
        checker['DATA_ACQUISITION'] = False
        errors_['DATA_ACQUISITION'] = traceback.format_exc()
    try:
        checker['EMPLOYEE_PANEL'] = test.employee_panel_test()
    except Exception as e:
        checker['EMPLOYEE_PANEL'] = False
        errors_['EMPLOYEE_PANEL'] = traceback.format_exc()
    try:
        checker['INTEGRATION_SHOPPING_LIST'] = test.integration_shopping_list()
    except Exception as e:
        checker['INTEGRATION_SHOPPING_LIST'] = False
        errors_['INTEGRATION_SHOPPING_LIST'] = traceback.format_exc()
    try:
        checker['FPS'] = test.check_FPS(path)
    except Exception as e:
        checker['FPS'] = False
        errors_['FPS'] = traceback.format_exc()
    ## try:
    #     checker['INTEGRATION_EMPLOYEE_PANEL'] = test.integration_employee_panel()
    # except Exception as e:
    #     checker['INTEGRATION_EMPLOYEE_PANEL'] = False
    #     errors_['INTEGRATION_EMPLOYEE_PANEL'] = traceback.format_exc()
    print_small_log = False

    errors = test.get_errors()
    for x, y in checker.items():
        if y:
            logger.print(Fore.GREEN, '###### {} PASS ######'.format(x))
        else:
            print_small_log = True
            logger.print(Fore.RED, '###### {} FAILED ######'.format(x))

    logger.print(Fore.MAGENTA,
                 "--- Total Time {} ---".format(time.strftime('%H:%M:%S', time.gmtime(time.time() - start_time))))
    if print_small_log:
        for row in errors:
            if row.startswith('#'):
                logger.print(Fore.YELLOW, row)
            else:
                logger.print(Fore.RED, row)

    if len(errors_) > 0:
        automation_err = True
        for x, y in errors_.items():
            print('got exception from {}: {}'.format(x, y))

    s3_path = test.get_s3_bucket()
    s3_path.delete()  # remove folder from s3 if exists before close automation
    test.close()
    sys.exit(automation_err or not all(checker.values()))
