import logging
from colorama import Fore


class Logger:
    def __init__(self):
        self.logger = logging
        self.logger.basicConfig(filename='AutomationTest.log', filemode='w', level=logging.INFO,
                                format='%(asctime)s %(message)s', datefmt='%Y-%m-%d %H:%M:%S')

    def log(self, msg):
        self.logger.info(msg)

    def print(self, color, msg):
        self.log(msg)
        print(color + msg)
        print(Fore.RESET + '', end='')
