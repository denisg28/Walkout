import sqlite3
import os
import time


class SqliteConnector:
    def __init__(self, db_path):
        self.products = []
        self.deals = {}
        self.table_types = {}
        self.cursor = None
        while not os.path.exists(db_path):
            time.sleep(1)
        can_start = False
        while not can_start:
            try:
                self.connect_to_db(db_path)
                time.sleep(10)
                can_start = True
            except:
                time.sleep(1)

    def connect_to_db(self, db_path):
        sqliteConnection = sqlite3.connect(db_path)
        sqliteConnection.text_factory = str
        self.cursor = sqliteConnection.cursor()
        self.defined_sqlite_schema()
        self.get_all_items()
        self.get_deal_items()

    def get_all_items(self):
        self.cursor.execute("SELECT * FROM Products")
        rows = self.cursor.fetchall()
        for row in rows:
            self.products.append(row[self.table_types['product_code']])

    def defined_sqlite_schema(self):
        query = " PRAGMA table_info(Products) "
        self.cursor.execute(query)
        rows = self.cursor.fetchall()
        for row in rows:
            self.table_types[row[1]] = row[0]

    def get_products(self):
        return self.products

    def get_deals(self):
        return self.deals

    def get_deals_item_from_id(self, deal_id, pos):
        return self.deals[deal_id]['products'][pos]

    def get_deal_items(self):
        self.cursor.execute("SELECT * FROM Deals")
        deals = self.cursor.fetchall()
        self.cursor.execute("SELECT * FROM DealsProducts")
        deals_products = self.cursor.fetchall()
        for row in deals:
            self.deals[row[0]] = {"discount_type": row[1], "parameter1": row[2], "parameter2": row[3]}
        for row in deals_products:
            if 'products' not in self.deals[row[2]]:
                self.deals[row[2]]['products'] = [row[1]]
            else:
                self.deals[row[2]]['products'].append(row[1])

# if __name__ == '__main__':
#     db_path = "/home/walkout06/walkout/webapp/server/database.sqlite3"
#     a = SqliteConnector(db_path)
#
#     a.get_deal_items()
