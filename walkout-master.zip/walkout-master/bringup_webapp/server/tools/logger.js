const { createLogger, format, transports } = require('winston');
const { combine, timestamp, simple, splat, printf } = format;

const myFormat = printf(({ level, message, timestamp }) => {
    return `${timestamp} ${level}: ${message}`;
});

const timezoned = _ => {
    const now = new Date();
    const offsetMs = now.getTimezoneOffset() * 60 * 1000;
    const dateLocal = new Date(now.getTime() - offsetMs);
    return dateLocal.toISOString().slice(0, 19).replace("T", " ");
};

const logger = createLogger({
    format: combine(
        timestamp({
            format: timezoned
        }),
        simple(),
        splat(),
        myFormat
    ),
    transports: [
        new transports.File({ filename: 'app.log' }),
        new transports.Console()
    ]
});

const uptime_log = createLogger({
    format: combine(
        timestamp({
            format: timezoned
        }),
        simple(),
        splat(),
        myFormat
    ),
    transports: [
        new transports.File({ filename: 'uptime.log' })
    ]
});

module.exports = { logger, uptime_log };