const os = require('os');
const { logger, uptime_log } = require('../logger');
const ks = require('node-key-sender');
const wifi = require("node-wifi");
const publicIp = require('public-ip');
const isOnline = require('is-online');
const { execSync, spawn } = require('child_process');

wifi.init({ iface: 'wlan0' });
let isConnected = false;
let rescan = 0;
let login = false;
let connection_payload = {};
let activity_type = 'idle';
const uptime_log_interval = 1000 * 60;
const uptime_log_interval_minutes = uptime_log_interval * 2;

const checker = (function liveCheck(socket, myEmitter) {
    isOnline().then(async online => {
        const ssid = await get_wifi_ssid_name();
        const ssid_name = ssid.split('\n')[1].split(' ')[0];
        let internal_ip;
        try { internal_ip = await checkIpv4() } catch (e) { internal_ip = 'NONE' }
        let external_ip = 'NONE';
        if (online) {
            isConnected = true;
            try { external_ip = await publicIp.v4(); } catch (e) { external_ip = 'NONE' };
        }
        else isConnected = false;
        myEmitter ? myEmitter.emit('wifi_scanner') : null;
        const event_payload = {
            ssid_name,
            internet_connection: isConnected,
            external_ip,
            internal_ip
        };
        JSON.stringify(connection_payload) !== JSON.stringify(event_payload) ? logger.log('info', `event_type:network_interfaces, event_payload:${JSON.stringify(event_payload)}`) : null;
        connection_payload = { ...event_payload };
        socket ? socket.emit('ipv4', internal_ip === 'NONE' ? '' : internal_ip) : null;
        socket ? socket.emit('current_connection', ssid_name) : null;
        socket ? socket.emit('connection', isConnected) : null;
    });
    return liveCheck;
}());

function checkIpv4() {
    return new Promise((resolve, reject) => {
        const ifaces = os.networkInterfaces();
        let found = false;
        Object.keys(ifaces).forEach(dev => {
            ifaces[dev].filter(details => {
                const { family, internal, address } = details;
                if (family === 'IPv4' && !internal) {
                    resolve(address);
                }
            })
        });
        if (!found)
            reject('');
    });
}

function get_wifi_ssid_name() {
    return new Promise((resolve, reject) => {
        try {
            const data = execSync('nmcli --fields NAME con show --active').toString();
            resolve(data)
        }
        catch (e) { reject(''); }
    });

}

function scan_for_wifi() {
    return new Promise((resolve, reject) => {
        if (rescan % 10 === 0) {
            try {
                execSync('nmcli device wifi rescan');
                rescan++;
            }
            catch (e) {/* cant scan now*/ }
        }
        try {
            const data = execSync('nmcli -f SSID dev wifi').toString();
            resolve(data)
        }
        catch (e) { reject([]); }
    });
}

function exit_all(socket, myEmitter, cmd) {
    socket.removeAllListeners();
    myEmitter.removeAllListeners();
    spawn("sudo", [cmd]);
    throw 'NodeJS killed';
}

/**
* get data back from FE via socket io
*/

exports = module.exports = (io, myEmitter) => {
    myEmitter.on('wifi_scanner', async _ => {
        const networks = await scan_for_wifi();
        io.emit('wifi_networks', networks);
    });

    myEmitter.on('checker', _ => checker(undefined, myEmitter));
    myEmitter.on('logger', (log, system) => {
        const { event_type, event_payload } = log;
        system ? uptime_log.log('info', `event_type:${event_type}, event_payload:${JSON.stringify(event_payload)}`) :
            logger.log('info', `event_type:${event_type}, event_payload:${JSON.stringify(event_payload)}`);
    });

    io.sockets.on('connection', socket => {
        let connectionInterval;
        activity_type = 'idle';
        myEmitter.emit('logger', { event_type: 'activity', event_payload: { activity_type } }, true);
        let activityInteval = setInterval(_ => myEmitter.emit('logger', { event_type: 'activity', event_payload: { activity_type } }, true), uptime_log_interval_minutes);
        socket.on('error', _ => {
            clearInterval(activityInteval);
            clearInterval(connectionInterval);
        });
        socket.on('connect_failed', _ => {
            clearInterval(connectionInterval);
            clearInterval(activityInteval);
        });
        socket.on('disconnect', _ => clearInterval(activityInteval));
        socket.on('get_login', _ => socket.emit('loggedin', login));
        socket.on('set_login', data => login = data);
        socket.on('close_interval', _ => clearInterval(connectionInterval));

        socket.on('set_interval', _ => {
            checker(socket, myEmitter)
            socket.emit('connection', isConnected);
            clearInterval(connectionInterval);
            connectionInterval = setInterval(_ => checker(socket, myEmitter), 3000);
        });

        socket.on('connect_wifi', data => {
            wifi.connect(data, err => {
                if (err)
                    socket.emit('connect_to_wifi', data.ssid, false);
                else socket.emit('connect_to_wifi', data.ssid, true)
            });
        });

        socket.on('disconnect_from_wifi', _ => {
            if (isConnected) {
                wifi.disconnect(error => {
                    if (error) return;
                });
            }
        });

        socket.on('exit', cmd => {
            ks.sendCombination(['control', 'shift', 'w']);
            exit_all(socket, myEmitter, cmd);
        });
    });
}