const bodyParser = require("body-parser");
const path = require('path');
const port = process.env.PORT || 3001;
const express = require('express')
const app = express();
const Server = require('http').createServer(app)
const io = require('socket.io')(Server);
const EventEmitter = require('events');
const { logger } = require('./tools/logger');
class MyEmitter extends EventEmitter { }
const myEmitter = new MyEmitter();
io.sockets.setMaxListeners(Infinity);
myEmitter.setMaxListeners(Infinity);
require('./tools/IO/Init')(io, myEmitter);
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(bodyParser.json());

myEmitter.emit('checker');
myEmitter.on('close', _ => { });

const root = path.join(__dirname, '../client', 'build')
app.use(express.static(root));

app.get('*', (_, res) => res.sendFile('index.html', { root }));

// =============================================================================================
logger.log('info', '################################################################################');
Server.listen(port, '127.0.0.1', _ => {
  logger.log('info', `####################### NodeJS server listen on port ${port} ######################`);
  logger.log('info', '################################################################################');
});
