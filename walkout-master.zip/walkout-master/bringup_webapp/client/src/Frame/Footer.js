import React, { Component } from 'react';
const Logo = require('../assets/images/WalkOut_Logo.png');

const root = {
    backgroundColor: '#9cb4d7',
    color: 'white',
    position: 'fixed',
    left: 0,
    bottom: 0,
    width: '100%',
    height: 60,
    textAlign: 'center',
};

/**
 * function that handle the screen footer and send errors to client 
 */

class Footer extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    render() {
        return (
            <footer style={root}><br />
                <img style={{ marginTop: '-25px' }} src={Logo} alt='' />
                <p style={{ fontSize: '15px', marginTop: '-12px' }}>Smart shopping platform</p>
            </footer>
        );
    }
}

export default Footer;