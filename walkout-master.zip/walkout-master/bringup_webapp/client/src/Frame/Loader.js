import React, { Component } from 'react';
import { connect } from "react-redux";
import { withStyles } from "@material-ui/core/styles";
import { CircularProgress, Dialog, DialogContent } from '@material-ui/core';
import { ChangeLoad } from '../store/actions/loaderAction';
import '../Styles/Loader.css';


const styles = {
    dialogPaper: {
        minHeight: '80vh',
        maxHeight: '80vh',
        backgroundColor: 'transparent',
        boxShadow: 'unset'
    },
    whiteDialogPaper: {
        minHeight: '80vh',
        maxHeight: '80vh',
        backgroundColor: 'transparent',
        boxShadow: 'unset',
        color: 'white'
    },
};

const MyDialog = withStyles(styles)(props => {
    const { children, classes, color, ...other } = props;
    return (
        <Dialog classes={!!color ? { paper: classes.whiteDialogPaper } : { paper: classes.dialogPaper }}
            {...other}>
            {children}
        </Dialog>
    );
});

class Loader extends Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }

    componentDidMount() {
        const { ChangeLoad } = this.props;
        ChangeLoad(0);
    }

    componentWillUnmount() { }

    render() {
        const { load } = this.props;
        return (
            <MyDialog
                id={'loader_page'}
                color={'white'}
                fullWidth={true}
                open={!!load}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>
                    <div className='loaderContainer'>
                        <CircularProgress style={{ color: 'white' }} size={80} thickness={2} className='loader' />
                        <br />
                        <br />
                        Connecting...
                    </div>
                </DialogContent>
            </MyDialog>
        );
    }
};


const mapStateToProps = (state) => {
    return {
        load: state.loader.load
    }
};

const mapDispatchToProps = (dispatch) => {
    return {
        ChangeLoad: (load) => dispatch(ChangeLoad(load)),
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Loader)
