const initState = {
    login: localStorage.getItem('login') || '1',
};

const loginReducer = (state = initState, action) => {
    switch (action.type) {
        case 'CHANGE_LOGIN':
            localStorage.setItem('login', action.login);
            return {
                ...state,
                login: action.login
            };
        default:
            return state;
    }
};
export default loginReducer;
