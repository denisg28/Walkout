const initState = {
    load: Number(localStorage.getItem('loading')) || 1
};

const loaderReducer = (state = initState, action) => {
    switch (action.type) {
        case 'CHANGE_LOAD':
            localStorage.setItem('loading', action.load);
            return {
                ...state,
                load: action.load
            };
        default:
            return state;
    }
};
export default loaderReducer;
