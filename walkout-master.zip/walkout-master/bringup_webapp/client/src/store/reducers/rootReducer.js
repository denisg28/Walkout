import loginReducer from './loginReducer';
import loaderReducer from './loaderReducer';
import { combineReducers } from "redux";

const rootReducer = combineReducers({
    loader: loaderReducer,
    login: loginReducer
});
export default rootReducer;
