export const ChangeLogin = (login) => {
    return async (dispatch, getState) => {
        dispatch({ type: 'CHANGE_LOGIN', login });
    };
};
