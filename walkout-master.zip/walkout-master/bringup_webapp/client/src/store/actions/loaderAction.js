export const ChangeLoad = (load) => {
    return async (dispatch, getState) => {
        dispatch({type: 'CHANGE_LOAD', load});
    };
};
