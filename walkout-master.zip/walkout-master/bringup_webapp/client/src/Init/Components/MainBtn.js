import React from 'react';

const divStyle = {
    display: 'inline-block',
    margin: '5px 45px 5px 5px',
    boxShadow: '0 4px 8px 0 rgba(0,0,0,0.4)',
    padding: '0 10px 0 10px',
    borderRadius: '5px',
    backgroundColor: 'lightgrey'
};

const spanStyle = {
    color: '#707070',
    fontSize: 'x-large',
    fontWeight: 'bold',
    margin: 'auto',
    display: 'block',
    textAlign: 'center'
};

const imgStyle = {
    width: '190px',
    height: '190px'
};

function MainBtn(props) {
    const { text, image, id } = props;
    return (
        <div className='initBtn'
            id={id}
            style={divStyle} >
            <img src={image} style={imgStyle} alt='' /> < br />
            <span style={spanStyle} > {text} </span>
        </div >
    )
}

export default MainBtn;