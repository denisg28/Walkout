import React from 'react'
const style = { borderRadius: '5px', display: 'inline-block', margin: '5px', marginLeft: '15px', marginTop: '20px', boxShadow: '0 4px 8px 0 rgba(0,0,0,0.4)', padding: '5px' };
const wifi_style = { borderRadius: '5px', float: 'right', marginRight: '10px', boxShadow: '0 4px 8px 0 rgba(0,0,0,0.4)', padding: '5px', marginTop: '20px' };

const imgStyle = {
    width: '42px',
    height: '42px',
    padding: '6px'
};

function UpBtn(props) {
    const { image, run, wifi, runAndGo } = props;
    return (
        <div className='upBtn'
            onClick={() => runAndGo ? runAndGo(run) : null}
            style={!!wifi ? wifi_style : style} >
            <img src={image} style={imgStyle} alt='' /> < br />
        </div >
    )
}
export default UpBtn;