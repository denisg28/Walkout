import '../../Styles/Loader.css';
import { CircularProgress, Dialog, DialogContent } from '@material-ui/core';
import React, { Component } from 'react';
import { withStyles } from "@material-ui/core/styles";


const styles = {
    dialogPaper: {
        minHeight: '80vh',
        maxHeight: '80vh',
        backgroundColor: 'transparent',
        boxShadow: 'unset'
    },
    whiteDialogPaper: {
        minHeight: '80vh',
        maxHeight: '80vh',
        backgroundColor: 'transparent',
        boxShadow: 'unset',
        color: 'white'
    },
};

const MyDialog = withStyles(styles)(props => {
    const { children, classes, color, ...other } = props;
    return (
        <Dialog
            classes={!!color ? { paper: classes.whiteDialogPaper } : { paper: classes.dialogPaper }}
            {...other}>
            {children}
        </Dialog>
    );
});

class Loader extends Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    render() {
        const { open } = this.props;
        return (
            <MyDialog
                id={'loader_page'}
                fullWidth={true}
                open={!open}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>
                    <div className='loaderContainer'>
                        <CircularProgress style={{ color: 'white' }} size={80} thickness={2} className='loader' />
                        <br />
                        <br />
                        {<span style={{ color: 'white' }}>Loading...</span>}
                    </div>
                </DialogContent>
            </MyDialog>
        );
    }
};

export default Loader;
