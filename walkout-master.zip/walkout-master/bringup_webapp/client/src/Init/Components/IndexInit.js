import React, { Component } from 'react';
import { Redirect } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../Styles/Init.css';
import { connect } from "react-redux";
import $ from "jquery/dist/jquery.min";
import Footer from '../../Frame/Footer';
import WifiSelect from './WifiSelect';
import Keyboard from 'react-simple-keyboard';
import 'react-simple-keyboard/build/css/index.css';
import VisibilityIcon from '@material-ui/icons/Visibility';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import '../../Styles/keyboard.css';
import Swal from 'sweetalert2';
import UpBtn from './UpBtn';
import MainBtn from './MainBtn';
import Loader from '../../Frame/Loader';
import { ChangeLogin } from '../../store/actions/loginAction';
import { ChangeLoad } from '../../store/actions/loaderAction';
import Login from './Login';
const Wifi_On = require('../../assets/Init-images/wifi.png');
const Wifi_Off = require('../../assets/Init-images/wifi-off.png');
const Reboot = require('../../assets/Init-images/reboot.png');
const Power = require('../../assets/Init-images/power.png');
const Shop = require('../../assets/Init-images/shop.gif');
const Data = require('../../assets/Init-images/data.gif');
const Upload = require('../../assets/Init-images/upload.gif');

const VisibilityStyle = {
    float: 'right',
    marginTop: '93px',
    color: 'black',
    position: 'relative',
    fontSize: '32px',
    marginRight: '5px'
};

/**
 * IndexInit (root) component handle the main page  
 */
class IndexInit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            layout: 'default',
            input: '',
            path: '',
            inputType: 'password',
            openKeyboard: false,
            wifi: '',
            connection: null,
            showGUI: true,
            openPopup: true,
            redirect: '',
            ipv4: ''
        };
        this.Interval = null;
        this.passInterval = null;
    }

    componentDidMount() {
        const { socket, ChangeLoad } = this.props;
        ChangeLoad(0);
        socket.emit('get_ipv4');
        socket.emit('get_login');
        socket.on('connection', connection => this.setState({ connection }));
        socket.on('ipv4', ipv4 => this.setState({ ipv4 }));
        socket.on('loggedin', login => this.props.ChangeLogin(login));
        socket.on('connect_to_wifi', (ssid, success) => {
            ChangeLoad(0);
            let text, icon;
            if (success) {
                text = `Successfully connect to ${ssid} network`;
                icon = 'success';
            } else {
                text = `Cannot connect to ${ssid} network`;
                icon = 'error';
            }
            Swal.fire({
                text, icon, timer: 1500,
            });
        });
    }

    componentWillUnmount() {
        const { socket } = this.props;
        socket.off('connection');
        socket.off('ipv4');
        socket.off('loggedin');
        socket.off('connect_to_wifi');
    }

    WifiHandler = _ => {
        const { socket } = this.props;
        socket.emit('wifi_scanner');
        socket.emit('disconnect_from_wifi')
    }

    componentDidUpdate() {
        const { openKeyboard } = this.state;
        if (openKeyboard)
            this.passInterval = setInterval(_ => $('#wifiinputpass').focus(), 100);
        else clearInterval(this.passInterval);
    }

    onChange = input => this.setState({ ...this.state, input });

    checkPass = pass => {
        const { socket } = this.props;
        if (pass.trim() === 'innovation1') {
            this.setState({ openPopup: false });
            socket.emit('set_login', true);
            this.props.ChangeLogin(true);
        }
        else Swal.fire({
            title: 'Password Mismatched!',
            icon: 'error',
            showConfirmButton: false,
            customClass: 'zclass',
            timer: 2000
        }).then(_ => this.setState({ pass: '' }));
    }

    onKeyPress = button => {
        const { socket } = this.props;
        const { wifi, input } = this.state;
        if (button === "{lock}")
            this.handleShift();
        if (button === '{close}')
            this.closeKeyboard(false);
        if (button === '{enter}') {
            socket.emit('connect_wifi', { ssid: wifi, password: input });
            this.closeKeyboard(true);
        }
    }

    sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));

    closeKeyboard(flag) {
        const { ChangeLoad } = this.props;
        this.setState({ openKeyboard: false, input: '', wifi: '' }, _ =>
            this.sleep(200).then(_ => {
                flag ? ChangeLoad(1) : ChangeLoad(0);
                this.setState({ showGUI: true });
            }));
    }

    handleShift = _ => {
        const { layout } = this.state;
        this.setState({
            ...this.state,
            layout: layout === "default" ? "lock" : "default"
        });
    };

    changeInputType() {
        let { inputType } = this.state;
        if (inputType === 'password')
            inputType = 'text';
        else inputType = 'password'
        this.setState({ ...this.state, inputType });
    }

    onChangeInput = event => {
        const input = event.target.value;
        this.setState({ ...this.state, input }, _ => this.keyboard.setInput(input));
    };

    onSelect = wifi =>
        Swal.fire({
            text: 'Provide Wifi Password Here',
            icon: 'info',
            showConfirmButton: false,
            timer: 1000,
            showClass: {
                popup: 'animated fadeInDown faster'
            },
            hideClass: {
                popup: 'animated fadeOutUp faster'
            }
        }).then(_ => this.setState({ openKeyboard: true, wifi, showGUI: false }));

    runAndGo = query => {
        const { socket } = this.props;
        Swal.fire({
            title: 'Are you sure?',
            text: `This operation will cause system to ${query}`,
            icon: 'question',
            confirmButtonColor: '#3085d6',
            showCancelButton: true,
            cancelButtonColor: '#d33',
            confirmButtonText: `Yes, ${query}!`,
            reverseButtons: true
        }).then(result => {
            if (result.value)
                socket.emit('exit', query);
        });

    }


    render() {
        const { socket, login } = this.props;
        const { layout, input, inputType, openKeyboard, connection, showGUI, openPopup, redirect, ipv4 } = this.state;
        if (!JSON.parse(login))
            return (
                <div>
                    <Login open={openPopup} run={this.runAndGo} handleClickPassword={this.checkPass} />
                    <Footer translate={false} socket={socket} />
                </div>
            );
        else if (redirect.length) return <Redirect to={`/${redirect}`} />
        return (
            <div className="HomeInit">
                <Loader />
                <UpBtn text={'POWER'} image={Power} run={'poweroff'} runAndGo={this.runAndGo} />
                <UpBtn text={'REBOOT'} image={Reboot} run={'reboot'} runAndGo={this.runAndGo} />
                <WifiSelect socket={socket} ChangeLoad={this.props.ChangeLoad} onSelect={this.onSelect} />
                <UpBtn text={'WIFI'} image={connection ? Wifi_On : Wifi_Off} runAndGo={this.WifiHandler} wifi={true} />
                <h1 style={
                    { color: '#707070', textAlign: 'center', marginTop: '45px', fontSize: '-webkit-xxx-large' }
                } > Welcome! </h1>
                {showGUI ?
                    <>
                        <div style={
                            {
                                marginTop: '50px',
                                marginRight: '10%',
                                marginLeft: 'auto',
                                display: 'table'
                            }
                        } >
                            <MainBtn text={'SHOP'} id={'shop_btn'} image={Shop} />
                            <MainBtn text={'DATA'} id={'data_btn'} image={Data} />
                            <MainBtn text={'UPLOAD'} id={'upload_btn'} image={Upload} />
                        </div>
                        <div style={{
                            float: 'right',
                            marginTop: '5%',
                            marginRight: 10,
                            color: '#9CB4D7',
                            fontWeight: 'bold'
                        }}>
                            <span>IPv4: </span>
                            <span style={{ color: connection || !ipv4.length ? '#9CB4D7' : 'orange' }}>{ipv4.length ? ipv4 : 'Not Connected'}</span></div></> : null}
                {openKeyboard ?
                    <div>
                        <div style={{
                            position: 'absolute',
                            top: '0',
                            marginTop: '280px',
                            width: '100%'
                        }}>
                            <input autoComplete={"off"} id={'wifiinputpass'} ref={inputType => inputType && inputType.focus()} type={'text'} value={input} style={{
                                width: '100%', borderRadius: '15px',
                                border: '2px solid',
                                paddingLeft: '10px',
                                WebkitTextSecurity: inputType === 'password' ? 'disc' : ''
                            }}
                                onChange={e => this.onChangeInput(e)} />
                        </div>
                        {inputType === 'password' ?
                            <VisibilityIcon
                                onClick={_ => this.changeInputType()} style={VisibilityStyle} /> :
                            <VisibilityOffIcon
                                onClick={_ => this.changeInputType()} style={VisibilityStyle}
                            />}
                        <br />
                        <Keyboard
                            keyboardRef={r => (this.keyboard = r)}
                            layoutName={layout}
                            theme={"my-theme hg-theme-default hg-layout-default"}
                            layout={{
                                'default': [
                                    '` 1 2 3 4 5 6 7 8 9 0 - = {bksp}',
                                    '{tab} q w e r t y u i o p [ ] \\',
                                    '{lock} a s d f g h j k l ; \' {enter}',
                                    '@ z x c v b n m , . / {close}',
                                    '{space}'
                                ],
                                'lock': [
                                    '~ ! @ # $ % ^ & * ( ) _ + {bksp}',
                                    '{tab} Q W E R T Y U I O P { } |',
                                    '{lock} A S D F G H J K L : " {enter}',
                                    '@ Z X C V B N M < > ? {close}',
                                    '{space}'
                                ]
                            }}
                            buttonTheme={[
                                {
                                    class: "hg-red-home",
                                    buttons: "{close}"
                                },
                                {
                                    class: "hg-green-home",
                                    buttons: "{enter}"
                                },
                            ]}
                            display={{
                                '{bksp}': 'BackSpace',
                                '{enter}': 'Connect',
                                '{tab}': 'Tab',
                                '{close}': 'Close',
                                '{space}': 'Space',
                                '{lock}': 'Caps Lock'
                            }}
                            onChange={input =>
                                this.onChange(input)}
                            onKeyPress={button =>
                                this.onKeyPress(button)}
                        />
                    </div> : null}
                <Footer translate={false} socket={socket} />
            </div >
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        ChangeLogin: (login) => dispatch(ChangeLogin(login)),
        ChangeLoad: (flag) => dispatch(ChangeLoad(flag))
    }
};

const mapStateToProps = (state) => {
    return {
        login: state.login.login
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(IndexInit);