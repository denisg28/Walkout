import React, { Component } from 'react';
import { Select, FormControl, MenuItem } from '@material-ui/core';

const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: 250
        },
    },
};

const FormControlStyle = {
    minWidth: 170,
    maxWidth: 170,
    float: 'right',
    background: 'aliceblue',
    marginTop: 20,
    marginRight: 15
};

class WifiSelect extends Component {
    constructor(props) {
        super(props);
        this.state = {
            wifi_nets: [],
            select: [],
            curr_ssid: '',
            selectOpen: false
        }
    }

    componentDidMount() {
        const { socket } = this.props;
        socket.emit('set_interval');
        socket.on('wifi_networks', networks => {
            const wifis = [];
            for (let net of networks.split('\n'))
                if (net.trim() !== 'SSID')
                    wifis.push(net.trim());
            const { selectOpen } = this.state;
            const wifi_nets = [...new Set(wifis)];
            if (!selectOpen) {
                this.setState({ wifi_nets });
            }
        });

        socket.on('current_connection', curr_ssid => this.setState({ curr_ssid: curr_ssid.length ? curr_ssid : '' }));
    }

    handleChange = event => {
        const select = event.target.value;
        this.setState({ ...this.state, select }, _ => this.props.onSelect(select));
    };

    renderWIFI() {
        const { wifi_nets } = this.state;
        return wifi_nets.length ? wifi_nets.map((name, index) =>
            (<MenuItem key={index} value={name}> {name} </MenuItem>)) : null
    }

    componentWillUnmount() {
        const { socket } = this.props;
        socket.off('wifi_networks');
        socket.off('current_connection')
    }

    canUpdateNetworks = selectOpen => this.setState({ selectOpen });

    render() {
        const { curr_ssid } = this.state;
        return (
            <FormControl variant="outlined" style={FormControlStyle}>
                <Select
                    MenuProps={MenuProps}
                    value={curr_ssid}
                    onChange={this.handleChange}
                    onOpen={_ => this.canUpdateNetworks(true)}
                    onClose={_ => this.canUpdateNetworks(false)}
                >
                    <MenuItem disabled value="">
                        <em>Select WIFI</em>
                    </MenuItem>
                    {this.renderWIFI()}
                </Select>
            </FormControl>
        );
    }
}

export default WifiSelect;