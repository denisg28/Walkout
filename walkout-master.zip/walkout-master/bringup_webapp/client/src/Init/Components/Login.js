import React, { Component } from 'react';
import VisibilityIcon from '@material-ui/icons/Visibility';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';
import '../../Styles/keyboardPass.css';
import $ from "jquery/dist/jquery.min";
import Keyboard from 'react-simple-keyboard';
import 'react-simple-keyboard/build/css/index.css';

const VisibilityStyle = {
    float: 'right',
    marginTop: '-151px',
    color: 'black',
    position: 'relative',
    fontSize: '32px',
    marginRight: '715px'
}

/**
 * Login component handle the login to innovation
 */
class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            input: '',
            layout: 'default',
            inputType: 'password',
            unmount: false
        };
        this.Interval = null;
        this.handleKeyPress = this.handleKeyPress.bind(this);
    }

    onChange = (input) => {
        this.setState({ ...this.state, input });
    }

    handleChangeInput = (e) => {
        const input = e.target.value;
        this.setState({ ...this.state, input },
            () => {
                this.keyboard.setInput(input);
            }
        );
    };

    handleClose = () => {
        const { input } = this.state;
        this.setState({ ...this.state, input: '' }, () => {
            this.keyboard.setInput(input);
            this.props.handleCloseModal();
        });
    };

    componentDidMount() {
        this.Interval = setInterval(_ => {
            $('#logininputpass').focus();
        }, 100);
        document.addEventListener("keypress", this.handleKeyPress, false);
    }

    componentWillUnmount() {
        $('#logininputpass').blur();
        clearInterval(this.Interval);
        document.removeEventListener("keypress", this.handleKeyPress, false);
    }

    handleKeyPress = e => {
        if (e.keyCode === 13)
            this.sendPass();
    }

    sendPass() {
        const { input } = this.state;
        const pass = input;
        this.setState({ input: '', }, () => { this.props.handleClickPassword(pass) });
    }

    sleep = (milliseconds) => {
        return new Promise(resolve => setTimeout(resolve, milliseconds))
    }

    onKeyPress = (button) => {
        if (button === "{lock}")
            this.handleShift();
        if (button === '{close}')
            this.sleep(200).then(_ => {
                this.props.run('poweroff', 'up');
            });
        if (button === '{enter}') {
            this.sleep(200).then(_ => {
                this.props.run('reboot', 'up');
            });
        }
    }

    changeInputType() {
        let { inputType } = this.state;
        if (inputType === 'password')
            inputType = 'text';
        else inputType = 'password'
        this.setState({ ...this.state, inputType })
    }

    onChangeInput = event => {
        const input = event.target.value;
        this.setState({ ...this.state, input },
            () => {
                this.keyboard.setInput(input);
            }
        );
    };

    handleShift = () => {
        const { layout } = this.state;
        this.setState({
            ...this.state,
            layout: layout === "default" ? "lock" : "default"
        });
    };


    render() {
        const { input, inputType, layout } = this.state;
        return (
            <div className={'keyboradInputPass'}>
                <div style={{ margin: '40px' }}>
                    <button className={'btn btn-lg'} style={{ color: 'white', float: 'right', backgroundColor: '#9CB4D7', marginBottom: '20px', marginRight: '65%', marginTop: '50px', borderRadius: '15px' }} onClick={() => { this.sendPass() }}>Login</button>
                    <input autoComplete={"off"} id={'logininputpass'} ref={input => input && input.focus()} placeholder={'Password'}
                        type={'text'} value={input} style={{
                            borderRadius: '15px',
                            float: 'left',
                            border: '2px solid #9cb4d7',
                            paddingLeft: '10px',
                            WebkitTextSecurity: inputType === 'password' ? 'disc' : ''

                        }}
                        onChange={e => this.onChangeInput(e)} />
                    {inputType === 'password' ?
                        <VisibilityIcon
                            onClick={() => this.changeInputType()} style={VisibilityStyle} /> :
                        <VisibilityOffIcon
                            onClick={() => this.changeInputType()} style={VisibilityStyle}
                        />}
                </div>
                <br />
                <div style={{
                    width: '70%',
                    margin: '0 auto'
                }}>
                    <Keyboard
                        keyboardRef={r => (this.keyboard = r)}
                        theme={"my-theme-pass hg-theme-default hg-layout-default"}
                        layoutName={layout}
                        layout={{
                            'default': [
                                '` 1 2 3 4 5 6 7 8 9 0 - = {bksp}',
                                '{tab} q w e r t y u i o p [ ] \\',
                                '{lock} a s d f g h j k l ; \' {enter}',
                                '@ z x c v b n m , . / {close}',
                                '{space}'
                            ],
                            'lock': [
                                '~ ! @ # $ % ^ & * ( ) _ + {bksp}',
                                '{tab} Q W E R T Y U I O P { } |',
                                '{lock} A S D F G H J K L : " {enter}',
                                '@ Z X C V B N M < > ? {close}',
                                '{space}'
                            ]
                        }}
                        buttonTheme={[
                            {
                                class: "hg-red-pass",
                                buttons: "{close}"
                            },
                            {
                                class: "hg-red-pass",
                                buttons: "{enter}"
                            },
                        ]}
                        display={{
                            '{bksp}': 'BackSpace',
                            '{enter}': 'Reboot',
                            '{tab}': 'Tab',
                            '{close}': 'PowerOff',
                            '{space}': 'Space',
                            '{lock}': 'Caps Lock'
                        }}
                        onChange={input =>
                            this.onChange(input)}
                        onKeyPress={button =>
                            this.onKeyPress(button)}
                    />
                </div>
            </div>
        );
    }
}

export default Login;