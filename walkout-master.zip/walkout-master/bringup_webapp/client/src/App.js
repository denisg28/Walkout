import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'jquery/dist/jquery.min.js'
import 'bootstrap/dist/js/bootstrap.min.js'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';
import IndexInit from './Init/Components/IndexInit';
import NotFoundPage from './NotFoundPage/NotFoundPage';
import io from 'socket.io-client'
const socket = io('http://localhost:3001');

/**
 * App component that handle all the app 
 */
class App extends Component {

    render() {
        return (
            <Router>
                {document.addEventListener('contextmenu', e => e.preventDefault())}
                {document.getElementById('root').addEventListener('wheel', event => {
                    if (event.ctrlKey)
                        event.preventDefault()
                }, true)}
                {document.addEventListener('keydown', e => {
                    const keys = [ 65, 68, 69, 70, 71, 72, 74, 75, 76, 79, 80, 82, 83, 85, 191, 107, 109 ]
                    if (e.keyCode === 123 || e.keyCode === 122 || e.keyCode === 116) { // Prevent F12 & F11
                        e.preventDefault();
                        return false;
                    }
                    else if (e.ctrlKey && e.shiftKey) { // Prevent Ctrl+Shift - keys       
                        e.preventDefault();
                        return false;
                    }
                    else if (e.ctrlKey && keys.includes(e.keyCode)) {
                        e.preventDefault();
                        return false;
                    }
                })}
                <Switch>
                    <Route exact path="/">
                        <IndexInit socket={ socket } />
                    </Route>
                    <Route component={ NotFoundPage } />
                </Switch>
            </Router>
        );
    }
}

export default App;
