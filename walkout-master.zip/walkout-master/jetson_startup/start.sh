#!/bin/bash

export PATH=/usr/local/cuda-10.0/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda-10.0/lib64:$LD_LIBRARY_PATH

source $HOME/py3_env/bin/activate

export PYTHONPATH=/usr/local/walkout
PYTHONPATH=/usr/local/walkout/ourFirstCNN:$PYTHONPATH

# mount SD card to walkout/../sd_card
save_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
save_dir+="/../../sd_card"
mkdir -p ${save_dir}
sudo mount /dev/mmcblk2p1 ${save_dir}

# Sound card settings - moved to /etc/pulse/default.pa
# pactl set-default-sink alsa_output.usb-Generic_USB2.0_Device_20130100ph0-00.analog-stereo

WALKOUT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/../"
python3 ${WALKOUT_DIR}/utils/generate_run_config.py

# start NodeJS server
pushd ${WALKOUT_DIR}/webapp/server/
yarn
yarn start
#popd
