#!/bin/bash

# stop NodeJS server
popd
pkill -f node