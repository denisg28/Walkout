# importing the requests library
import requests
from datetime import date, timedelta, datetime
import json
import sys


class CloudApi():
    def __init__(self, user, password):
        self.playground_url = "https://database-staging.walkout.co"
        self.url = "http://database.walkout.co"
        auth = requests.post(url='{}/auth/login'.format(self.url),
                             json={'email': user, 'password': password})
        if auth.status_code != 200:
            print(auth.json())
            sys.exit(1)
        self.jwt = auth.cookies['jwt']

    def create_predefined_list(self, body):
        """
            post a list of predefined lists (can be one list too)
            @params: body - list of predefined lists
        """
        if type(body) != list or len(body) == 0:
            print('Not A valid type of body, exepted non empty list')
            return
        req = requests.post(url="{}/api/predefined_lists".format(
            self.url), json=body, cookies={'jwt': self.jwt})
        print(req.json())
        if req.status_code != 200:
            sys.exit(1)

    def delete_predefined_list(self, id):
        """
            delete an list form server by id
            @params: id - the id of the list
        """
        req = requests.delete(url="{}/api/predefined_lists/{}".format(
            self.url, id), cookies={'jwt': self.jwt})
        print(req.json())


def generate_target_date(delta):
    """
        function that calculate target date by delta days
        @params: delta - get days after today by delta days i.e: 1 - give me tomorrow date
        @return: target date with template yyyy-mm-dd
    """
    target = date.today() + timedelta(days=delta)
    return str(target).split(' ')[0]


if __name__ == '__main__':

    api = CloudApi()
    target = generate_target_date(1)
    action = 'del'  # 'del' / 'write_one'
    if action == 'write_one':
        body = [{'id': 1000,
                 'purpose': 'test',  # can be 'test' or 'ob-single' or 'ob-pile'
                 # if destination dosent found, server will choose walkout by default
                 'destination': 'walkout',
                 # today date in format yyyy-mm-dd, if target_date dosent found, server will choose today date by default
                 # can use target function to generate
                 'target_date': str(datetime.now()).split(' ')[0],
                 "list_of_events": [
                     {
                         "event": 1,
                         "barcode": "4061458025256",
                         "direction": 1
                     },
                     {
                         "event": 2,
                         "barcode": "22141354",
                         "direction": -1
                     }]
                 }]

        api.create_predefined_list(body)
    elif action == 'del':
        api.delete_predefined_list('1000')
