#!/bin/bash

run_mode=$1
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

if [ "$run_mode" == "video" ] ; then
    printf "${GREEN}Running profiling in video mode\n${NC}"
elif [ "$run_mode" == "camera" ]; then
    printf "${GREEN}Running profiling in camera mode\n${NC}"
else
    printf "${RED}bad parameters given to script: run_nvidia_profiling.sh [video | camera] \n${NC}"
    exit
fi

export PATH=/usr/local/cuda-10.0/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda-10.0/lib64:$LD_LIBRARY_PATH
source $HOME/py3_env/bin/activate

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
export REPO=$DIR/../..
export PYTHONPATH=$REPO:$REPO/ourFirstCNN

if [ "$run_mode" == "video" ] ; then
    mkdir -p $REPO/movies
    aws s3 sync s3://walkout-main/cart_data/2020-08-17/walkout/debug_profiler_video_3/ $REPO/movies/
fi

cd $REPO

# Make sure jetson is in performance mode
sudo nvpmodel -m 0
sudo jetson_clocks

if [ "$run_mode" == "video" ] ; then
    nvprof -f -o /tmp/prof_tx2_video.nvvp python $REPO/ourFirstCNN/run_motion_detect.py --video $REPO/movies/debug_2020-08-17-17_33_19_L.avi -c $REPO/user_files/shop_mode_profiling.yaml
elif [ "$run_mode" == "camera" ]; then
    nvprof -f -o /tmp/prof_tx2_camera.nvvp python $REPO/ourFirstCNN/run_motion_detect.py -c $REPO/user_files/shop_mode_profiling.yaml
fi