import random
import time
import ctypes
from collections import defaultdict
import numpy as np
from config import config

class InlineTimer():

    def __init__(self):
        self.timers = defaultdict(list)
        self.start_timers = {}

    def append_timer(self, timer_name, time_to_add):
        self.timers[timer_name].append(time_to_add)

    def start_timer(self, timer_name):
        curr_value = self.start_timers.get(timer_name)
        if curr_value is not None:
            print("Timer for {} was overriden!".format(timer_name))

        self.start_timers[timer_name] = time.time()

    def end_timer(self, timer_name):
        curr_value = self.start_timers.get(timer_name)
        if curr_value is None:
            print("Timer for {} is missing the start timer!".format(timer_name))
        else:
            self.start_timers.pop(timer_name)
            self.append_timer(timer_name, time.time() - curr_value)

    def print_single_timer_summary(self, timer_name, average_total_fps=None):
        values_list = self.timers.get(timer_name)
        num_measures = len(values_list)
        num_measures_print = "num_measures={},\t".format(num_measures)
        avg = sum(values_list) / num_measures
        avg_print = "avg[ms]= {:.3f},\t".format(avg *1000)
        min_print = "min[ms]= {:.3f},\t".format(min(values_list)*1000)
        max_print = "max[ms]= {:.3f},\t".format(max(values_list)*1000)
        p95_print = "p95[ms]= {:.3f},\t".format(np.percentile(values_list, 95)*1000)
        sum_print = "total[ms]= {:.3f}".format(sum(values_list)*1000)
        median_print = "median[ms]= {:.3f},\t".format(np.median(values_list)*1000)
        percent_of_cycle = "" if average_total_fps is None else " percent= {:.3f}%,   \t".format((avg / (1 / average_total_fps)) * 100)
        timer_name_print = "{0: <20}".format(timer_name[0:20])
        print("{}:     {} {} {} {} {} {} {} {}"
              .format(timer_name_print,
                      avg_print,
                      percent_of_cycle,
                      p95_print,
                      median_print,
                      min_print,
                      max_print,
                      num_measures_print,
                      sum_print))

    def print_summary(self, print_frames_hist=False):
        for timer_name in self.timers.keys():
            self.print_single_timer_summary(timer_name)
        if print_frames_hist:
            self.plot_2_arrays_hist("frame-during-event", "frame")

    def plot_2_arrays_hist(self, first_timer_name, second_timer_name):
        import matplotlib.pyplot as plt
        if self.timers.get(first_timer_name) is not None: plt.hist(1000 * np.array(self.timers.get(first_timer_name)), bins=25, alpha=0.5, label=first_timer_name)
        if self.timers.get(second_timer_name) is not None: plt.hist(1000 * np.array(self.timers.get(second_timer_name)), bins=25, alpha=0.5, label=second_timer_name)
        plt.legend(loc='upper right')
        plt.show()


class VoidProfiler(object):
    def __init__(self):
        pass

    def start_session(self):
        pass

    def start_block(self, block_name):
        pass

    def stop_block(self, block_name):
        pass

    def finish_session(self):
        pass

class NVProfiler(VoidProfiler):
    def __init__(self):
        import cupy
        self.cuda = cupy.cuda
        if config.JETSON_EMBEDDED_SYSTEM:
            self.nvToolsExt = ctypes.CDLL(
                '/usr/local/cuda/targets/aarch64-linux/lib/libnvToolsExt.so')
        else:
            self.nvToolsExt = ctypes.CDLL(
                '/usr/local/cuda/targets/x86_64-linux/lib/libnvToolsExt.so')
        self.color_idx = 1
    
    def increment_idx(self):
        self.color_idx +=1
        if self.color_idx > 9:
            self.color_idx = 1



    def start_session(self):
        start_message = "Walkout Init Profiling"
        self.nvToolsExt.nvtxMarkA(ctypes.c_char_p(start_message.encode("ascii")))
        self.inline_timer = InlineTimer()

    def start_block(self, block_name):
        self.cuda.nvtx.RangePush(block_name, self.color_idx)
        self.inline_timer.start_timer(block_name)
        self.increment_idx()

    def stop_block(self, block_name):
        self.cuda.nvtx.RangePop()
        self.inline_timer.end_timer(block_name)

    def finish_session(self):
        finish_message = "Walkout Finish Profiling"
        self.nvToolsExt.nvtxMarkA(ctypes.c_char_p(finish_message.encode("ascii")))
        self.inline_timer.print_summary()
        self.cuda.profiler.stop()