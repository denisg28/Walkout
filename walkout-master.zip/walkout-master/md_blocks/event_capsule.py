from config import config
import os
from cv_blocks.video_writer.video_writer import VideoWriter, OpenCVGsteamerVideoWriter, ExactVideoWriter
from .md_state import MdState
import misc
import json
from queue import Queue
import numpy as np
import datetime
import enum

"""
should we support capsules with different :
self.cart_calib
self.cart_config
self.cart_th_img
self.catalog
CNNs ?
"""


class EventCapsule:
    def __init__(self, capsule_type, camera_id, 
                 movie_name=None, camera_info=None, id=None,
                 state=None, path=None, gt_frame=None, session_id=None):

        self.capsule_type = capsule_type
        if id is None:
            id = misc.getTimeAndDate()
        frame = gt_frame if gt_frame is not None else state.frame_num
        name = "capsule_id_" + str(id) +"_frame_" + str(frame)
        if path is not None:
            root_dir = path.replace('.pkl', '_raw_capsules')
            capsule_dir = os.path.join(root_dir, name)
        elif movie_name is not None and movie_name!='':
            capsule_dir = os.path.join(config.MOVIES_PATH, '%s_capsules' % movie_name, name)
        else:
            today_dir = str(datetime.date.today())
            session_dir = 'shop_mode_log_%s_raw_capsules' % session_id
            capsule_dir = os.path.join(config.MOVIES_PATH, today_dir, session_dir, name)
        os.makedirs(capsule_dir, exist_ok=True)

        self.path  = os.path.join(capsule_dir, name)
        self.capsule_dir = capsule_dir

        self.md_state = state
        self.md_state.save_state_to_disk(capsule_dir)

        self.video_writer = self.init_video_writer(camera_id, camera_info, self.path)
        self.log = dict(capsule_type=self.capsule_type, start_frame=state.frame_num)
        print('\033[93m', "starting event capsule: frame {}".format(state.frame_num), '\033[0m', flush=True)

    def init_video_writer(self,camera_id,camera_info, path):
        # Initialize video writer
        if config.JETSON_EMBEDDED_SYSTEM and config.GPU_VIDEO_ENCODER:
            video_writer = OpenCVGsteamerVideoWriter(camera_id,camera_info, path)
        else:
            # video_writer = ExactVideoWriter(camera_id, camera_info, path)
            video_writer = VideoWriter(camera_id, camera_info, path)
        return video_writer
    
    def update_log(self, key, val):
        self.log[key] = val

    def finish(self,frame_num):
        self.log['end_frame'] = frame_num
        self.log['total_frame_duration'] = frame_num - self.log["start_frame"]

        # Save GT for barcode event
        if self.capsule_type=='barcode':
            self.log['gt'] = self.infer_gt()

        # save stuff
        with open(self.path + '_metadata.json', 'w') as fp:
            json.dump(self.log, fp)
        print('\033[93m', "Saving event capsule:frame {}-> {}".format(frame_num, self.capsule_dir), '\033[0m', flush=True)

    def infer_gt(self):
        event_frame = (self.log['start_frame'] + self.log['end_frame']) // 2
        product = self.log['scanned_barcode'] if 'scanned_barcode' in self.log else None
        # TODO - get more data (direction/product) from algo
        return [dict(product=product, direction='in', frame=event_frame)]

    def get_video_writer(self):
        return self.video_writer

class CapsuleManagerState(enum.Enum):
    Idle = -1
    DuringCapsuleRecord = 1
    DuringCapsuleRecordPost = 2
    DuringCapsuleClose = 3

class EventCapsuleManger(object):
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.capsule_pre_frames = config.get('capsule_pre_frames', 5)
            self.capsule_post_frames = config.get('capsule_post_frames', 15)
            self.start_trigger = config.get('start_trigger', 'gt')
            self.stop_trigger = config.get('stop_trigger', 'gt')
            self.capsule_frames_gt_short_edge = config.get('capsule_frames_gt_short_edge', 20)
            self.capsule_frames_gt_long_edge = config.get('capsule_frames_gt_long_edge', 100)
            assert self.start_trigger in ('gt', 'barcode', 'algo')
            assert self.stop_trigger in ('gt', 'barcode', 'algo')

    def __init__(self, md_module, movie_name, ec_config=dict()):
        self.params = self.Config(ec_config)
        self.event_capsule = None
        # self.event_capsule_triggred = False
        self.state = CapsuleManagerState.Idle
        self.event_capsule_frames_buffer = Queue()
        self.event_capsule_state_buffer = Queue()
        self.md_module = md_module
        self.gt_trigger = self.use_gt_as_capsule_trigger(movie_name)
        self.capsule_post_count = 0
        self.gt_event_frame = None
        if 'algo' in (self.params.start_trigger, self.params.stop_trigger):
            assert hasattr(self.md_module, 'cart_bottom_detector')
        if 'barcode' in (self.params.start_trigger, self.params.stop_trigger):
            assert hasattr(self.md_module, 'barcode_handler')
        
    def is_active(self):
        return self.state!=CapsuleManagerState.Idle
    
    def use_gt_as_capsule_trigger(self, movie_name):
        if movie_name is None or not (self.params.start_trigger=='gt' and self.params.stop_trigger=='gt'):
            return None
        gt_failure_file = movie_name + '_L.failure.csv'
        gt_all_file = movie_name + '_L.csv'
        # First check for failure failure 
        gt_file = gt_failure_file if os.path.exists(gt_failure_file) else \
            gt_all_file if os.path.exists(gt_all_file) else None
        if gt_file is None:
            return None
        import pandas as pd
        event_list = pd.read_csv(gt_file)
        event_list['capsule_start'] = event_list['frame']
        event_list['capsule_end'] = event_list['frame']
        event_list.loc[event_list['direction']=='in', 'capsule_start'] -= self.params.capsule_frames_gt_short_edge
        event_list.loc[event_list['direction']=='in', 'capsule_end'] += self.params.capsule_frames_gt_long_edge
        event_list.loc[event_list['direction']=='out', 'capsule_start'] -= self.params.capsule_frames_gt_long_edge
        event_list.loc[event_list['direction']=='out', 'capsule_end'] += self.params.capsule_frames_gt_short_edge
        # Make sure not overlap in events
        max_capsule_end = event_list.loc[:, 'capsule_start'].shift(-1) - 1
        event_list.loc[~max_capsule_end.isnull(), 'capsule_end'] = event_list.loc[~max_capsule_end.isnull(), 'capsule_end'].clip(0, max_capsule_end)
        min_capsule_start = event_list.loc[:, 'capsule_end'].shift(1) + 1
        event_list.loc[~min_capsule_start.isnull(), 'capsule_start'] = event_list.loc[~min_capsule_start.isnull(), 'capsule_start'].clip(min_capsule_start, np.inf)
        return event_list

    def should_start_capsule(self):
        if self.state!=CapsuleManagerState.Idle:
            return False
        # GT based trigger
        if self.params.start_trigger=='gt':
            trigger = self.md_module.global_frame_num in self.gt_trigger['capsule_start'].tolist()
            if trigger:
                self.gt_event_frame = \
                    self.gt_trigger.loc[self.gt_trigger.index[self.gt_trigger['capsule_start']==self.md_module.global_frame_num][0], 'frame']
            return trigger
        # Algo based trigger
        elif self.params.start_trigger=='algo':
            if hasattr(self.md_module, 'cart_bottom_detector'):
                return self.md_module.cart_bottom_detector.is_during_event()
            else:
                return self.md_module.mv_manager.is_active()
        # Barcode based trigger
        elif self.params.start_trigger=='barcode':
            return (not self.md_module.barcode_handler.is_idle()) and \
                self.md_module.barcode_handler.active_event_type()=='user'

    def should_stop_capsule(self):
        if self.state!=CapsuleManagerState.DuringCapsuleRecord:
            return False
        # GT based trigger
        if self.params.stop_trigger=='gt':
            return self.md_module.global_frame_num in self.gt_trigger['capsule_end'].tolist()
        # Algo based trigger
        elif self.params.stop_trigger=='algo':
            if hasattr(self.md_module, 'cart_bottom_detector'):
                return self.md_module.cart_bottom_detector.is_event_done()
            else:
                return not self.md_module.mv_manager.is_active()
        # Barcode based trigger
        elif self.params.stop_trigger=='barcode':
            return self.md_module.barcode_handler.is_idle()
    
    def step(self):
        # update state every cycle !! ( maybe too compute intensive)
        md_state = MdState(self.md_module)


        self.event_capsule_state_buffer.put(md_state)
        if self.event_capsule_state_buffer.qsize() > self.params.capsule_pre_frames:
            md_state = self.event_capsule_state_buffer.get()

        should_start = False
        should_stop = False
        if self.state==CapsuleManagerState.DuringCapsuleRecordPost:
            self.capsule_post_count = self.capsule_post_count - 1 
            if self.capsule_post_count==0:
                self.state = CapsuleManagerState.DuringCapsuleClose
        elif self.state==CapsuleManagerState.Idle:
            should_start = self.should_start_capsule()
            if should_start:
                self.state = CapsuleManagerState.DuringCapsuleRecord
        elif self.state==CapsuleManagerState.DuringCapsuleRecord:
            should_stop = self.should_stop_capsule()
            if should_stop:
                self.state = CapsuleManagerState.DuringCapsuleRecordPost
                self.capsule_post_count = self.params.capsule_post_frames + self.params.capsule_pre_frames

        if should_start:
            # Start new capsule
            movie_name = self.md_module.stream.get_movie_name()
            logger_path = self.md_module.algo_logger.filename if hasattr(self.md_module, 'algo_logger') \
                and self.md_module.algo_logger is not None else None
            capsule_type = self.get_capsule_type()
            self.event_capsule = EventCapsule(capsule_type,
                                              camera_id = self.md_module.cart_calib.config_id,
                                              movie_name = movie_name,
                                              camera_info = self.md_module.cart_config['camera_info'],
                                              state = md_state,
                                              path = logger_path,
                                              gt_frame = self.gt_event_frame, 
                                              session_id = self.md_module.system_init_ts)
            self.video_writer = self.event_capsule.get_video_writer()
        
        if self.state in (CapsuleManagerState.DuringCapsuleRecord, CapsuleManagerState.DuringCapsuleRecordPost):
            # Write single item from queue
            if self.event_capsule_frames_buffer.qsize() > 0:
                frameL, frameR, frameB = self.event_capsule_frames_buffer.get()
                self.video_writer.write_images(frameL,frameR,frameB)
        elif self.state==CapsuleManagerState.DuringCapsuleClose:
            #close event capsule
            self.event_capsule.finish(self.md_module.global_frame_num)
            del self.video_writer
            self.event_capsule = None
            self.state = CapsuleManagerState.Idle
        
        # Check other modules to update log
        if self.state!=CapsuleManagerState.Idle:
            self.check_for_updates()
    
    def close(self):
        if self.event_capsule is not None:
            #close event capsule
            self.event_capsule.finish(self.md_module.global_frame_num)
            del self.video_writer
            self.event_capsule = None
            self.state = CapsuleManagerState.Idle

    def get_capsule_type(self):
        '''
        Place holder for more complex inference of type:
        - vision mode insert/remove
        - MSCO mode insert/remove
        - MSCO mode adverserial insert/remove
        TODO: implement
        '''
        if self.params.start_trigger=='barcode':
            return 'barcode'
        else:
            return 'vision'


    def store_frames(self, data):
        data_cp = tuple([d.copy() for d in data])
        self.event_capsule_frames_buffer.put(data_cp)
        if self.event_capsule_frames_buffer.qsize() > self.params.capsule_pre_frames:
            self.event_capsule_frames_buffer.get()

    def update_log(self, key, val, overwrite=False):
        if self.event_capsule is not None:
            if overwrite or key not in self.event_capsule.log:
                self.event_capsule.update_log(key, val)
    
    def check_for_updates(self):
        if self.params.start_trigger=='barcode':
            # Barcode read
            if self.md_module.barcode_handler.curr_barcode_event is not None:
                bc_ev = self.md_module.barcode_handler.curr_barcode_event
                if 'scanned_barcode' in bc_ev:
                    self.update_log('scanned_barcode', bc_ev['scanned_barcode'])
                    if 'barcode_frame' in bc_ev:
                        # Try to get more accurate frame number of barcode scan
                        # Real-time capsule recording may have frames skips, that are not compensated in the recording
                        # Some of the frames between barcode scan (last queued frame) and curr MD processed frame
                        # May stil be skipped, but this is a more accurate estimation
                        if self.event_capsule is not None and hasattr(self.event_capsule, 'video_writer'):
                            barcode_to_md_delay = int(bc_ev['barcode_frame'] - self.md_module.global_frame_num)
                            frame_in_video = int(self.event_capsule.video_writer.frame() + barcode_to_md_delay)
                            frame_with_offset = frame_in_video + self.event_capsule.log['start_frame']
                            self.update_log('barcode_frame', frame_with_offset)
                        else:
                            self.update_log('barcode_frame', bc_ev['barcode_frame'])
            

