import argparse
import os
import cv2
from cv_blocks.misc.logger import BaseLogger


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Convert Syncer capsules to ')
    parser.add_argument('--log-file', help='path to capsulue file',type=str, required=True)
    parser.add_argument('--output-dir', help='path to directory to write output', required=True)
    args = parser.parse_args()
    assert os.path.exists(args.log_file)
    os.makedirs(args.output_dir, exist_ok=True)

    my_logger = BaseLogger(True, include_barocde=True)
    el_list = my_logger.from_data(args.log_file)

    # Get GT per event
    session_name = os.path.splitext((os.path.basename(args.log_file)))[0]
    all_prod_info = dict()
    events = []
    for el in el_list:
        if el['type'] == 'user_marked_event' and el['element'].event_type=='EventAnnotated':
            gt_product_code = el['element'].metadata['resolution']
            event_id = el['element'].event_id
            if gt_product_code not in all_prod_info:
                all_prod_info[gt_product_code] = [event_id]
            else:
                all_prod_info[gt_product_code].append(event_id)
    
    # Parse visual events into images
    for prod_name, prod_events in all_prod_info.items():
        product_n_images = 0
        prod_sub_dir = os.path.join(args.output_dir, prod_name)
        os.makedirs(prod_sub_dir, exist_ok=True)
        for el in el_list:
            if el['type'] == 'event_aggregator_out':
                event_id = el['element'].data['event_id']
                if event_id in prod_events:
                    # Save images to directory
                    for mv_el in el['element'].data['movement_vector']:
                        img_type = 'cart_bottom_rgb' if mv_el.source=='CB' else \
                            'front_wnoise_crop' if mv_el.cam_name=='front' else 'back_rgb_crop'
                        img_name = 'product_classifier_%s_%s_event_id_%d_frame_%d_cam_%s_source_%s_cls_%s.png' % \
                        (img_type, session_name, event_id, mv_el.global_frame_number , mv_el.cam_name, mv_el.source, prod_name)
                        img_dir = os.path.join(prod_sub_dir, img_type)
                        os.makedirs(img_dir, exist_ok=True)
                        img_data = cv2.cvtColor(mv_el.cropped_image, cv2.COLOR_RGB2BGR)
                        cv2.imwrite(os.path.join(img_dir, img_name), img_data)
                        product_n_images += 1
        print('Saved %d product images product: %s' % (product_n_images, prod_name))