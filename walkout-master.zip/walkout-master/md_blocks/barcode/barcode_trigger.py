import enum
import numpy as np
from md_blocks.barcode.barcode_handler import BarcodeHandlerEvent

class BarcodeTriggerState(enum.Enum):
    Idle = -1
    MaybeScan = 1
    TriggerScan = 2
    DuringScan = 3
    PostScan = 4

class BarcodeTrigger:
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.num_frames_obj_is_maybe_close = config.get('num_frames_obj_is_maybe_close', 2)
            self.num_frames_obj_is_close = config.get('num_frames_obj_is_close', 4)
            self.num_frames_obj_is_static = config.get('num_frames_obj_is_static', 2)
            self.cam_static_th = config.get('cam_static_th', dict(front=0.03, back=0.01))
            self.min_dist_from_cam_to_consider_valid = config.get('min_dist_from_cam_to_consider_valid', 0.2)
            self.enable_trigger_n_frames_after_last_event = config.get('enable_trigger_n_frames_after_last_event', 60)

    def __init__(self, md_module, debug=False, bt_config=dict()):
        self.params = self.Config(bt_config)
        self.md_module = md_module
        self.state = BarcodeTriggerState.Idle
        self.near_obj_counter = 0
        self.static_obj_counter = 0
        self.debug = True#debug
    
    def reset(self):
        self.state = BarcodeTriggerState.Idle
        self.near_obj_counter = 0
        self.static_obj_counter = 0

    def step(self):
        '''
        Entry point to barcode trigger
        '''
        # Get indication from MD Module
        # =============================
        trigger_indications = self.check_indications()

        # Propagate state
        # ===============
        next_state = self.get_next_state(trigger_indications)

        # Trigger barcode scanner
        # =======================
        if next_state==BarcodeTriggerState.TriggerScan and self.state!=next_state:
            if hasattr(self.md_module, 'gui'):
                self.md_module.gui.scan_item_with_barcode()
            else:
                user_trigger = {'cmd':'barcode_event_info', \
                                    'payload': {'msg_type': 'new_event_request', 'trigger': 'user'}}
                self.md_module.barcode_handler.write_message(user_trigger)

        self.state = next_state

    def get_next_state(self, trigger_indications):
        '''
        Logic defining transition between states according to indications
        '''
        next_state = self.state

        # update indictation counters
        self.near_obj_counter = self.near_obj_counter + 1 if trigger_indications['near_obj'] else 0
        self.static_obj_counter = self.static_obj_counter + 1 if trigger_indications['static_obj'] else 0

        # If other process triggered barcode, go to During scan 
        bc_handler_active = not self.md_module.barcode_handler.is_idle()
        if bc_handler_active and self.state not in (BarcodeTriggerState.DuringScan, BarcodeTriggerState.TriggerScan):
            next_state = BarcodeTriggerState.DuringScan

        elif self.state==BarcodeTriggerState.Idle:
            cond_idle_to_maybe = self.near_obj_counter >= self.params.num_frames_obj_is_maybe_close
            next_state = BarcodeTriggerState.MaybeScan if  cond_idle_to_maybe else BarcodeTriggerState.Idle
        elif self.state==BarcodeTriggerState.MaybeScan:
            cond_maybe_to_trigger = self.near_obj_counter>=self.params.num_frames_obj_is_close and \
                self.static_obj_counter>=self.static_obj_counter>=self.params.num_frames_obj_is_static and \
                self.md_module.global_frame_num - self.md_module.barcode_handler.last_mode_close_frame > self.params.enable_trigger_n_frames_after_last_event
            cond_maybe_to_idle = self.near_obj_counter==0
            next_state = BarcodeTriggerState.TriggerScan if cond_maybe_to_trigger else \
                         BarcodeTriggerState.Idle if cond_maybe_to_idle else \
                         BarcodeTriggerState.MaybeScan 
        elif self.state==BarcodeTriggerState.TriggerScan:
            # only barcode handler can transition
            cond_trigger_to_during = self.md_module.barcode_handler.is_pending_scan()
            next_state = BarcodeTriggerState.DuringScan if cond_trigger_to_during else BarcodeTriggerState.TriggerScan
        elif self.state==BarcodeTriggerState.DuringScan:
            # only barcode handler can transition
            cond_during_to_post = self.md_module.barcode_handler.is_idle()
            next_state = BarcodeTriggerState.PostScan if cond_during_to_post else BarcodeTriggerState.DuringScan
        elif self.state==BarcodeTriggerState.PostScan:
            cond_post_to_idle = not (trigger_indications['near_obj'] or trigger_indications['static_obj']) and \
                self.md_module.global_frame_num - self.md_module.barcode_handler.last_mode_close_frame > self.params.enable_trigger_n_frames_after_last_event
            next_state = BarcodeTriggerState.Idle if cond_post_to_idle else BarcodeTriggerState.PostScan
        if self.debug and (next_state!=self.state):
            print('BarcodeTrigger DEBUG[%d]: state transition: (%s-> %s)' \
                % (self.md_module.global_frame_num, self.state, next_state), flush=True)
        return next_state
    
    def check_indications(self):
        '''
        Check for barcode trigger indications:
        - nearby/large object
        - static object
        '''
        if self.state in (BarcodeTriggerState.TriggerScan, BarcodeTriggerState.DuringScan):
            return dict(near_obj=False, static_obj=False)
        if not hasattr(self.md_module, 'global_frame_num'):
            return dict(near_obj=False, static_obj=False)
        curr_frame = self.md_module.global_frame_num


        # Check if object is near front camera
        near_obj=False
        static_obj=False
        mv_candidate = dict()
        mv_ids = dict()
        for cam_name, barcode_roi in self.md_module.barcode_handler.initial_barcode_roi.items():
            best_mv_id, best_box = self.md_module.mv_manager.match_mv_to_roi(cam_name, barcode_roi)
            if best_mv_id is None:
                continue
            possible_candidate = self.md_module.mv_manager.get_mv_by_id(cam_name, best_mv_id)
            last_el = possible_candidate.tail()
            if cam_name=='front' and last_el.depth is not None:
                # Check if box is very close
                cart_calib = self.md_module.cart_calib
                disp_scale = cart_calib.conf_data['disparity']['scale']
                mv_cam = cart_calib.sensors[cam_name]
                uv = last_el.coords.renormalize(320, 240).centroid()
                xyz = mv_cam.uvdisp2xyz(uv, last_el.depth, disp_scale=disp_scale)
                dist_from_cam = np.linalg.norm(xyz)
                very_near_by_disparity = dist_from_cam < self.params.min_dist_from_cam_to_consider_valid
                if not very_near_by_disparity:
                    continue

            if self.md_module.barcode_handler.box_in_barcode_roi(best_box, cam_name, check_coverage=cam_name!='front'):
                mv_candidate[cam_name] = self.md_module.mv_manager.get_mv_by_id(cam_name, best_mv_id)
                mv_ids[cam_name] = best_mv_id

        # if self.debug and len(mv_ids) >= 1:
        #     print('BarcodeTrigger DEBUG[%d]: mv_id_candidates: ' % self.md_module.global_frame_num, mv_ids, flush=True)
        #     for _,v  in mv_candidate.items():
        #         print('BarcodeTrigger DEBUG[%d]: state: ', v.state , flush=True)

        valid_cams = [cam_name for cam_name, mv in mv_candidate.items() if mv.tail().global_frame_number>=curr_frame-1]
        # if self.debug and len(valid_cams) >= 1:
        #     print('BarcodeTrigger DEBUG[%d]: valid_cams: ' % self.md_module.global_frame_num, valid_cams, flush=True)
        if len(valid_cams) > 1: # require 2 cams for trigger
            # TODO - check for recency of frames in MV -> near_obj = True
            near_obj = True # TODO
            if near_obj:
                for cam_name in valid_cams:
                    cam_mv = self.md_module.mv_manager.get_cam_mvs(cam_name)
                    if self.md_module.mv_manager.check_if_bbox_is_static(mv_ids[cam_name], cam_mv, last_n=3, \
                        dist=self.params.cam_static_th[cam_name]):
                        static_obj = True
                        break
            return dict(near_obj=near_obj, static_obj=static_obj)
        else:
            # TODO
            return dict(near_obj=False, static_obj=False)

        