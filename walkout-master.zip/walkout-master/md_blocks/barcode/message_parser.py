import enum

class BarcodeHandlerEvent(enum.Enum):
    Empty = -1
    NewEventRequest = 1
    InitEvent = 2
    SetBarcodeMode = 3
    BarcodeScanned = 4
    ProductRemoved = 5
    CloseEventRequest = 6
    FinishEvent = 7
    ItemActivityMarked = 8
    # Internal Events
    BarcodeScanSuccess = 11
    BarcodeScanFailure = 12
    InsertionSuccess = 13
    InsertionFailure = 14
    RemovalSuccess = 15
    RemovalFailure = 16
    BarcodeModeReady = 17
    DefaultModeReady = 18

msg2enum_map = dict(new_event_request=BarcodeHandlerEvent.NewEventRequest,
                    init_event=BarcodeHandlerEvent.InitEvent, 
                    set_barcode_mode=BarcodeHandlerEvent.SetBarcodeMode,
                    barcode_scanned=BarcodeHandlerEvent.BarcodeScanned,
                    product_removed=BarcodeHandlerEvent.ProductRemoved,
                    close_event_request=BarcodeHandlerEvent.CloseEventRequest,
                    finish_event=BarcodeHandlerEvent.FinishEvent,
                    item_activity_marked=BarcodeHandlerEvent.ItemActivityMarked,
)
enum2msg_map = {v:k for k, v in msg2enum_map.items()}

def parse_message(raw_message):
    assert isinstance(raw_message, dict) and raw_message['cmd']=='barcode_event_info'
    message = raw_message['payload']
    # convert message type to enum
    event = msg2enum_map[message['msg_type']]
    metadata = message
    return event, metadata

def compose_message(event, metadata):
    raw_message = dict(cmd='barcode_event_info', payload=metadata)
    msg_type = enum2msg_map[event]
    raw_message['payload']['msg_type'] = msg_type
    return raw_message