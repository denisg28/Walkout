import enum
import cv2
import numpy as np
from cv_blocks.common.types import BoundingBox2D
from cv_blocks.events.event_logic import EventType
from cv_blocks.events.event_similarity import event_vs_event_predictions_similar, event_vs_event_descriptors_similar
from md_blocks.md_messages import MDMessages
import traceback

class BarcodeHandlerState(enum.Enum):
    Idle = -1
    BarcodeTransitionUser = 1
    BarcodeTransitionInternal = 2
    BarcodePending = 3
    InsertionPending = 4
    RemovalPending = 5
    BarcodeFailed = 6
    BarcodeVerified = 7
    DefaultTransition = 8
    DefaultTransitionForced = 9
    ScanB4Remove = 10

from md_blocks.barcode.error_handler import BarcodeError, BarcodeWarning, BarcodeErrMessage, handle_invalid_close
from md_blocks.barcode.message_parser import parse_message, compose_message, BarcodeHandlerEvent

class BarcodeEventState(enum.Enum):
    # Initial state of insertion event where barcode triggered by algo
    PendingInside = 0
    # 3 possible cases:
    # 1. Initial state of removal event where barcode triggered by algo
    # 2. Initial state of user barcode trigger
    # 3. Algo triggered insertion, after removing product from cart
    PendingOutside = 1
    # After valid barcode scan, in all 3 cases (user, algo in, algo out)
    ScannedPendingOutside = 2
    # Final state of (user, algo in)
    VerifiedInside = 3
    # Final state algo out
    VerifiedOutside = 4
    # Final state of (user, algo in) & user marker
    VerifiedInsideMarked = 5

class BarcodeHandler:
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.target_fps_barcode = config.get('target_fps_barcode', 10)
            self.target_fps_default = config.get('target_fps_barcode', 20) # TODO
            self.scanner_gray = config.get('scanner_gray', True)
            self.scanner_img_shape = config.get('scanner_img_shape', (960, 1280))
            self.scanner_xlim = config.get('scanner_xlim', (0.25, 0.75))
            self.scanner_ylim = config.get('scanner_ylim', (0., 1.))
            self.activate_scanner_every_n_frames = config.get('activate_scanner_every_n_frames', 2)
            self.visualization_factor = config.get('visualization_factor', 1.)
            self.visualization_rot_op = config.get('visualization_rot_op', cv2.ROTATE_90_CLOCKWISE)
            self.visualization_xlim = config.get('visualization_xlim', (0., 1.))
            self.visualization_ylim = config.get('visualization_ylim', (0.25, 0.75))
            self.frame_diff_to_consider_still_scan_event = config.get('frame_diff_to_consider_still_scan_event', 10)
            self.iou_th_to_consider_during_scan = config.get('iou_th_to_consider_during_scan', 0.3)
            self.roi_coverage_th_to_consider_during_scan = config.get('roi_coverage_th_to_consider_during_scan', 0.5)
            self.item_coverage_th_to_consider_during_scan = config.get('item_coverage_th_to_consider_during_scan', 0.7)
            self.keep_marking_after_scan_n_frames = config.get('keep_marking_after_scan_n_frames', 10)
            self.barcode_crop_max_iou = config.get('barcode_crop_max_iou', 0.9)
            self.min_barcode_crop_area = config.get('min_barcode_crop_area', 0.01)
            self.use_auto_trigger = config.get('use_auto_trigger', False)
            self.viz_barcode_img = config.get('viz_barcode_img', False)
            self.max_barcode_crop_per_cam = config.get('max_barcode_crop_per_cam', 10)
            self.ignore_algo_trigger = config.get('ignore_algo_trigger', False)
            self.enable_marking_invalid_events = config.get('enable_marking_invalid_events', True)
            self.max_pending_events = config.get('max_pending_events', 2)
            self.allow_barcodes_out_of_catalog = config.get('allow_barcodes_out_of_catalog', False)
            self.marked_unrecognized_barcode_after_n_det = config.get('marked_unrecognized_barcode_after_n_det', 3)
            self.min_cls_supported_product_conf = config.get('min_cls_supported_product_conf', 1.0)
            self.disable_triggers_n_frames_around_scan = config.get('disable_triggers_n_frames_around_scan', 100)
            self.skip_similarity_validation = config.get('skip_similarity_validation', False)
            self.send_bc_err_to_cart = config.get('send_bc_err_to_cart', False)
            self.marker_event_frame_diff = config.get('marker_event_frame_diff', 40)

    def __init__(self, md_module, debug=False, logger=None, use_cam_scanner=True, 
                       product_validator=None, bh_config=dict()):

        self.params = self.Config(bh_config)
        self.state = BarcodeHandlerState.Idle
        self.next_message = dict(event=BarcodeHandlerEvent.Empty, metadata=None)
        self.debug = True#debug
        self.use_cam_scanner = use_cam_scanner
        if use_cam_scanner:
            from cv_blocks.barcode_scanner.barcode_scanner import BarcodeScanner
            self.barcode_scanner = BarcodeScanner(full_image_shape=self.params.scanner_img_shape,
                                                is_gray=self.params.scanner_gray,
                                                bbox=self.get_scanner_box())
        self.md_module = md_module
        self.should_skip_frame = False
        self.mode_change_triggered = False
        self.curr_barcode_event = None
        self.barcode_event_id = 0
        self.barcode_scanner_frame_counter = 0
        self.last_verified_barcode_frame = 0
        self.last_scanned_barcode_frame = 0
        self.last_mode_close_frame = 0
        self.pending_barcode_triggers = []
        self.external_markers = []
        self.barcode_visualization_img = None
        self.unfinished_events = []
        self.logger = logger
        if logger is not None:
            from cv_blocks.misc.logger import MarkedEventLogger
            self.mel = MarkedEventLogger
        # Init barcode automatic trigger
        if use_cam_scanner and self.params.use_auto_trigger:
            from md_blocks.barcode.barcode_trigger import BarcodeTrigger
            self.auto_detect_trigger = BarcodeTrigger(self.md_module)
        # Define online/offline scan-operator
        self.scan_operator = self.scan_barcode if hasattr(md_module, 'stream') and \
            md_module.self.stream.isRealTime else self.scan_barcode_offline
        self.barcode_inject = None # offline usage only
        if product_validator is not None:
            self.product_validator = product_validator
    
    def set_barcode_roi(self, cart_calib, default_roi=dict(front=[0.,0.25,1.,0.75], back=[0.16,0.1875,0.41,0.34])):
        barcode_roi = dict()
        for cam_name, cam_data in cart_calib.conf_data['camera_config'].items():
            if 'barcode_roi' in cam_data:
                barcode_roi[cam_name] = BoundingBox2D(cam_data[cam_name])
            else:
                # Initialize roi box according to default values
                barcode_roi[cam_name] = BoundingBox2D(default_roi[cam_name])
        self.initial_barcode_roi = barcode_roi

    def get_barcode_roi_params(self, cam):
        if not self.use_cam_scanner:
            return None
        if cam == 'front':
            return None
        barcode_roi_params = dict(barcode_roi=self.initial_barcode_roi[cam],
                                  iou_th_to_consider_during_scan=self.params.iou_th_to_consider_during_scan,
                                  roi_coverage_th_to_consider_during_scan=self.params.roi_coverage_th_to_consider_during_scan,
                                  item_coverage_th_to_consider_during_scan=self.params.item_coverage_th_to_consider_during_scan,
                                  check_coverage=cam != 'front')
        return barcode_roi_params

    def draw_barcode_roi(self, img, cam_name):
        image_h, image_w, _ = img.shape
        box = self.initial_barcode_roi[cam_name]
        color = (128, 128, 128) # gray
        xmin = int(box.x1*image_w)
        ymin = int(box.y1*image_h)
        xmax = int(box.x2*image_w)
        ymax = int(box.y2*image_h)
        cv2.rectangle(img, (xmin,ymin), (xmax,ymax), color, 2)

    def draw_scanned_boxes(self, img, cam_name, detector_boxes, detector_ids):
        if self.curr_barcode_event is None:
            return
        image_h, image_w, _ = img.shape
        color = (0, 0, 0) # black
        for mv_id, box in zip(detector_ids, detector_boxes):
            if mv_id in self.curr_barcode_event['scanned_mv_id'][cam_name]:
                xmin = int(box.x1*image_w)
                ymin = int(box.y1*image_h)
                xmax = int(box.x2*image_w)
                ymax = int(box.y2*image_h)
                cv2.rectangle(img, (xmin,ymin), (xmax,ymax), color, 2)
    
    def box_in_barcode_roi(self, box, cam_name, check_coverage=True):
        barcode_roi = self.initial_barcode_roi[cam_name]
        iou_condition = BoundingBox2D.iou(barcode_roi, box) > self.params.iou_th_to_consider_during_scan
        boxes_intersection = BoundingBox2D.intersection(barcode_roi, box)
        if check_coverage:
            coverage_condition = boxes_intersection > self.params.item_coverage_th_to_consider_during_scan * box.area() or \
                boxes_intersection > self.params.roi_coverage_th_to_consider_during_scan * barcode_roi.area()
        else:
            coverage_condition = False

        return iou_condition or coverage_condition
    
    def active_event_type(self):
        if self.curr_barcode_event is not None:
            return self.curr_barcode_event['trigger']
        else:
            return None
    
    def skip_barcode_event(self):
        if len(self.md_module.event_logic.special_item_handler.pending_verification_events['barcode']):
            self.md_module.event_logic.special_item_handler.pending_verification_events['barcode'].pop(0)
    
    def log_state_transition(self, state):
        return dict(state=state, frame=self.md_module.global_frame_num)
    
    def start_barcode_event(self, trigger):
        self.curr_barcode_event = dict(trigger=trigger)
        self.curr_barcode_event['trigger_frame'] = self.md_module.global_frame_num
        self.curr_barcode_event['barcode_frame'] = -1
        self.curr_barcode_event['barcode_input_method'] = 'manual'
        self.curr_barcode_event['last_event_id_compared'] = -1
        self.curr_barcode_event['scanned_mv_id'] = dict(front=[], back=[])
        self.curr_barcode_event['curr_error'] = None
        self.curr_barcode_event['all_errors'] = []
        self.curr_barcode_event['marked_event'] = False
        self.curr_barcode_event['external_close'] = None
        self.curr_barcode_event['product_img_during_scan'] = dict(front=[], back=[])
        self.curr_barcode_event['state_transitions'] = [self.log_state_transition(BarcodeHandlerState.Idle)]
        self.barcode_visualization_img = None
        if trigger=='internal':
            self.curr_algo_verified_event = self.md_module.event_logic.special_item_handler.pending_verification_events['barcode'].pop(0)
            direction = self.curr_algo_verified_event['seq']['event_direction']
            self.curr_barcode_event['barcode_event_id'] = self.curr_algo_verified_event['seq']['event_id']
            event_state = BarcodeEventState.PendingInside if direction=='in' else BarcodeEventState.PendingOutside
        else: # User barcode trigger
            direction='in'
            self.curr_algo_verified_event = None
            self.curr_barcode_event['barcode_event_id'] = self.barcode_event_id
            self.barcode_event_id += 1
            event_state = BarcodeEventState.PendingOutside
        self.curr_barcode_event['direction'] = direction
        # Send indication to cart content
        if hasattr(self.md_module, 'cart_content_handler'):
            tr='user' if 'user' in self.curr_barcode_event['trigger'] else 'internal'
            self.md_module.cart_content_handler.init_barcode_event_state(self.curr_barcode_event['barcode_event_id'],
                                                                        tr, 
                                                                        self.curr_barcode_event['direction'],
                                                                        event_state) 

        if self.debug:
            print('BarcodeHandler DEBUG: Initializing barcode event: [id:%d, frame:%d, trigger:%s, direction:%s]' \
                % (self.curr_barcode_event['barcode_event_id'], self.curr_barcode_event['trigger_frame'], \
                   self.curr_barcode_event['trigger'], self.curr_barcode_event['direction']), flush=True)
            if hasattr(self.md_module, 'event_logic'):
                if len(self.md_module.event_logic.special_item_handler.pending_verification_events['barcode']) > 0:
                    pending_events_in_que = ['Id:%d, frame:%d, direction:%s' % \
                        (ev['seq']['event_id'], ev['seq']['event_frame'], ev['seq']['event_direction']) \
                        for ev in self.md_module.event_logic.special_item_handler.pending_verification_events['barcode']]
                    print('BarcodeHandler DEBUG: pending events: ', pending_events_in_que, flush=True)


    def update_barcode_event(self, key, val):
        self.curr_barcode_event[key] = val
    
    def reset(self):
        self.state = BarcodeHandlerState.Idle
        self.next_message = dict(event=BarcodeHandlerEvent.Empty, metadata=None)
        self.should_skip_frame = False
        self.mode_change_triggered = False
        self.curr_barcode_event = None
        self.barcode_event_id = 0
        self.last_verified_barcode_frame = 0
        self.last_scanned_barcode_frame = 0
        self.last_mode_close_frame = 0
        self.pending_barcode_triggers = []
        self.external_markers = []
        self.barcode_visualization_img = None
        self.unfinished_events = []
        if hasattr(self, 'auto_detect_trigger'):
            self.auto_detect_trigger.reset()
        self.barcode_inject = None
    
    def get_scanner_box(self):
        xs = int(self.params.scanner_img_shape[1] * self.params.scanner_xlim[0])
        ys = int(self.params.scanner_img_shape[0] * self.params.scanner_ylim[0])
        xe = int(self.params.scanner_img_shape[1] * self.params.scanner_xlim[1])
        ye = int(self.params.scanner_img_shape[0] * self.params.scanner_ylim[1])
        return [xs, ys, xe, ye]
    
    def is_idle(self):
        return self.state==BarcodeHandlerState.Idle
    
    def is_after_event(self, n_frames):
        # For visualization purpose, delay transition to default visualization
        return self.state==BarcodeHandlerState.Idle and self.md_module.global_frame_num - self.last_verified_barcode_frame < n_frames and \
            self.last_verified_barcode_frame > 0

    def is_pending_scan(self):
        return self.state==BarcodeHandlerState.BarcodePending

    def is_during_scan(self):
        currently_scanning = self.state==BarcodeHandlerState.BarcodePending
        recent_barcode_scan = self.curr_barcode_event is not None and \
            self.md_module.global_frame_num - self.curr_barcode_event['barcode_frame'] < self.params.frame_diff_to_consider_still_scan_event
        return currently_scanning or recent_barcode_scan
    
    def is_during_insert_event(self):
        return self.state in (BarcodeHandlerState.BarcodePending, BarcodeHandlerState.InsertionPending)
    
    def is_marker_event_match(self, dir, frame):
        if len(self.external_markers)>0:
            last_marker = self.external_markers[-1]
            valid_marker_dir = last_marker['action']=='insert' and dir=='in' or \
                               last_marker['action']=='remove' and dir=='out'
            if valid_marker_dir and abs(last_marker['frame'] - frame) < self.params.marker_event_frame_diff:
                return True

    def is_expecting_event(self, dir, frame, filtered_event):
        # Ignore event recieved shortly after user pressed item activity
        if self.is_marker_event_match(dir, frame):
            if self.debug:
                print('BarcodeHandler DEBUG: Forcing expecting event -> True(User Marker): dir:%s, event frame: %d.' % \
                    (dir, frame))
            return True
        during_event = self.state not in (BarcodeHandlerState.Idle, \
                                          BarcodeHandlerState.DefaultTransitionForced) and self.curr_barcode_event is not None
        # Make sure we are not checking event that occured before transition to current state
        if self.curr_barcode_event is not None:
            if len(self.curr_barcode_event['state_transitions']) > 0:
                if self.curr_barcode_event['state_transitions'][-1]['state'] == BarcodeHandlerState.ScanB4Remove:
                    frame_of_last_transition = self.curr_barcode_event['state_transitions'][-2]['frame']     
                else:
                    frame_of_last_transition = self.curr_barcode_event['state_transitions'][-1]['frame']
                if self.debug:
                    print('BarcodeHandler DEBUG: Checking if expecting event: dir:%s, event frame: %d. bc state transition' % \
                        (dir, frame), self.curr_barcode_event['state_transitions'])
                if frame < frame_of_last_transition:
                    if self.debug:
                        print('BarcodeHandler DEBUG: expecting event: %r' % (False), flush=True) 
                    return False

        if dir=='out':
            valid = self.state in (BarcodeHandlerState.RemovalPending, BarcodeHandlerState.ScanB4Remove)
            if not valid and during_event and not filtered_event:
                barcode_event_dir = self.curr_barcode_event['direction']
                err = BarcodeWarning.BarcodeRemoveOtherRemove if barcode_event_dir=='out' else \
                    BarcodeWarning.BarcodeInsertOtherRemove
                self.add_barcode_error(err)
        else:
            valid = self.state==BarcodeHandlerState.InsertionPending
            if not valid and during_event and not filtered_event:
                barcode_event_dir = self.curr_barcode_event['direction']
                err = BarcodeWarning.BarcodeRemoveOtherInsert if barcode_event_dir=='out' else \
                    BarcodeWarning.BarcodeInsertOtherInsert
                self.add_barcode_error(err)

        if self.debug:
            print('BarcodeHandler DEBUG: expecting event: %r' % (valid), flush=True) 
        return valid

    def is_expected_insert_event(self, dir):
        return self.state==BarcodeHandlerState.InsertionPending and dir=='in'
    
    def scan_barcode(self):
        assert self.state==BarcodeHandlerState.BarcodePending
        if hasattr(self.md_module, 'crop_for_barcode') and self.md_module.crop_for_barcode is not None:
            img = self.md_module.crop_for_barcode # pre-rotated
            barcode = self.barcode_scanner.scan(img, scan_raw=True)
        else:
            img = self.md_module.frameR_full_size # pre-rotated
            barcode = self.barcode_scanner.scan(img)
        valid, barcode, out_of_catalog = self.is_valid_barcode(barcode)
        return valid, barcode, out_of_catalog

    def scan_barcode_offline(self):
        assert self.state==BarcodeHandlerState.BarcodePending
        if self.barcode_inject is not None:
            # Simulate scan of valid barcode
            barcode = self.barcode_inject
            self.barcode_inject = None
            return True, barcode, False
        else:
            if hasattr(self.md_module, 'crop_for_barcode') and self.md_module.crop_for_barcode is not None:
                img = self.md_module.crop_for_barcode # pre-rotated
                barcode = self.barcode_scanner.scan(img, scan_raw=True)
            else:
                img = self.md_module.frameR_full_size # pre-rotated
                barcode = self.barcode_scanner.scan(img)
        valid, barcode, out_of_catalog = self.is_valid_barcode(barcode)
        return valid, barcode, out_of_catalog
    
    def is_valid_barcode(self, barcode):
        out_of_catalog = False
        if len(barcode)==1:
            bc = barcode[0].data
            if not self.params.allow_barcodes_out_of_catalog and hasattr(self.md_module, 'catalog'):
                if self.md_module.catalog.is_valid_barcode(bc):
                    return True, bc, out_of_catalog
                else:
                    out_of_catalog = True
                    valid = False
                    if 'out_of_catalog_bc' not in self.curr_barcode_event or self.curr_barcode_event['out_of_catalog_bc']['bc']!=bc:
                        self.curr_barcode_event['out_of_catalog_bc'] = dict(bc=bc, times_found=1, valid=False)
                    elif bc==self.curr_barcode_event['out_of_catalog_bc']['bc']:
                        self.curr_barcode_event['out_of_catalog_bc']['times_found'] +=1
                        valid = self.curr_barcode_event['out_of_catalog_bc']['times_found'] >= self.params.marked_unrecognized_barcode_after_n_det
                        self.curr_barcode_event['out_of_catalog_bc']['valid'] = valid

                    if self.debug:
                        print('BarcodeHandler DEBUG: barcode out of catalog: %s. times found: %d. valid=%r' % \
                            (bc, self.curr_barcode_event['out_of_catalog_bc']['times_found'], valid), flush=True)
                    return valid, bc if valid else None, out_of_catalog 
            else:
                return True, bc, out_of_catalog
        else:
            return False, None, out_of_catalog
    
    def create_ui_visualization_img(self, mask_img=False):
        if not hasattr(self.md_module, 'viz_img_for_barcode'):
            return
        if self.params.visualization_factor!=1:
            img = self.md_module.viz_img_for_barcode # pre-rotated
            img_vis = cv2.resize(img, (0,0), fx=self.params.visualization_factor, fy=self.params.visualization_factor)
        else:
            img_vis = self.md_module.viz_img_for_barcode # pre-rotated
        if self.params.visualization_rot_op is not None:
            img_vis = cv2.rotate(img_vis, cv2.ROTATE_90_CLOCKWISE)
        if mask_img:
            # Mask on image
            xs, xe = int(self.params.visualization_xlim[0] * img_vis.shape[1]), int(self.params.visualization_xlim[1] * img_vis.shape[1])
            ys, ye = int(self.params.visualization_ylim[0] * img_vis.shape[0]), int(self.params.visualization_ylim[1] * img_vis.shape[0])
            center_part = img_vis[ys:ye, xs:xe].copy()
            img_vis = np.clip((img_vis.astype(np.int) - 100),0,255).astype(np.uint8)
            img_vis[ys:ye, xs:xe] = center_part
        self.barcode_visualization_img = img_vis
        if self.params.viz_barcode_img and not hasattr(self.md_module, 'gui'):
            cv2.imshow('barcode visualization', img_vis)
    
    def log_current_event(self):
        if self.curr_barcode_event is None:
            return
        curr_event = dict(barcode_event_id=self.curr_barcode_event.get('barcode_event_id', -1),
                          scanned_barcode=self.curr_barcode_event.get('scanned_barcode', None),
                          product_code=self.curr_barcode_event.get('product_code', None),
                          state_transitions=self.curr_barcode_event.get('state_transitions', None)
        )
        self.unfinished_events.append(curr_event)
        print('BarcodeHandler: Logging unfinished barcode event %d' % curr_event['barcode_event_id'], flush=True)

    def write_message(self, raw_message, internal=False):
        if internal:
            event = raw_message
            metadata = None
        else:
            event, metadata = parse_message(raw_message)
        assert isinstance(event, BarcodeHandlerEvent)
        # If handling previous barcode event, push internal trigger to pending queue
        if event==BarcodeHandlerEvent.NewEventRequest:
#            trigger = metadata['trigger'] if 'trigger' in metadata else 'user'
            trigger = metadata['trigger']
            assert trigger in ('user', 'user_scan', 'internal')
            if trigger in ('user', 'user_scan') and self.state!=BarcodeHandlerState.Idle:
                self.log_current_event()
                self.clean_barcode_metadata()
                self.state = BarcodeHandlerState.Idle
                self.should_skip_frame = False
                self.mode_change_triggered = False
                self.curr_barcode_event = None
            elif trigger=='internal' and self.state!=BarcodeHandlerState.Idle:
                assert 'event_ID' in metadata.keys()
                self.pending_barcode_triggers.append(dict(event=BarcodeHandlerEvent.NewEventRequest,
                                                          metadata=metadata))
                if self.debug:
                    print('\033[93mBarcodeHandler DEBUG: Adding internal trigger for later handling. curr triggers queue:\033[00m', self.pending_barcode_triggers, flush=True)
                return
        elif event==BarcodeHandlerEvent.BarcodeScanned:
            if self.curr_barcode_event is not None and 'barcode' in metadata:
                if self.curr_barcode_event.get('scanned_barcode', None)==metadata['barcode']:
                    # TODO - log the number of consequtive scans of the same barcode
                    if self.debug:
                        print('\033[93mBarcodeHandler DEBUG: Ignoring consequtive barcode scan: %s\033[00m' % metadata['barcode'], flush=True)
                    return
                else:
                    # default behavior
                    self.next_message = dict(event=event, metadata=metadata)
        elif event==BarcodeHandlerEvent.SetBarcodeMode:
            # Valid external event to recieve during flow
            self.next_message = dict(event=event, metadata=metadata)
        
        # Override event with 'marked' message, only if waiting for insert/remove event
        elif event==BarcodeHandlerEvent.ItemActivityMarked and \
            self.state in (BarcodeHandlerState.InsertionPending, BarcodeHandlerState.RemovalPending):
            self.next_message = dict(event=event, metadata=metadata)

        # If State machine is not on idle, ignore external message other than forced close
        elif not event==BarcodeHandlerEvent.CloseEventRequest \
            and not internal and self.state!=BarcodeHandlerState.Idle:
            if self.debug:
                print('BarcodeHandler DEBUG: ignoring external message %s' % event, flush=True)
            return
        self.next_message = dict(event=event, metadata=metadata)
        if self.debug:
            print('BarcodeHandler DEBUG[%d]: recieved API message: ' % self.md_module.global_frame_num, raw_message, flush=True)

    
    def read_message(self):
        msg = self.next_message
        self.next_message = dict(event=BarcodeHandlerEvent.Empty, metadata=None)
        # If state machine is idle and more triggers are pending, pop a trigger for queue
        if self.state==BarcodeHandlerState.Idle and msg['event']==BarcodeHandlerEvent.Empty and len(self.pending_barcode_triggers)>0:
            trigger = self.pending_barcode_triggers.pop(0)
            assert trigger['metadata']['event_ID']==self.md_module.event_logic.special_item_handler.pending_verification_events['barcode'][0]['seq']['event_id']
            msg = trigger
        if self.debug and msg['event']!=BarcodeHandlerEvent.Empty:
            print('BarcodeHandler DEBUG: next message %s' % msg, flush=True)
        return msg['event'], msg['metadata']

    
    def check_validity(self):
        if len(self.pending_barcode_triggers) >= self.params.max_pending_events:
            assert len(self.pending_barcode_triggers)==len(self.md_module.event_logic.special_item_handler.pending_verification_events['barcode'])
            if self.debug:
                print('BarcodeHandler DEBUG: %d pending barcode events, Invalidating' % \
                    len(self.pending_barcode_triggers), flush=True)

            # Send events overflow notification
            if hasattr(self.md_module, 'cart_content_handler'):
                self.md_module.cart_content_handler.send_event_overflow_message()


            # Send all events as marked for validation
            while len(self.pending_barcode_triggers) > 0:
                self.pending_barcode_triggers.pop(0)
                event = self.md_module.event_logic.special_item_handler.pending_verification_events['barcode'].pop(0)
                if hasattr(self.md_module, 'cart_content_handler'):
                    self.md_module.cart_content_handler.invalidate_event(event['seq'])
            
            # Invalidate cart
            self.add_barcode_error(BarcodeError.BarcodeInsertErrOnInsert)

    def step(self):
        '''
        Entry point to barcode handler
        '''

        try:
            if hasattr(self, 'auto_detect_trigger'):
                self.auto_detect_trigger.step()
            
            # Check Module Validity
            # =====================
            self.check_validity()

            # Get indication from MD Module
            # =============================
            event, metadata = self.read_message()

            # Propagate state
            # ===============
            next_state = self.get_next_state(event, metadata)
            self.state = next_state

            # Perform state actions
            # =====================
            internal_message = self.state_actions(metadata)

            if internal_message is not None:
                self.write_message(internal_message, internal=True)
        except:
            MDMessages.log_md_warning(traceback.format_exc(), source='barcode_handler')
            metadata= dict(reason='failure')
            next_state = self.get_next_state(BarcodeHandlerEvent.CloseEventRequest, metadata)
            self.state = next_state
            
            # Perform state actions
            # =====================
            internal_message = self.state_actions(metadata)

            if internal_message is not None:
                self.write_message(internal_message, internal=True)



    def get_next_state(self, event, metadata):
        '''
        Logic defining transition between states according to messages
        '''
        next_state = self.state
        assert isinstance(event, BarcodeHandlerEvent)
        if event==BarcodeHandlerEvent.NewEventRequest:
            assert self.state==BarcodeHandlerState.Idle
        #    trigger = metadata['trigger'] if 'trigger' in metadata else 'user'
            trigger = metadata['trigger']
            assert trigger in ('user', 'user_scan', 'internal')
            if 'user' in trigger:
                next_state = BarcodeHandlerState.BarcodeTransitionUser
            else:
                if self.params.ignore_algo_trigger:
                    self.skip_barcode_event()
                else:
                    next_state = BarcodeHandlerState.BarcodeTransitionInternal

        elif event==BarcodeHandlerEvent.SetBarcodeMode:
            assert self.state in (BarcodeHandlerState.BarcodePending, BarcodeHandlerState.BarcodeTransitionInternal, \
                                  BarcodeHandlerState.BarcodeTransitionUser, BarcodeHandlerState.RemovalPending)
            assert metadata['mode'] in ('camera', 'manual')
            self.curr_barcode_event['barcode_input_method'] = metadata['mode']
        elif event==BarcodeHandlerEvent.BarcodeScanned:
            if self.state in (BarcodeHandlerState.BarcodePending, BarcodeHandlerState.BarcodeTransitionUser, \
                              BarcodeHandlerState.BarcodeTransitionInternal, BarcodeHandlerState.RemovalPending):
                print('BarcodeHandler DEBUG got barcode when expecting it' , flush=True)
                # Update barcode with input from user
                assert metadata['scan_type']=='manual'
                self.curr_barcode_event['scanned_barcode'] = metadata['barcode']
                self.curr_barcode_event['product_code'] = metadata['product_code']
                # Simulate same variable settings as camera barcode
                barcode_to_md_delay = self.md_module.imgs_in_queue
                self.last_scanned_barcode_frame = int(self.md_module.global_frame_num + barcode_to_md_delay)
                self.update_barcode_event('barcode_frame', int(self.md_module.global_frame_num + barcode_to_md_delay))
                next_state = BarcodeHandlerState.ScanB4Remove if self.state==BarcodeHandlerState.RemovalPending else \
                    BarcodeHandlerState.BarcodeVerified if self.curr_barcode_event['direction']=='out' else \
                    BarcodeHandlerState.InsertionPending
            elif self.state==BarcodeHandlerState.BarcodeTransitionInternal:
                next_state = BarcodeHandlerState.BarcodeVerified if self.curr_barcode_event['direction']=='out' else \
                    BarcodeHandlerState.RemovalPending
            if hasattr(self.md_module, 'cart_content_handler'):
                self.md_module.cart_content_handler.update_barcode_event_state(self.curr_barcode_event['barcode_event_id'],
                                                                            self.curr_barcode_event['trigger'], 
                                                                            BarcodeEventState.ScannedPendingOutside,
                                                                            barcode=self.curr_barcode_event['scanned_barcode'],
                                                                            product_code=self.curr_barcode_event['product_code']) 
            # Log to capsule
            if self.logger is not None and self.logger.should_log('user_marked_event'):
                event_metadata = dict(action=event.name, scan_type=metadata['scan_type'],
                                      barcode=self.curr_barcode_event['scanned_barcode'],
                                      product_code=self.curr_barcode_event['product_code'],
                                      trigger=self.curr_barcode_event['trigger'])
                self.logger.log(self.mel.pack(self.curr_barcode_event['barcode_event_id'], \
                    'BarcodeEventOp', metadata=event_metadata), 'user_marked_event')

        elif event==BarcodeHandlerEvent.BarcodeScanSuccess:
            if self.state==BarcodeHandlerState.BarcodePending:
                next_state = BarcodeHandlerState.BarcodeVerified if self.curr_barcode_event['direction']=='out' else \
                    BarcodeHandlerState.InsertionPending
            if self.state==BarcodeHandlerState.BarcodeTransitionInternal:
                next_state = BarcodeHandlerState.BarcodeVerified if self.curr_barcode_event['direction']=='out' else \
                    BarcodeHandlerState.RemovalPending
            if hasattr(self.md_module, 'cart_content_handler'):
                self.md_module.cart_content_handler.update_barcode_event_state(self.curr_barcode_event['barcode_event_id'],
                                                                            self.curr_barcode_event['trigger'], 
                                                                            BarcodeEventState.ScannedPendingOutside,
                                                                            barcode=self.curr_barcode_event['scanned_barcode']) 
            # Log to capsule
            if self.logger is not None and self.logger.should_log('user_marked_event'):
                event_metadata = dict(action=event.name, scan_type='camera',
                                      barcode=self.curr_barcode_event['scanned_barcode'],
                                      trigger=self.curr_barcode_event['trigger'])
                self.logger.log(self.mel.pack(self.curr_barcode_event['barcode_event_id'], \
                    'BarcodeEventOp', metadata=event_metadata), 'user_marked_event')
        elif event==BarcodeHandlerEvent.BarcodeScanFailure:
            assert self.state==BarcodeHandlerState.BarcodePending
            # TODO - Failure counter?
            next_state = BarcodeHandlerState.BarcodePending
        elif event==BarcodeHandlerEvent.InsertionSuccess:
            assert self.state in (BarcodeHandlerState.InsertionPending, BarcodeHandlerState.RemovalPending, BarcodeHandlerState.ScanB4Remove)
            # TODO - Future handle of similarity
            next_state = BarcodeHandlerState.BarcodeVerified
        elif event==BarcodeHandlerEvent.RemovalSuccess:
            if self.state==BarcodeHandlerState.RemovalPending:
                # TODO - Future handle of similarity
                next_state = BarcodeHandlerState.BarcodePending
            elif self.state==BarcodeHandlerState.ScanB4Remove:
                next_state = BarcodeHandlerState.InsertionPending    
            if hasattr(self.md_module, 'cart_content_handler'):
                self.md_module.cart_content_handler.update_barcode_event_state(self.curr_barcode_event['barcode_event_id'],
                                                                            self.curr_barcode_event['trigger'], 
                                                                            BarcodeEventState.PendingOutside)
                if hasattr(self.md_module.cart_content_handler, 'location_matching'):
                    self.md_module.cart_content_handler.location_matching.remove_product(None, None,
                                                                                        pending_items_removal=True,
                                                                                        pending_event_id=self.curr_barcode_event['barcode_event_id'])
        elif event==BarcodeHandlerEvent.BarcodeModeReady:
            assert self.state in (BarcodeHandlerState.BarcodeTransitionUser, BarcodeHandlerState.BarcodeTransitionInternal)
            self.barcode_scanner_frame_counter = 0
            if self.curr_barcode_event['trigger']=='internal':
                next_state = BarcodeHandlerState.BarcodePending if self.curr_barcode_event['direction']=='out' else \
                    BarcodeHandlerState.RemovalPending  
            else:
                next_state = BarcodeHandlerState.BarcodePending
        elif event==BarcodeHandlerEvent.DefaultModeReady:
            assert self.state in (BarcodeHandlerState.DefaultTransition, BarcodeHandlerState.DefaultTransitionForced)
            if self.state==BarcodeHandlerState.DefaultTransitionForced:
                next_state = BarcodeHandlerState.Idle
            else:
                next_state = BarcodeHandlerState.Idle
        elif event==BarcodeHandlerEvent.Empty:
            if self.state==BarcodeHandlerState.BarcodeVerified:
                next_state = BarcodeHandlerState.DefaultTransition
        elif event==BarcodeHandlerEvent.CloseEventRequest:
            if self.state not in (BarcodeHandlerState.DefaultTransitionForced, BarcodeHandlerState.Idle):
                next_state = BarcodeHandlerState.DefaultTransitionForced
                if hasattr(self.md_module, 'cart_content_handler'):
                    close_type = metadata['reason']
                    self.curr_barcode_event['external_close'] = close_type
                    # Race condition fix - it may be possible that UI side has sent close event # TODO - check if still happens
                    # before state machine got to idle. if that is the case, don't send errors, and continue to idle if needed
                    event_already_closed = self.curr_barcode_event is None
                    if event_already_closed:
                        if self.state==BarcodeHandlerState.DefaultTransition:
                            next_state = BarcodeHandlerState.Idle
                    else:
                        valid, err, err_msg = handle_invalid_close(close_type, self.state, self.curr_barcode_event['direction'])
                        if not valid:
                            self.add_barcode_error(err)
                        self.md_module.cart_content_handler.close_barcode_event(self.curr_barcode_event['barcode_event_id'],
                                                                                self.curr_barcode_event['trigger'], err_msg, valid)
        elif event==BarcodeHandlerEvent.ItemActivityMarked:
            if self.state in (BarcodeHandlerState.InsertionPending, BarcodeHandlerState.RemovalPending):
                # Mark frame to ignore delayed events in the next frames
                barcode_to_md_delay = self.md_module.imgs_in_queue
                approx_frame = int(self.md_module.global_frame_num + barcode_to_md_delay)
                marker = dict(frame=approx_frame, action=metadata['action'])
                self.external_markers.append(marker)
                # Skip to next state
                if self.state==BarcodeHandlerState.RemovalPending:
                    next_state = BarcodeHandlerState.BarcodePending
                    if hasattr(self.md_module, 'cart_content_handler'):
                        self.md_module.cart_content_handler.update_barcode_event_state(self.curr_barcode_event['barcode_event_id'],
                                                                                    self.curr_barcode_event['trigger'], 
                                                                                    BarcodeEventState.PendingOutside, send_ui=False)
                        if hasattr(self.md_module.cart_content_handler, 'location_matching'):
                            self.md_module.cart_content_handler.location_matching.remove_product(None, None,
                                                                                                pending_items_removal=True,
                                                                                                pending_event_id=self.curr_barcode_event['barcode_event_id'])
                elif self.state==BarcodeHandlerState.InsertionPending:
                    next_state = BarcodeHandlerState.BarcodeVerified
                    self.md_module.cart_content_handler.update_barcode_event_state(self.curr_barcode_event['barcode_event_id'],
                                                                                self.curr_barcode_event['trigger'], 
                                                                                BarcodeEventState.VerifiedInsideMarked)



        if self.debug and (next_state!=self.state or event!=BarcodeHandlerEvent.Empty):
            print('BarcodeHandler DEBUG[%d]: state transition: (%s-> %s) with message %s' \
                % (self.md_module.global_frame_num, self.state, next_state, event), flush=True)
        if next_state!=self.state and (self.curr_barcode_event is not None and 'state_transitions' in self.curr_barcode_event):
            self.curr_barcode_event['state_transitions'].append(self.log_state_transition(next_state))

        return next_state

    def send_message(self, event):
        '''
        Implement rules for each sent message in flow
        '''
        assert isinstance(event, BarcodeHandlerEvent) and self.curr_barcode_event is not None
        if event==BarcodeHandlerEvent.InitEvent:
            metadata = dict(event_ID=self.curr_barcode_event['barcode_event_id'],
                            trigger=self.curr_barcode_event['trigger'],
                            direction=self.curr_barcode_event['direction'])
        elif event==BarcodeHandlerEvent.BarcodeScanned:
            scan_type = self.curr_barcode_event['barcode_input_method']
            # Don't send barcode message to UI if it was recieved from user
            if scan_type!='camera':
                return
            metadata = dict(event_ID=self.curr_barcode_event['barcode_event_id'],
                            barcode=self.curr_barcode_event['scanned_barcode'],
                            scan_type=scan_type)
        elif event==BarcodeHandlerEvent.ProductRemoved:
            metadata = dict(event_ID=self.curr_barcode_event['barcode_event_id'])
        elif event==BarcodeHandlerEvent.FinishEvent:
            # TODO - return only (done, done_with_warning, done_with_error)
            close_reason = 'done_with_warning' if self.curr_barcode_event['marked_event'] else 'done'
            if self.curr_barcode_event['external_close'] is not None:
                if self.curr_barcode_event['curr_error'] is None:
                    close_reason = 'close'
                else:
                    close_reason = 'done_with_error'
            metadata = dict(event_ID=self.curr_barcode_event['barcode_event_id'],
                            reason=close_reason)

        raw_message = compose_message(event, metadata)

        if self.debug:
            print('BarcodeHandler DEBUG[%d]: sending message: ' % self.md_module.global_frame_num, raw_message, flush=True) 
        # Send message to UI
        if hasattr(self.md_module, 'gui') and self.md_module.gui is not None:
            self.md_module.gui.send(raw_message)
        # Log to capsule
        if self.logger is not None and self.logger.should_log('user_marked_event'):
            if event in (BarcodeHandlerEvent.InitEvent, BarcodeHandlerEvent.FinishEvent):
                event_metadata = dict(action=event.name)
                if event==BarcodeHandlerEvent.InitEvent:
                    event_metadata['trigger'] = self.curr_barcode_event['trigger']
                elif event==BarcodeHandlerEvent.FinishEvent:
                    event_metadata['close_reason'] = close_reason
                self.logger.log(self.mel.pack(self.curr_barcode_event['barcode_event_id'], \
                    'BarcodeEventOp', metadata=event_metadata), 'user_marked_event')


    def state_actions(self, metadata):
        if not self.is_idle():
            self.create_ui_visualization_img()
        internal_message = None
        if self.state in (BarcodeHandlerState.BarcodeTransitionUser, BarcodeHandlerState.BarcodeTransitionInternal):
            if self.curr_barcode_event is None:
#                trigger = 'user' if self.state==BarcodeHandlerState.BarcodeTransitionUser else 'internal'
                trigger = metadata['trigger'] if metadata is not None else 'internal'
                self.start_barcode_event(trigger)
                self.send_message(BarcodeHandlerEvent.InitEvent)
                # Send UI init event message
            self.set_stream('Barcode')
            if self.mode_change_triggered and self.is_stream_ready():
                internal_message = BarcodeHandlerEvent.BarcodeModeReady
        elif self.state==BarcodeHandlerState.BarcodePending:
            if self.use_cam_scanner and self.curr_barcode_event['barcode_input_method']=='camera':
                self.mark_barcode_mv()
                if self.barcode_scanner_frame_counter % self.params.activate_scanner_every_n_frames == 0:
                    valid, barcode, out_of_catalog = self.scan_operator()
                    if valid:
                        barcode_err = BarcodeError.BarcodeRemoveErrOnScan if self.curr_barcode_event['direction']=='out' else \
                            BarcodeError.BarcodeInsertErrOnScan
                        # TODO - Check vs. catalog for valid product
                        event_results = [] # dummy
                        if self.curr_barcode_event['trigger']=='internal':
                            # This State used to require a validation if a product barcode is mapped to one of the top5 classifier predictions
                            # We enable the shopper to "trick" the system here and scan a different product
                            # The reason is that as long as we managed to identify a valid removal, the process is like a user-triggered event:
                            # The result of the event will be set by the barcode scan.
                            # This alleviates the need to compare the barcode scan results vs. the classifier predictions,
                            # Especially when the product is unrecognized
                            # Compare barcode result vs. verified event
                            # event_results = self.curr_algo_verified_event['result'][1]
                            # barcode_similar_to_event = self.event_vs_barcode_similar(event_results, barcode, False)
                            barcode_similar_to_event = True
                        else:
                            barcode_similar_to_event = True
                        if barcode_similar_to_event:
                            self.remove_barcode_error(barcode_err)
                            internal_message = BarcodeHandlerEvent.BarcodeScanSuccess
                            self.update_barcode_event('scanned_barcode', barcode)
                            # Since we are using last acquired frame, we need to take into account the delay in image queue
                            barcode_to_md_delay = self.md_module.imgs_in_queue
                            self.last_scanned_barcode_frame = int(self.md_module.global_frame_num + barcode_to_md_delay)
                            self.update_barcode_event('barcode_frame', int(self.md_module.global_frame_num + barcode_to_md_delay))
                            if self.curr_barcode_event['direction']=='out':
                                self.clear_barcode_mv()
                        else:
                            self.add_barcode_error(barcode_err)
                            if self.debug:
                                print('BarcodeHandler DEBUG: Warning: Barcode result not similar to Event:', \
                                    barcode, event_results , flush=True)


            self.barcode_scanner_frame_counter += 1
        elif self.state==BarcodeHandlerState.InsertionPending:
            assert self.curr_barcode_event['direction']!='out'
            # Keep trying to mark a valid mv due to delay in image queue
            if self.md_module.global_frame_num <= self.curr_barcode_event['barcode_frame'] + self.params.keep_marking_after_scan_n_frames:
                self.mark_barcode_mv(pos_only=True)
            if self.check_new_event('in'):
                internal_message = BarcodeHandlerEvent.InsertionSuccess
                self.clear_barcode_mv()
        elif self.state in (BarcodeHandlerState.RemovalPending, BarcodeHandlerState.ScanB4Remove):
            # TODO - similarity to scanned item
            if self.check_new_event('out'):
                internal_message = BarcodeHandlerEvent.RemovalSuccess
        elif self.state in (BarcodeHandlerState.DefaultTransition, BarcodeHandlerState.DefaultTransitionForced):
            if self.curr_barcode_event is not None:
                self.send_message(BarcodeHandlerEvent.FinishEvent)
                self.clear_barcode_mv()
                self.set_stream('Default')
                self.clear_warnings()
                self.log_barcode_event()
                self.clean_barcode_metadata()
            if self.mode_change_triggered and self.is_stream_ready():
                internal_message = BarcodeHandlerEvent.DefaultModeReady
                self.last_mode_close_frame = self.md_module.global_frame_num
        elif self.state==BarcodeHandlerState.BarcodeVerified:
            self.last_verified_barcode_frame = self.md_module.global_frame_num
            event_state = BarcodeEventState.VerifiedInside if self.curr_barcode_event['direction']=='in' \
                else BarcodeEventState.VerifiedOutside
            if hasattr(self.md_module, 'cart_content_handler'):
                self.md_module.cart_content_handler.update_barcode_event_state(self.curr_barcode_event['barcode_event_id'],
                                                                            self.curr_barcode_event['trigger'], 
                                                                            event_state) 
            # Post-Validate removal event
            if hasattr(self, 'product_validator'):
                if self.curr_barcode_event is not None and self.curr_barcode_event['direction']=='out' and \
                    'product_code' in self.curr_barcode_event and self.curr_algo_verified_event is not None and \
                    self.curr_algo_verified_event['seq']['event_id']==self.curr_barcode_event['barcode_event_id']:
                    last_event_info = self.curr_algo_verified_event['seq']
                    product_code = self.curr_barcode_event['product_code']
                    event_score, _ = self.product_validator.validate_event(last_event_info, product_code)
                    # Save validation score to capsule
                    if event_score is not None and self.logger is not None and self.logger.should_log('user_marked_event'):
                        event_metadata = dict(barcode=self.curr_barcode_event['scanned_barcode'],
                                            product_code=self.curr_barcode_event['product_code'],
                                            direction=self.curr_barcode_event['direction'],
                                            trigger=self.curr_barcode_event['trigger'],
                                            validation_score=event_score)
                        self.logger.log(self.mel.pack(self.curr_barcode_event['barcode_event_id'], \
                            'ProductValidation', metadata=event_metadata), 'user_marked_event')

        
        return internal_message

    def clean_barcode_metadata(self):
        self.curr_barcode_event = None

    def log_barcode_event(self):
        if self.logger is not None and self.logger.should_log('barcode_event_img'):
            has_images = len([1 for v in self.curr_barcode_event['product_img_during_scan'].values() if len(v)>0])
            if has_images:
                frame = self.curr_barcode_event['trigger_frame'] if 'trigger_frame' in self.curr_barcode_event else None
                self.logger.log(BarcodeImgLogger.pack(self.curr_barcode_event['product_img_during_scan']), 'barcode_event_img', frame=frame)


    def check_new_event(self, direction):
        if hasattr(self.md_module, 'event_logic'):
            return self.check_new_classified_event(direction)
        else:
            return self.check_new_non_classified_event(direction)


    def check_new_classified_event(self, direction):
        if len(self.md_module.purchaseList)==0:
            return False
        last_event = self.md_module.purchaseList[-1]
        if last_event['id']==self.curr_barcode_event['last_event_id_compared'] or \
           (last_event['id']==self.curr_barcode_event['barcode_event_id'] and self.curr_barcode_event['trigger']=='internal'):
            return False
        # Ignore insertions that happened before barcode was scanned
        if self.state==BarcodeHandlerState.InsertionPending and direction=='in':
            if last_event['frameNum'] < self.curr_barcode_event['barcode_frame']:
                return False

        self.curr_barcode_event['last_event_id_compared'] = last_event['id']
        valid_direction = last_event['direction']==direction
        valid_timing =  last_event['frameNum'] > self.curr_barcode_event['trigger_frame']
        if not (valid_direction and valid_timing):
            if self.debug and not valid_direction:
                print('BarcodeHandler DEBUG: Ignoring Event[dir:%s, id:%d, frame:%d] due to invalid direction' \
                    % (last_event['direction'], last_event['id'], last_event['frameNum']), flush=True)
            return False
        if direction=='out':
            assert self.curr_barcode_event['trigger']=='internal'
            assert self.curr_algo_verified_event is not None
            # Compare event vs. event
            event_to_event_similar = last_event['part_of_barcode_verification']
            if self.debug and not event_to_event_similar:
                print('BarcodeHandler DEBUG: Ignoring Event[dir:%s, id:%d, frame:%d] due to event-event not similar' \
                    % (last_event['direction'], last_event['id'], last_event['frameNum']), flush=True)
            return event_to_event_similar
        else:
            if self.curr_barcode_event is not None and 'product_code' in self.curr_barcode_event:
                products_with_barcode = [self.curr_barcode_event['product_code']] 
            else:
                products_with_barcode = self.md_module.catalog.get_products_with_barcode(self.curr_barcode_event['scanned_barcode'])
                if len(products_with_barcode)==0:
                    # Place holder, should ignore barcodes invalid according to catalog
                    products_with_barcode = [self.curr_barcode_event['scanned_barcode']]
            event_to_barcode_similar = last_event['topProb'][0][0] in products_with_barcode
            if self.debug and not event_to_barcode_similar:
                print('BarcodeHandler DEBUG: Ignoring Event[dir:%s, id:%d, frame:%d] due to event-barcode not similar' \
                    % (last_event['direction'], last_event['id'], last_event['frameNum']), flush=True)
            return event_to_barcode_similar

    def check_new_non_classified_event(self, direction):
        if len(self.md_module.purchaseList)==0:
            return False
        assert 'user' in self.curr_barcode_event['trigger'] and direction=='in'
        last_event = self.md_module.purchaseList[-1]
        if last_event['id']==self.curr_barcode_event['last_event_id_compared']:
            return False
        # Ignore insertions that happened before barcode was scanned
        if self.state==BarcodeHandlerState.InsertionPending and direction=='in':
            if last_event['frameNum'] < self.curr_barcode_event['barcode_frame']:
                return False

        self.curr_barcode_event['last_event_id_compared'] = last_event['id']
        valid_direction = last_event['direction']==direction
        valid_timing =  last_event['frameNum'] > self.curr_barcode_event['trigger_frame']
        if not (valid_direction and valid_timing):
            if self.debug and not valid_direction:
                print('BarcodeHandler DEBUG: Ignoring Event[dir:%s, id:%d, frame:%d] due to invalid direction' \
                    % (last_event['direction'], last_event['id'], last_event['frameNum']), flush=True)
            return False
        else:
            valid_event = last_event['source']=='MD'
            if valid_event and hasattr(self.md_module, 'cart_content_handler'):
                # Send verified barcode event to UI - to compensate on event_logic op
                event_id = last_event['id']
                barcode = self.curr_barcode_event['scanned_barcode']
                self.md_module.cart_content_handler.update_ui_with_insert_barcode_event(event_id, barcode)
            return valid_event

    
    def event_vs_event_similar(self, last_event, query_event, last_event_info=None):
        '''
        Basic logic for similar events - look for at least 1 joint prediction in top5 of both events
        '''
        if self.params.skip_similarity_validation:
            if self.debug:
                print('BarcodeHandler DEBUG: Overriding Event-Event similarity: True', flush=True)
            return True
        if 'sequence_descriptors' in query_event['seq'] and (last_event_info is not None and 'sequence_descriptors' in last_event_info):
            query_event_desc = query_event['seq']['sequence_descriptors']
            last_event_desc = last_event_info['sequence_descriptors']
            if self.debug:
                print('BarcodeHandler DEBUG: Checking Event-Event similarity. Event 1 samples: %d, Event 2 samples: %d' % \
                                        (len(query_event_desc), len(last_event_desc)), flush=True)
            return event_vs_event_descriptors_similar(query_event_desc, last_event_desc)
        else:
            last_event_pred = [p[0] for p in last_event]
            query_event_pred = [p[0] for p in query_event['result'][1]]
            return event_vs_event_predictions_similar(last_event_pred, query_event_pred)
    
    def get_product_code(self, barcode):
        if self.curr_barcode_event is not None and 'product_code' in self.curr_barcode_event:
            product_code = self.curr_barcode_event['product_code'] 
        else:
            products_with_barcode = self.md_module.catalog.get_products_with_barcode(barcode)
            if len(products_with_barcode) > 0:
                # TODO - possibly returning wrong product code when multiple UPC has same barcode
                product_code = products_with_barcode[0]
            else:
                product_code = barcode #fallback
        return product_code

    def event_vs_barcode_similar(self, last_event, barcode, event_marked_during_barcode_scan, last_event_info=None):
        '''
        Basic logic for similarity between event & barcode - check if barcode is in top5 predictions
        '''
        if self.params.skip_similarity_validation:
            if self.debug:
                print('BarcodeHandler DEBUG: Overriding Event-Barcode similarity: True', flush=True)
            return True
        # Product validation
        # ==================
        if hasattr(self, 'product_validator') and last_event_info is not None:
            product_code = self.get_product_code(barcode)
            event_score, _ = self.product_validator.validate_event(last_event_info, product_code)
            if event_score is None:
                # TODO - unrecognized product - add event to dataset
                if self.debug:
                    print('BarcodeHandler DEBUG: (%s): Unsupported product validation -> similarity: True' % product_code, flush=True)
                    return True
            else:
                # Save validation score to capsule - insert events
                if event_score is not None and self.logger is not None and self.logger.should_log('user_marked_event') and \
                    self.state==BarcodeHandlerState.InsertionPending and last_event_info['event_direction']=='in' and \
                        self.curr_barcode_event['direction']=='in':
                    event_metadata = dict(barcode=self.curr_barcode_event['scanned_barcode'],
                                          product_code=product_code,
                                          direction=self.curr_barcode_event['direction'],
                                          trigger=self.curr_barcode_event['trigger'],
                                          validation_score=event_score)
                    self.logger.log(self.mel.pack(self.curr_barcode_event['barcode_event_id'], \
                        'ProductValidation', metadata=event_metadata), 'user_marked_event')
                return self.product_validator.is_valid(event_score, product_code)
        elif self.curr_barcode_event['barcode_input_method']=='manual':
            if self.debug:
                print('BarcodeHandler DEBUG: barcode manually selected by user. Assuming barcode similar to event.', flush=True)
            return True
        # Include also products similar to barcode scan
        products_with_barcode = self.md_module.catalog.get_products_with_barcode(barcode)
        if len(products_with_barcode) > 0:
            supported_product = False
            for pwbc in products_with_barcode:
                if self.md_module.event_classifier.is_class_supported(pwbc):
                    supported_product = True
                    break
        else:
            supported_product = False
            # TODO: This scenario shouldn't happen as all scanned products should be is catalog
        if self.debug:
            print('BarcodeHandler DEBUG: Barcode supported by classifier: %r. catalog products:' % supported_product, products_with_barcode, flush=True)
        pred_conflict = False
        if supported_product:
            possible_barcode_products = []
            for bc_prod in products_with_barcode:
                barcode_similar_product = self.md_module.event_logic.special_item_handler.very_similar_products(barcode)
                if barcode_similar_product:
                    possible_barcode_products += [bc_prod, barcode_similar_product]
                else:
                    possible_barcode_products += [bc_prod]
            possible_barcode_products = list(set(possible_barcode_products))
            # In Case out of catalog product was scanned
            if len(possible_barcode_products)==0:
                return False
            # Include also products similar to event products
            last_event_pred = []
            for pred_idx, p in enumerate(last_event):
                # Consider top-2 predictions + other predictions > th
                if not (pred_idx<2 or p[1] > self.params.min_cls_supported_product_conf):
                    continue
                # get barcode of prediction and add all products with barcode
                product_barcode = self.md_module.catalog.get_barcode(p[0])
                barcode_pred = self.md_module.catalog.get_products_with_barcode(product_barcode)
                last_event_pred += barcode_pred
                similar_product = self.md_module.event_logic.special_item_handler.very_similar_products(p[0])
                if similar_product:
                    last_event_pred.append(similar_product)

            last_event_pred = list(set(last_event_pred))
            # if self.debug and event_marked_during_barcode_scan:
            #     print('BarcodeHandler DEBUG: Event-Barcode similar due to MARKED DURING SCAN', flush=True)
            pred_to_bc_similar = event_vs_event_predictions_similar(last_event_pred, possible_barcode_products, input_type='pred_vs_barcode') 
            if not (pred_to_bc_similar or event_marked_during_barcode_scan):
                if self.debug:
                    print('BarcodeHandler DEBUG: Event-Barcode NOT SIMILAR: Marked: False, Pred:False', flush=True)
                return False
            elif pred_to_bc_similar:
                if self.debug:
                    print('BarcodeHandler DEBUG: Event-Barcode SIMILAR: Marked: %r, Pred:True' % event_marked_during_barcode_scan, flush=True)
                return True
            else: # pred=False, marked=True
                if self.debug:
                    print('BarcodeHandler DEBUG: Event-Barcode CONFLICT: Marked: True, Pred:False', flush=True)
                pred_conflict = True

        if pred_conflict or (not supported_product):
            # TODO: currently rely only on tracking the MV. should add similarity-based verification here
            if (not pred_conflict) and event_marked_during_barcode_scan:
                if self.debug:
                    print('BarcodeHandler DEBUG: Event-Barcode similar due to MARKED DURING SCAN', flush=True)
                return True 
            # Extract barcode crops descriptors
            event_cls = self.md_module.event_classifier.yaaen
            if event_cls.can_extract_descriptors and (last_event_info is not None and 'sequence_descriptors' in last_event_info):
                last_event_desc = last_event_info['sequence_descriptors']
                last_event_cams = [mv.cam_name for mv in last_event_info['movement_vector_for_saving']]
                barcode_crop_img = []
                barcode_crop_cams = []
                for cam_name, _ in self.curr_barcode_event['product_img_during_scan'].items():
                    cam_imgs = [bc_mv.cropped_image for bc_mv in self.curr_barcode_event['product_img_during_scan'][cam_name] \
                        if bc_mv.coords.area() > self.params.min_barcode_crop_area]
                    cam_imgs = cam_imgs[:self.params.max_barcode_crop_per_cam]
                    barcode_crop_img += cam_imgs
                    barcode_crop_cams += [cam_name] * len(cam_imgs)
                barcode_crop_desc = event_cls.extract_descriptors(barcode_crop_img)
                if self.debug:
                    print('BarcodeHandler DEBUG: Checking Event-Barcode similarity. Barcode samples: %d, Event samples: %d' % \
                        (len(barcode_crop_img), len(last_event_desc)), flush=True)
                return event_vs_event_descriptors_similar(barcode_crop_desc, last_event_desc, per_cam=True, ev1_cams=barcode_crop_cams, ev2_cams=last_event_cams, max_th=1.3)
            else:
                if self.debug:
                    print('BarcodeHandler DEBUG: Event-Barcode not-similar: No descriptors compared', flush=True)
                return False

    def set_stream(self, mode):
        '''
        Simple place-holder for changing FPS - toggle skip/no skip mode
        skip - equivalent to 10FPS
        no skip - equivalent to 20FPS
        '''
        if self.mode_change_triggered:
            return
        if self.use_cam_scanner:
            if mode=='Barcode':
                self.should_skip_frame = True
                self.md_module.stream.set_barcode_viz(True)
            elif mode=='Default':
                self.should_skip_frame = False
                self.md_module.stream.set_barcode_viz(False)
                if hasattr(self.md_module, 'crop_for_barcode'):
                    self.md_module.crop_for_barcode = None
        self.mode_change_triggered = True
        if self.debug:
            print('BarcodeHandler DEBUG: Setting stream mode: %s' % mode, flush=True)

    def is_stream_ready(self):
        # TODO - what indication do we need here?
        ret = True
        # Turn off trigger flag
        if ret and self.mode_change_triggered:
            self.mode_change_triggered = False
        return ret

    def is_seq_scanned(self, cls_seq, seq_result):
        '''
        This method is responsible for deciding if the recent barcode scan is
        the same sequence that was just classified.
        In the future it will be done by tracking the product from the scanning frame
        or compare it in some similarity metric.
        Currently it is just a simple place holder
        '''
        event_type, last_event = seq_result[:2]
        if self.state==BarcodeHandlerState.InsertionPending and cls_seq['event_direction']=='in':
            event_marked_during_barcode_scan = cls_seq['marked_during_barcode_scan']
            event_similar_to_barcode_result = \
                self.event_vs_barcode_similar(last_event, self.curr_barcode_event['scanned_barcode'], event_marked_during_barcode_scan, last_event_info=cls_seq)
            if self.curr_algo_verified_event is not None:
                # Insertion after algo trigger-> removal -> barcode scan:
                # 1. Compare original insertion vs. insertion after barcode scan
                # 2. Compare barcode scan vs. insertion after barcode scan
                valid_insert = self.event_vs_event_similar(last_event, self.curr_algo_verified_event, last_event_info=cls_seq) and event_similar_to_barcode_result
            else:
                # Insertion after user trigger-> barcode scan:
                # 1. Compare barcode scan vs. insertion after barcode scan
                valid_insert = event_similar_to_barcode_result
            # Error handler
            if valid_insert:
                self.remove_barcode_error(BarcodeError.BarcodeInsertErrOnInsert)
            else:
                if event_type not in (EventType.HandEvent, EventType.FilteredEvent):
                    self.add_barcode_error(BarcodeError.BarcodeInsertErrOnInsert)
            # Handle products out of catalog
            if self.curr_barcode_event is not None and 'out_of_catalog_bc' is self.curr_barcode_event:
                if self.curr_barcode_event['out_of_catalog_bc']['valid']:
                    valid_insert = False

            if self.params.enable_marking_invalid_events:
                cls_seq['mark_for_validation'] = not valid_insert
                self.curr_barcode_event['marked_event'] = not valid_insert
                return True
            else:
                return valid_insert
        elif self.state in (BarcodeHandlerState.RemovalPending, BarcodeHandlerState.ScanB4Remove) and cls_seq['event_direction']=='out':
            # Removal after algo trigger:
            # 1. Compare original insertion vs. removal
            valid_removal = self.event_vs_event_similar(last_event, self.curr_algo_verified_event, last_event_info=cls_seq)
            if valid_removal:
                self.remove_barcode_error(BarcodeError.BarcodeInsertErrOnRemove)
            else:
                if event_type not in (EventType.HandEvent, EventType.FilteredEvent):
                    self.add_barcode_error(BarcodeError.BarcodeInsertErrOnRemove)
            return valid_removal
        else:
            return False

    def mark_barcode_mv(self, pos_only=False):
        '''
        Mark mv of product being scanned for later verification
        '''
        # Ignore if using an external scanner
        if not self.use_cam_scanner:
            return
        for cam_name, barcode_roi in self.initial_barcode_roi.items():
            best_mv_id, best_box = self.md_module.mv_manager.match_mv_to_roi(cam_name, barcode_roi)
            if best_mv_id is not None and self.box_in_barcode_roi(best_box, cam_name):
                mv_list = [best_mv_id]
            else:
                mv_list = []
            if not pos_only or len(mv_list) > 0:
                self.curr_barcode_event['scanned_mv_id'][cam_name] = mv_list
                self.md_module.mv_manager.mark_as_barcode_scanned(cam_name, mv_list)
                self.md_module.object_tracker[cam_name].ids_to_force_tracking = mv_list
            # Add image to barcode item images for future similarity check
            if len(mv_list) > 0:
                mv_id = mv_list[0]
                marked_mv = self.md_module.mv_manager.get_mv_by_id(cam_name, mv_id)
                cam_img_during_scan = self.curr_barcode_event['product_img_during_scan'][cam_name]

                add_all_mv = len(cam_img_during_scan)==0# or marked_mv.head() not in cam_img_during_scan
                if add_all_mv:
                    # Add first
                    cam_img_during_scan.append(marked_mv.mv_element_list[0])
                    # Add other with IOU smaller than th
                    for mv_el in marked_mv.mv_element_list[1:]:
                        if BoundingBox2D.iou(mv_el.coords, cam_img_during_scan[-1].coords) < self.params.barcode_crop_max_iou:
                            cam_img_during_scan.append(mv_el)
                else:
                    marked_mv_el = marked_mv.tail()
                    if marked_mv_el.global_frame_number > cam_img_during_scan[-1].global_frame_number and \
                        BoundingBox2D.iou(marked_mv_el.coords, cam_img_during_scan[-1].coords) < self.params.barcode_crop_max_iou:
                        cam_img_during_scan.append(marked_mv_el)
    
    def is_algo_trigger_allowed(self, cls_seq, seq_result):
        '''
        Logic describing scenarios when algo trigger is allowed
        Current logic is very simple heuristic: don't allow another trigger around scan
        TODO: use barcode scan box locations and descriptors to identify similar events
        '''
        ref_frame = self.md_module.global_frame_num if self.state==BarcodeHandlerState.BarcodePending else \
            self.last_scanned_barcode_frame
        if abs(ref_frame - cls_seq['event_frame']) < self.params.disable_triggers_n_frames_around_scan:
            if self.debug:
                print('BarcodeHandler DEBUG: Rejected Algo Barcode trigger: Event %d[Frame %d]' % \
                     (cls_seq['event_id'], cls_seq['event_frame']), flush=True)
            return False
        return True
            
    
    def clear_barcode_mv(self):
        if hasattr(self, 'initial_barcode_roi'):
            for cam_name in self.initial_barcode_roi.keys():
                if self.curr_barcode_event is not None:
                    self.curr_barcode_event['scanned_mv_id'][cam_name] = []
                self.md_module.mv_manager.mark_as_barcode_scanned(cam_name, [])
                self.md_module.object_tracker[cam_name].ids_to_force_tracking = []
    
    def get_resolved_event_id(self):
        if self.curr_barcode_event is not None and self.curr_barcode_event['trigger']=='internal':
            return self.curr_barcode_event['barcode_event_id']
        else:
            return -1
    
    def add_barcode_error(self, err):
        if hasattr(self.md_module, 'cart_content_handler'):
            if self.curr_barcode_event is not None and hasattr(self.curr_barcode_event, 'curr_error'):
                if err!=self.curr_barcode_event['curr_error']:
                    self.curr_barcode_event['all_errors'].append(err)
                    self.curr_barcode_event['curr_error'] = err
                    # Add Barcode error indication
                    if self.params.send_bc_err_to_cart:
                        event_id = self.curr_barcode_event['barcode_event_id']
                        err_msg = BarcodeErrMessage[err.name]
                        self.md_module.cart_content_handler.add_barcode_error(event_id, err_msg)
            else:
                if self.params.send_bc_err_to_cart:
                    err_msg = BarcodeErrMessage[err.name]
                    self.md_module.cart_content_handler.add_barcode_error(-1, err_msg)

    def remove_barcode_error(self, err):
        if hasattr(self.md_module, 'cart_content_handler'):
            if err==self.curr_barcode_event['curr_error']:
                self.curr_barcode_event['curr_error'] = None
                # Remove Barcode error indication
                event_id = self.curr_barcode_event['barcode_event_id']
                self.md_module.cart_content_handler.remove_barcode_error(event_id)
    
    def clear_warnings(self):
        if hasattr(self.md_module, 'cart_content_handler'):
            if self.curr_barcode_event['curr_error'] in BarcodeWarning:
                event_id = self.curr_barcode_event['barcode_event_id']
                self.md_module.cart_content_handler.remove_barcode_error(event_id)

class BarcodeImgLogger(object):  
    def __init__(self, data=None):
        self.data = data['bc_img_vector']

    @staticmethod
    def pack(bc_mve):
        ret_list = []
        for _, val in bc_mve.items():
            ret_list += [v.pack() for v in val]

        ret_dict = dict(bc_img_vector=ret_list)
        return ret_dict

    @staticmethod
    def unpack(data):
        from cv_blocks.events.movement_vector import MVElement
        ret_dict = dict()
        for k, val in data.items():
            if k=='bc_img_vector':
                ret_dict[k] = [MVElement.unpack(v) for v in val]
            else:
                ret_dict[k] = val

        return BarcodeImgLogger(data=ret_dict)

    def visualize(self, path=None, prefix='bc_img_vector', timestamp=None):
        if path is not None:
            import os
            mv_path = os.path.join(path, prefix+'_frame_%05d_ts_%s' % (self.data[0].global_frame_number, timestamp))
            os.makedirs(mv_path, exist_ok=True)
        else:
            mv_path = None
        for img_idx, img_el in enumerate(self.data):
            img_path = mv_path + '/img_%02d.png' % img_idx if path is not None else None
            img_el.visualize(path=img_path)
    
if __name__=='__main__':
    from cv_blocks.benchmarks.product_classifier.utils import MotionDetectLight
    md_module = MotionDetectLight()
    md_module.imgs_in_queue = 0
    bh = BarcodeHandler(md_module, debug=True, use_cam_scanner=False)
    print('Valid User flow:')
    print('================')
    event_id = 0
    init_req = dict(cmd='barcode_event_info', payload=dict(msg_type='new_event_request', trigger='user'))
    bh.write_message(init_req);bh.step()
    set_man_req = dict(cmd='barcode_event_info', payload=dict(msg_type='set_barcode_mode', event_ID=event_id, mode='manual'))
    bh.write_message(set_man_req);bh.step();bh.step()
    scan_msg = dict(cmd='barcode_event_info', payload=dict(msg_type='barcode_scanned', scan_type='manual', event_ID=event_id, barcode='9832', product_code='acb'))
    bh.write_message(scan_msg);bh.step();bh.step()
    close_req = dict(cmd='barcode_event_info', payload=dict(msg_type='close_event_request', event_ID=event_id, reason='cancel'))
    bh.write_message(close_req);bh.step();bh.step()

    print('Invalid User flow - multiple init requests:')
    print('===========================================')
    event_id = 1
    init_req = dict(cmd='barcode_event_info', payload=dict(msg_type='new_event_request', trigger='user'))
    bh.write_message(init_req);bh.write_message(init_req);bh.step()
    bh.write_message(init_req);bh.write_message(init_req);bh.step()

    set_man_req = dict(cmd='barcode_event_info', payload=dict(msg_type='set_barcode_mode', event_ID=event_id, mode='manual'))
    bh.write_message(set_man_req);bh.step();bh.step()
    scan_msg = dict(cmd='barcode_event_info', payload=dict(msg_type='barcode_scanned', scan_type='manual', event_ID=event_id, barcode='9832', product_code='acb'))
    bh.write_message(scan_msg);bh.step();bh.step()
    close_req = dict(cmd='barcode_event_info', payload=dict(msg_type='close_event_request', event_ID=event_id, reason='cancel'))
    bh.write_message(close_req);bh.step();bh.step()


    print('Invalid User flow - multiple init-set-scanned:')
    print('==============================================')
    event_id = 2
    init_req = dict(cmd='barcode_event_info', payload=dict(msg_type='new_event_request', trigger='user'))
    set_man_req = dict(cmd='barcode_event_info', payload=dict(msg_type='set_barcode_mode', event_ID=event_id, mode='manual'))
    scan_msg = dict(cmd='barcode_event_info', payload=dict(msg_type='barcode_scanned', scan_type='manual', event_ID=event_id, barcode='9832', product_code='acb'))
    bh.write_message(init_req);bh.step()
    bh.write_message(set_man_req);bh.write_message(scan_msg)
    bh.write_message(init_req);bh.write_message(set_man_req);bh.write_message(scan_msg)
    for _ in range(10):
        bh.step()

    close_req = dict(cmd='barcode_event_info', payload=dict(msg_type='close_event_request', event_ID=event_id, reason='cancel'))
    bh.write_message(close_req);bh.step();bh.step()
