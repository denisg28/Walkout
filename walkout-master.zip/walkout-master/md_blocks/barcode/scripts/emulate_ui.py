import socket
import os
import json
import time

INIT_EVENT = {'cmd':'barcode_event_info', 'payload': {'msg_type': 'new_event_request'}}
SET_CAMERA_BARCODE = {'cmd':'barcode_event_info', 'payload':{'msg_type': 'set_barcode_mode', 'event_ID': 0, 'mode': 'camera'}}
SET_CAMERA_KEYBOARD = {'cmd':'barcode_event_info', 'payload':{'msg_type': 'set_barcode_mode', 'event_ID': 0, 'mode': 'manual'}}
MANUAL_BC = {'cmd': 'barcode_event_info', 'payload': {'msg_type': 'barcode_scanned', 'event_ID': 0, 'scan_type': 'manual', 'barcode': '5600286004089'}}
CANCEL_EVENT = {'cmd':'barcode_event_info', 'payload':{'msg_type': 'close_event_request', 'event_ID': 11, 'reason': 'cancel'}} 

MARK_INSERT = {'cmd':'barcode_event_info', 'payload':{'msg_type': 'item_activity_marked', 'event_ID': 1, 'action': 'insert'}}
PRODUCT_EVENT_1 = {'cmd':'barcode_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 0, 'product_code': '5000159304245', 'quantity': 2}}
PRODUCT_EVENT_2 = {'cmd':'barcode_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 0, 'product_code': '8410076610508', 'quantity': 3}}
PRODUCT_EVENT_3 = {'cmd':'barcode_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 0, 'product_code': '7290015675284', 'quantity': 1}}
EXTEND_EVENT =  {'cmd':'barcode_event_info', 'payload':{'msg_type': 'extend_event', 'event_ID': 0}}
FINISH_EVENT =  {'cmd':'barcode_event_info', 'payload':{'msg_type': 'finish_event', 'event_ID': 0, 'reason': 'done'}}

def wait_for_message(conn, msg_type='barcode_event_info'):
    while True:
        data = conn.recv(1024)
        data_decode = json.loads(data.decode('utf-8'))
        if 'cmd' in data_decode and data_decode['cmd']==msg_type:
            break
    
    return data_decode
# Connect to socket
my_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
try:
    os.remove('/tmp/unixSocket')
except:
    pass
my_socket.bind('/tmp/unixSocket')
my_socket.listen()
# Wait until we have a connection
print('Waiting for valid connection')
conn, addr = my_socket.accept()

def flow1_cam():
    # Flow 1 - generic flow with button, single product, camera scanner enabled
    # Send init event request
    print('Sending init event request-Flow 1')
    conn.sendall(json.dumps(INIT_EVENT).encode('utf-8'))

    print('Waiting for init event message from MD')
    init_message = wait_for_message(conn)
    print('Recieved message from MD:', init_message)

    print('Sending set barcode mode - camera')
    conn.sendall(json.dumps(SET_CAMERA_BARCODE).encode('utf-8'))

    print('Waiting for barcode scanned event message from MD')
    scan_message = wait_for_message(conn)
    print('Recieved message from MD:', scan_message)

    print('Waiting for product insert_item from MD')
    insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', insert_message)

    print('Waiting for barcode done event message from MD')
    finish_message = wait_for_message(conn)
    print('Recieved message from MD:', finish_message)

def flow1_keyboard():
    # Flow 1 - generic flow with button, single product, barcode comes from user
    # Send init event request
    print('Sending init event request-Flow 1')
    conn.sendall(json.dumps(INIT_EVENT).encode('utf-8'))

    print('Waiting for init event message from MD')
    init_message = wait_for_message(conn)
    print('Recieved message from MD:', init_message)

    print('Sending set barcode mode - keyboard')
    conn.sendall(json.dumps(SET_CAMERA_KEYBOARD).encode('utf-8'))

    time.sleep(0.5)
    print('Sending result of barcode type - keyboard')
    conn.sendall(json.dumps(MANUAL_BC).encode('utf-8'))

    print('Waiting for product insert_item from MD')
    insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', insert_message)

    print('Waiting for barcode done event message from MD')
    finish_message = wait_for_message(conn)
    print('Recieved message from MD:', finish_message)

def flow1_cancel():
    # Flow 1 - press button, scan, then cancel
    # Send init event request
    print('Sending init event request-Flow 1')
    conn.sendall(json.dumps(INIT_EVENT).encode('utf-8'))

    print('Waiting for init event message from MD')
    init_message = wait_for_message(conn)
    print('Recieved message from MD:', init_message)

    print('Sending set barcode mode - camera')
    conn.sendall(json.dumps(SET_CAMERA_BARCODE).encode('utf-8'))

    print('Waiting for barcode scanned event message from MD')
    scan_message = wait_for_message(conn)
    print('Recieved message from MD:', scan_message)

    print('Sending cancel request')
    conn.sendall(json.dumps(CANCEL_EVENT).encode('utf-8'))

    print('Waiting for barcode done event message from MD')
    finish_message = wait_for_message(conn)
    print('Recieved message from MD:', finish_message)

if __name__=='__main__':
    # flow1_cam()
    # flow1_keyboard()
    flow1_cancel()