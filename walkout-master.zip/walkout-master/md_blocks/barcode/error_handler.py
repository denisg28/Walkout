import enum
from md_blocks.barcode.barcode_handler import BarcodeHandlerState

class BarcodeError(enum.Enum):
    BarcodeInsertTimeOutOnInsert = 1
    BarcodeInsertErrOnInsert = 2
    BarcodeInsertStopOnInsert = 3
    BarcodeInsertTimeOutOnScan = 4 # Not sure it's illegal
    BarcodeInsertErrOnScan = 5
    BarcodeInsertStopOnScan = 6 # Not sure it's illegal
    BarcodeInsertTimeOutOnRemove = 7
    BarcodeInsertErrOnRemove = 8
    BarcodeInsertStopOnRemove = 9
    BarcodeRemoveErrOnScan = 10
    BarcodeRemoveTimeOutOnScan = 11
    BarcodeRemoveStopOnScan = 12

class BarcodeWarning(enum.Enum):
    BarcodeInsertOtherInsert = 1
    BarcodeInsertOtherRemove = 2
    BarcodeRemoveOtherInsert = 3
    BarcodeRemoveOtherRemove = 4
    BarcodeScanNotFound = 5

# TODO - Implement real error messages
BarcodeErrMessage = dict()
for err_type in BarcodeError:
    BarcodeErrMessage[err_type.name] = err_type.name
for err_type in BarcodeWarning:
    BarcodeErrMessage[err_type.name] = 'Warning:' + err_type.name

def handle_invalid_close(close_type, event_state, event_dir):
    assert close_type in ('timeout', 'cancel', 'done', 'failure')
    if close_type=='done':
        return True, None, None
    valid = True # default case
    err = None
    if close_type=='timeout':
        if event_state==BarcodeHandlerState.InsertionPending:
            assert event_dir=='in'
            valid = False
            err = BarcodeError.BarcodeInsertTimeOutOnInsert
        elif event_state==BarcodeHandlerState.RemovalPending:
            assert event_dir=='in'
            valid = False
            err = BarcodeError.BarcodeInsertTimeOutOnRemove
        elif event_state==BarcodeHandlerState.BarcodePending:
            valid = False
            if event_dir=='in':
                valid = True
                # err = BarcodeError.BarcodeInsertTImeOutOnScan
            else:
                valid = False
                err = BarcodeError.BarcodeRemoveTimeOutOnScan
    else:
        if event_state==BarcodeHandlerState.InsertionPending:
            assert event_dir=='in'
            valid = False
            err = BarcodeError.BarcodeInsertStopOnInsert
        elif event_state==BarcodeHandlerState.RemovalPending:
            assert event_dir=='in'
            valid = False
            err = BarcodeError.BarcodeInsertStopOnRemove
        elif event_state==BarcodeHandlerState.BarcodePending:
            valid = False
            if event_dir=='in':
                valid = True
                # err = BarcodeError.BarcodeInsertStopOnScan
            else:
                valid = False
                err = BarcodeError.BarcodeRemoveStopOnScan
    
    err_msg = None if valid else BarcodeErrMessage[err.name]
    return valid, err, err_msg