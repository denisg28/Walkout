from misc import print_formatted_message

class MDMessages(object):
    @staticmethod
    def log_md_algo_info(config, n_classes):
        neural_net_version = dict(product_classifier=config.LATEST_YAEEN_TRT_MODEL_NAME,
                                  product_detector=config.LATEST_DETECTOR_TRT_MODEL_NAME,
                                  diff_detector=config.DEFAULT_DIFF_DETECTOR_WEIGHTS,
                                  event_detector=config.DEFAULT_EVENT_DETECTOR_WEIGHTS,
                                  in_out_classifier=config.DEFAULT_CART_IN_OUT_CLASSIFIER_WEIGHTS)
        data = dict(event_type='md_algo_info',
                    event_id=-1,
                    event_payload=dict(neural_net_version=neural_net_version,
                                       n_products_supported=n_classes,
                                       sw_version=None, # TODO
                                    )
        )
        print_formatted_message(data)
    
    @staticmethod
    def log_md_failure(err_message, source='general'):
        data = dict(event_type='md_crash',
                    event_id=-1,
                    event_payload=dict(message=err_message,
                                       source=source,
                                    )
        )
        print_formatted_message(data)

    @staticmethod
    def log_md_warning(err_message, source='general'):
        data = dict(event_type='md_warning',
                    event_id=-1,
                    event_payload=dict(message=err_message,
                                       source=source,
                                    )
        )
        print_formatted_message(data)