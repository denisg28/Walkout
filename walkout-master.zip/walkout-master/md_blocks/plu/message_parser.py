import enum

class PLUHandlerEvent(enum.Enum):
    Empty = -1
    NewEventRequest = 1
    InitEvent = 2
    ItemActivityDetected = 3
    ItemActivityMarked = 4
    AddProduct = 5
    ExtendEvent = 6
    FinishEvent = 7

msg2enum_map = dict(new_event_request=PLUHandlerEvent.NewEventRequest,
                    init_event=PLUHandlerEvent.InitEvent, 
                    item_activity_detected=PLUHandlerEvent.ItemActivityDetected,
                    item_activity_marked=PLUHandlerEvent.ItemActivityMarked,
                    add_product=PLUHandlerEvent.AddProduct,
                    extend_event=PLUHandlerEvent.ExtendEvent,
                    finish_event=PLUHandlerEvent.FinishEvent,
)
enum2msg_map = {v:k for k, v in msg2enum_map.items()}

def parse_message(raw_message):
    assert isinstance(raw_message, dict) and raw_message['cmd']=='plu_event_info'
    message = raw_message['payload']
    # convert message type to enum
    event = msg2enum_map[message['msg_type']]
    metadata = message
    return event, metadata

def compose_message(event, metadata):
    raw_message = dict(cmd='plu_event_info', payload=metadata)
    msg_type = enum2msg_map[event]
    raw_message['payload']['msg_type'] = msg_type
    return raw_message