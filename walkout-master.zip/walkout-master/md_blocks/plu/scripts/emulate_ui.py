import socket
import os
import json
import time

INIT_EVENT = {'cmd':'plu_event_info', 'payload': {'msg_type': 'new_event_request'}}
MARK_INSERT = {'cmd':'plu_event_info', 'payload':{'msg_type': 'item_activity_marked', 'event_ID': 1, 'action': 'insert'}}
PRODUCT_EVENT_1 = {'cmd':'plu_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 0, 'product_code': '5000159304245', 'quantity': 2}}
PRODUCT_EVENT_2 = {'cmd':'plu_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 0, 'product_code': '8410076610508', 'quantity': 3}}
PRODUCT_EVENT_3 = {'cmd':'plu_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 0, 'product_code': '7290015675284', 'quantity': 1}}
EXTEND_EVENT =  {'cmd':'plu_event_info', 'payload':{'msg_type': 'extend_event', 'event_ID': 0}}
FINISH_EVENT =  {'cmd':'plu_event_info', 'payload':{'msg_type': 'finish_event', 'event_ID': 0, 'reason': 'done'}}

def wait_for_message(conn, msg_type='plu_event_info'):
    while True:
        data = conn.recv(1024)
        data_decode = json.loads(data.decode('utf-8'))
        if 'cmd' in data_decode and data_decode['cmd']==msg_type:
            break
    
    return data_decode
# Connect to socket
my_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
try:
    os.remove('/tmp/unixSocket')
except:
    pass
my_socket.bind('/tmp/unixSocket')
my_socket.listen()
# Wait until we have a connection
print('Waiting for valid connection')
conn, addr = my_socket.accept()

def flow1():
    # Flow 1 - generic flow with button, single product
    # Send init event request
    print('Sending init event request-Flow 1')
    conn.sendall(json.dumps(INIT_EVENT).encode('utf-8'))

    print('Waiting for init event message from MD')
    init_message = wait_for_message(conn)
    print('Recieved message from MD:', init_message)

    print('Waiting for product inserted message from MD')
    insert_message = wait_for_message(conn)
    print('Recieved message from MD:', insert_message)

    print('Sending product + quantity of plu to MD')
    conn.sendall(json.dumps(PRODUCT_EVENT_1).encode('utf-8'))

    time.sleep(1)
    print('Sending Finish command')
    conn.sendall(json.dumps(FINISH_EVENT).encode('utf-8'))

    print('Waiting for product insert_item from MD')
    insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', insert_message)

def flow2():
    # Flow 2 - generic flow with button, multiple product
    # Send init event request
    print('Sending init event request-Flow 2')
    conn.sendall(json.dumps(INIT_EVENT).encode('utf-8'))

    print('Waiting for init event message from MD')
    init_message = wait_for_message(conn)
    print('Recieved message from MD:', init_message)

    print('Waiting for product inserted message from MD')
    insert_message = wait_for_message(conn)
    print('Recieved message from MD:', insert_message)

    print('Sending product + quantity of plu to MD - 1')
    conn.sendall(json.dumps(PRODUCT_EVENT_1).encode('utf-8'))
    time.sleep(0.5)
    print('Sending extend_event')
    conn.sendall(json.dumps(EXTEND_EVENT).encode('utf-8'))
    time.sleep(0.5)
    print('Sending product + quantity of plu to MD - 2')
    conn.sendall(json.dumps(PRODUCT_EVENT_2).encode('utf-8'))
    time.sleep(0.5)
    print('Sending extend_event')
    conn.sendall(json.dumps(EXTEND_EVENT).encode('utf-8'))
    time.sleep(0.5)
    print('Sending product + quantity of plu to MD - 3')
    conn.sendall(json.dumps(PRODUCT_EVENT_3).encode('utf-8'))
    time.sleep(0.5)
    print('Sending Finish command')
    conn.sendall(json.dumps(FINISH_EVENT).encode('utf-8'))

    print('Waiting for product insert_item X 3 from MD')
    insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', insert_message)
    insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', insert_message)
    insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', insert_message)

def flow3_plu():
    # Flow 2 - insert product -> algo trigger -> press PLU -> complete event
    # Send init event request
    print('Starting Flow 3')
    print('Waiting for insert_item with event_type=10 from MD')
    unid_insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', unid_insert_message)
    assert unid_insert_message['payload']['event_type']==10

    REDIRECT_PLU_EVENT =  {'cmd':'update_item', 'payload':{'itemCount': -1, 'event_ID': 0, 'event_type': 7, 'product': 'plu_item_pending'}}
    print('Sending init event request-Flow 1')
    conn.sendall(json.dumps(REDIRECT_PLU_EVENT).encode('utf-8'))

    print('Waiting for init event message from MD')
    init_message = wait_for_message(conn)
    print('Recieved message from MD:', init_message)

    time.sleep(0.5)
    print('Sending product + quantity of plu to MD')
    conn.sendall(json.dumps(PRODUCT_EVENT_1).encode('utf-8'))

    time.sleep(1)
    print('Sending Finish command')
    conn.sendall(json.dumps(FINISH_EVENT).encode('utf-8'))

    print('Waiting for product insert_item from MD')
    insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', insert_message)
    assert unid_insert_message['payload']['event_type']==8
    time.sleep(1)

def flow3_barcode():
    # Flow 2 - insert product -> algo trigger -> press PLU -> complete event
    # Send init event request
    print('Starting Flow 3')
    print('Waiting for insert_item with event_type=10 from MD')
    unid_insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', unid_insert_message)
    assert unid_insert_message['payload']['event_type']==10

    REDIRECT_PLU_EVENT =  {'cmd':'update_item', 'payload':{'itemCount': -1, 'event_ID': 0, 'event_type': 7, 'product': 'barcode_item_pending'}}
    print('Sending init event request-Flow 1')
    conn.sendall(json.dumps(REDIRECT_PLU_EVENT).encode('utf-8'))

    print('Waiting for insert_item with event_type=5 from MD')
    unid_insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', unid_insert_message)
    assert unid_insert_message['payload']['event_type']==5

    print('Waiting for revert_event_action from MD')
    unid_revert_message = wait_for_message(conn, msg_type='revert_event_action')
    print('Recieved message from MD:', unid_revert_message)

    print('Waiting for scan message from MD')
    unid_revert_message = wait_for_message(conn, msg_type='barcode_scanner_output')
    print('Recieved message from MD:', unid_revert_message)

    print('Waiting for insert_item with event_type=6 from MD')
    unid_insert_message = wait_for_message(conn, msg_type='insert_item')
    print('Recieved message from MD:', unid_insert_message)
    assert unid_insert_message['payload']['event_type']==6

    time.sleep(0.5)
    CLOSE_BC_EVENT =  {'cmd':'set_barcode_mode', 'payload':{'set_value': 0, 'timeout': False}}
    print('Sending close barcode event')
    conn.sendall(json.dumps(CLOSE_BC_EVENT).encode('utf-8'))
    time.sleep(0.5)


if __name__=='__main__':
    # flow1()
    # flow2()
    # flow3_plu()
    flow3_barcode()