import enum
from md_blocks.plu.message_parser import parse_message, compose_message, PLUHandlerEvent
from md_blocks.md_messages import MDMessages
import traceback

class PLUHandlerState(enum.Enum):
    Idle = -1
    PluInitEventInternal = 1
    PluInitEventUser = 2
    PluPendingItemInsert = 3
    PluPendingProductUpdate = 4
    PluUpdateProduct = 5
    PluFinishEvent = 6

class PLUEventState(enum.Enum):
    # Initial state of insertion event where plu triggered by algo
    PendingInside = 0
    # 2 possible cases:
    # 1. Initial state of removal event where plu triggered by algo
    # 2. Initial state of user plu trigger
    PendingOutside = 1
    # Final state of (user, algo in)
    VerifiedInside = 2
    # Final state algo out
    VerifiedOutside = 3

class PLUHandler:
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.target_fps_plu = config.get('target_fps_plu', 10) # TODO - replace with valid params

    def __init__(self, md_module, debug=True, logger=None, ph_config=dict()):
        self.params = self.Config(ph_config)
        self.state = PLUHandlerState.Idle
        self.md_module = md_module
        self.input_messages = []
        self.debug = debug
        self.plu_event_id = 0
        self.curr_plu_event = None
        self.logger = logger
        if logger is not None:
            from cv_blocks.misc.logger import MarkedEventLogger
            self.mel = MarkedEventLogger
    
    def reset(self):
        self.state = PLUHandlerState.Idle
        self.input_messages = []
        self.plu_event_id = 0
        self.curr_plu_event = None
    
    def push_message(self, msg):
        self.input_messages.append(msg)
        if self.debug:
            print('PLUHandler DEBUG[%d]: recieved API message: ' % self.md_module.global_frame_num, msg, flush=True)


    def is_idle(self):
        return self.state==PLUHandlerState.Idle

    def step(self):
        '''
        Entry point to PLU handler
        '''
        try:
            # Get indication from MD Module
            # =============================
            event, metadata = self.read_message()

            # Propagate state
            # ===============
            next_state = self.get_next_state(event, metadata)
            self.state = next_state

            # Perform state actions
            # =====================
            self.state_actions()
        except:
            MDMessages.log_md_warning(traceback.format_exc(), source='plu_handler')
    
    def read_message(self):
        if len(self.input_messages) > 0:
            raw_message = self.input_messages.pop(0)
            event, metadata = parse_message(raw_message)
            # Ignore messages with different ID than current active plu event
            if self.curr_plu_event is not None:
                if metadata['event_ID']!=self.curr_plu_event['event_id']:
                    if self.debug:
                        print('PLUHandler DEBUG[%d]: Ignoring API message due to invalid ID: ' % self.md_module.global_frame_num, raw_message, flush=True)
                    return PLUHandlerEvent.Empty, None
            return event, metadata
        else:
            return PLUHandlerEvent.Empty, None
    
    def send_message(self, event):
        '''
        Implement rules for each sent message in flow
        '''
        assert isinstance(event, PLUHandlerEvent) and self.curr_plu_event is not None
        if event==PLUHandlerEvent.InitEvent:
            metadata = dict(event_ID=self.curr_plu_event['event_id'],
                            skip_md_validation=self.curr_plu_event['skip_md_validation'],
                            direction=self.curr_plu_event['direction'])
            if self.curr_plu_event['direction']=='out':
                if 'plu_in_cart' in self.curr_plu_event:
                    metadata['products'] = self.curr_plu_event['plu_in_cart']
        elif event==PLUHandlerEvent.ItemActivityDetected:
            metadata = dict(event_ID=self.curr_plu_event['event_id'],
                            action='insert' if self.curr_plu_event['direction']=='in' else 'remove')

        raw_message = compose_message(event, metadata)

        if self.debug:
            print('PLUHandler DEBUG[%d]: sending message: ' % self.md_module.global_frame_num, raw_message, flush=True) 
        # Send message to UI
        if hasattr(self.md_module, 'gui'):
            self.md_module.gui.send(raw_message)
        # Log to capsule
        if self.logger is not None and self.logger.should_log('user_marked_event'):
            if event in (PLUHandlerEvent.InitEvent, PLUHandlerEvent.ItemActivityDetected):
                event_metadata = dict(action=event.name)
                if event==PLUHandlerEvent.InitEvent:
                    event_metadata['trigger'] = self.curr_plu_event['trigger']
                elif event==PLUHandlerEvent.ItemActivityDetected:
                    event_metadata['direction'] = self.curr_plu_event['direction']
                self.logger.log(self.mel.pack(self.curr_plu_event['event_id'], \
                    'PluEventOp', metadata=event_metadata), 'user_marked_event')

    def get_next_state(self, event, metadata):
        '''
        Logic defining transition between states according to messages
        '''
        next_state = self.state
        assert isinstance(event, PLUHandlerEvent)

        # Unexpected finish event - go to finish state
        if event==PLUHandlerEvent.FinishEvent and self.state!=PLUHandlerState.PluUpdateProduct:
            assert self.state!=PLUHandlerState.Idle
            assert metadata['reason']!='done'
            self.curr_plu_event['external_close'] = metadata['reason']
            next_state = PLUHandlerState.PluFinishEvent

        elif self.state==PLUHandlerState.Idle:
            assert event in (PLUHandlerEvent.Empty, PLUHandlerEvent.NewEventRequest)
            if event==PLUHandlerEvent.NewEventRequest:
                trigger = metadata['trigger'] if 'trigger' in metadata else 'user'
                assert trigger in ('user', 'internal')
                next_state = PLUHandlerState.PluInitEventUser if trigger=='user' else PLUHandlerState.PluInitEventInternal
        elif self.state in (PLUHandlerState.PluInitEventUser, PLUHandlerState.PluInitEventInternal):
            assert event==PLUHandlerEvent.Empty
            next_state = PLUHandlerState.PluPendingProductUpdate if self.curr_plu_event['skip_md_validation'] else \
                PLUHandlerState.PluPendingItemInsert
        elif self.state==PLUHandlerState.PluPendingItemInsert:
            assert event in (PLUHandlerEvent.Empty, PLUHandlerEvent.ItemActivityMarked, PLUHandlerEvent.AddProduct)
            if event==PLUHandlerEvent.ItemActivityMarked:
                self.curr_plu_event['insert_marked'] = True
            prod_insert = self.curr_plu_event['insert_marked'] or self.curr_plu_event['insert_detected']
            if prod_insert and event in (PLUHandlerEvent.Empty , PLUHandlerEvent.ItemActivityMarked):
                next_state = PLUHandlerState.PluPendingProductUpdate
            elif prod_insert and event==PLUHandlerEvent.AddProduct:
                next_state = PLUHandlerState.PluUpdateProduct
                self.add_plu_prodct_to_event(metadata)
        elif self.state==PLUHandlerState.PluPendingProductUpdate:
            assert event in (PLUHandlerEvent.Empty, PLUHandlerEvent.AddProduct) or event==PLUHandlerEvent.ItemActivityMarked
            if event==PLUHandlerEvent.AddProduct:
                next_state = PLUHandlerState.PluUpdateProduct
                self.add_plu_prodct_to_event(metadata)
            elif event==PLUHandlerEvent.ItemActivityMarked:
                # Bad flow caused from inserting product before choosing item: CART-2478
                pass
        elif self.state==PLUHandlerState.PluUpdateProduct:
            assert event in (PLUHandlerEvent.Empty, PLUHandlerEvent.ExtendEvent, PLUHandlerEvent.FinishEvent)
            if event==PLUHandlerEvent.FinishEvent:
                next_state = PLUHandlerState.PluFinishEvent
            elif event==PLUHandlerEvent.ExtendEvent:
                next_state = PLUHandlerState.PluPendingProductUpdate
        elif self.state==PLUHandlerState.PluFinishEvent:
            assert event==PLUHandlerEvent.Empty
            next_state = PLUHandlerState.Idle
        if self.debug and (next_state!=self.state or event!=PLUHandlerEvent.Empty):
            print('PLUHandler DEBUG[%d]: state transition: (%s-> %s) with message %s' \
                % (self.md_module.global_frame_num, self.state, next_state, event), flush=True)
        if next_state!=self.state and (self.curr_plu_event is not None and 'state_transitions' in self.curr_plu_event):
            self.curr_plu_event['state_transitions'].append(self.log_state_transition(next_state))
        
        return next_state
    
    def state_actions(self):
        '''
        Action to take for each state
        '''
        if self.state in (PLUHandlerState.PluInitEventUser, PLUHandlerState.PluInitEventInternal):
            if self.curr_plu_event is None:
                trigger = 'user' if self.state==PLUHandlerState.PluInitEventUser else 'internal'
                self.start_plu_event(trigger)
                self.send_message(PLUHandlerEvent.InitEvent)
        if self.state==PLUHandlerState.PluPendingItemInsert:
            item_inserted = self.check_for_item_insert()
            if item_inserted:
                self.curr_plu_event['insert_detected'] = True
                if hasattr(self.md_module, 'cart_content_handler'):
                    md_event_id = None
                    event_state = PLUEventState.PendingInside if len(self.curr_plu_event['products'])==0 else PLUEventState.VerifiedInside
                    if self.curr_plu_event['trigger']=='user':
                        assert self.curr_algo_verified_event is not None
                        md_event_id = self.curr_algo_verified_event['seq']['event_id'] 
                    self.md_module.cart_content_handler.update_plu_event_state(self.curr_plu_event['event_id'],
                                                                            self.curr_plu_event['trigger'],
                                                                            event_state,
                                                                            md_event_id=md_event_id)
                self.send_message(PLUHandlerEvent.ItemActivityDetected)
        elif self.state==PLUHandlerState.PluPendingProductUpdate:
            pass
            # do nothing?
        elif self.state==PLUHandlerState.PluUpdateProduct:
            if not self.curr_plu_event['products'][-1]['updated']:
                self.curr_plu_event['products'][-1]['updated'] = True
                if hasattr(self.md_module, 'cart_content_handler'):
                    event_state = PLUEventState.VerifiedInside if \
                        (self.curr_plu_event['insert_detected'] or self.curr_plu_event['insert_marked']) else PLUEventState.VerifiedOutside
                    self.md_module.cart_content_handler.update_plu_event_state(self.curr_plu_event['event_id'],
                                                                            self.curr_plu_event['trigger'],
                                                                            event_state,
                                                                            products=self.curr_plu_event['products'])
        elif self.state==PLUHandlerState.PluFinishEvent:
            self.finish_plu_event()

    def log_state_transition(self, state):
        return dict(state=state, frame=self.md_module.global_frame_num)

    def start_plu_event(self, trigger):
        # Event is considered internal if the pending plu event list is not empty
        # TODO - improve this logic
        # trigger = 'internal' if len(self.md_module.event_logic.special_item_handler.pending_verification_events['plu']) > 0 else 'user'
        self.curr_plu_event = dict(trigger=trigger)
        self.curr_plu_event['trigger_frame'] = self.md_module.global_frame_num
        self.curr_plu_event['products'] = []
        self.curr_plu_event['external_close'] = None
        self.curr_plu_event['state_transitions'] = [self.log_state_transition(PLUHandlerState.Idle)]
        if trigger=='user':
            self.curr_plu_event['event_id'] = self.plu_event_id
            self.curr_plu_event['direction'] = 'in'
            self.curr_plu_event['skip_md_validation'] = False
            self.curr_plu_event['insert_detected'] = False
            self.curr_plu_event['insert_marked'] = False
            self.curr_algo_verified_event = None
            self.plu_event_id += 1
            event_state = PLUEventState.PendingOutside
        else:
            self.curr_algo_verified_event = self.md_module.event_logic.special_item_handler.pending_verification_events['plu'].pop(0)
            direction = self.curr_algo_verified_event['seq']['event_direction']
            self.curr_plu_event['event_id'] = self.curr_algo_verified_event['seq']['event_id']
            self.curr_plu_event['direction'] = direction
            self.curr_plu_event['skip_md_validation'] = True
            self.curr_plu_event['insert_detected'] = True
            self.curr_plu_event['insert_marked'] = False
            event_state = PLUEventState.PendingOutside if direction=='out' else PLUEventState.PendingInside
            # For removal events, gather all current plu products in the cart
            if direction=='out' and hasattr(self.md_module, 'cart_content_handler'):
                self.curr_plu_event['plu_in_cart'] = self.md_module.cart_content_handler.gather_product_of_type_in_cart('plu')
        # Send indication to cart content
        if hasattr(self.md_module, 'cart_content_handler'):
            self.md_module.cart_content_handler.init_plu_event_state(self.curr_plu_event['event_id'],
                                                                     self.curr_plu_event['trigger'],
                                                                     self.curr_plu_event['direction'],
                                                                     event_state)
    
    def is_valid_close(self):
        if self.curr_plu_event['external_close'] is not None:
            if self.curr_plu_event['direction']=='in':
                if self.curr_plu_event['insert_detected'] or self.curr_plu_event['insert_marked']:
                    return False
            elif self.curr_plu_event['direction']=='out':
                return False
        return True

    def finish_plu_event(self):
        if hasattr(self.md_module, 'cart_content_handler'):
            valid_close = self.is_valid_close()
            # Force products into cart also w/o valid MD event
            force_products = len(self.curr_plu_event['products']) > 0 and self.curr_plu_event['insert_marked']
            self.md_module.cart_content_handler.close_plu_event(self.curr_plu_event['event_id'],
                                                                self.curr_plu_event['trigger'],
                                                                valid_close,
                                                                force_products=force_products)
        if self.logger is not None and self.logger.should_log('user_marked_event'):
            event_metadata = dict(action=PLUHandlerEvent.FinishEvent.name)
            event_metadata['external_close'] = self.curr_plu_event['external_close']
            self.logger.log(self.mel.pack(self.curr_plu_event['event_id'], \
                'PluEventOp', metadata=event_metadata), 'user_marked_event')
        self.curr_plu_event = None
    
    def add_plu_prodct_to_event(self, metadata):
        single_product = dict(product_code=metadata['product_code'], quantity=metadata['quantity'], updated=False)
        self.curr_plu_event['products'].append(single_product)
        
    def is_expecting_event(self, dir, frame, filtered_event):
        '''
        Simple logic to check if PLU item is expected
        '''
        # Make sure we are not checking event that occured before transition to current state
        if self.curr_plu_event is not None:
            if len(self.curr_plu_event['state_transitions']) > 0:
                frame_of_last_transition = self.curr_plu_event['state_transitions'][-1]['frame']
                if self.debug:
                    print('PLUHandler DEBUG: Checking if expecting event: dir:%s, event frame: %d. bc state transition' % \
                        (dir, frame), self.curr_plu_event['state_transitions'])
                if frame > frame_of_last_transition and self.state==PLUHandlerState.PluPendingItemInsert:
                    if self.debug:
                        print('PLUHandler DEBUG: expecting event: %r' % (True), flush=True) 
                    return True
        return False
    
    def check_for_item_insert(self):
        if len(self.md_module.event_logic.special_item_handler.pending_verification_events['plu'])==0:
            return False
        if self.md_module.event_logic.special_item_handler.pending_verification_events['plu'][0]['seq']['event_direction']=='in':
            self.curr_algo_verified_event = self.md_module.event_logic.special_item_handler.pending_verification_events['plu'].pop(0)
            return True
        return False
            

if __name__=='__main__':
    class md_module:
        def __init__(self):
            self.global_frame_num = 0

    md_dummy = md_module()
    my_plu_handler = PLUHandler(md_dummy)

    def _steps(n_steps):
        for _ in range(5):
            my_plu_handler.step(); md_dummy.global_frame_num += 1

    # Generric Flow 1 - single plu with button
    print('Generic Flow #1 logic')
    print('=====================')
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload': {'msg_type': 'new_event_request'}})
    _steps(2)
     # message with invalid ID
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'item_activity_marked', 'event_ID': 11, 'action': 'insert'}})
    _steps(1)
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'item_activity_marked', 'event_ID': 0, 'action': 'insert'}})
    _steps(1)
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 0, 'product_code': '5000159304245', 'quantity': 2}})
    _steps(5)
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'finish_event', 'event_ID': 0, 'reason': 'done'}})
    _steps(5)


    # Generric Flow 2 - multiple plu with button
    print('Generic Flow #2 logic')
    print('=====================')
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload': {'msg_type': 'new_event_request'}})
    _steps(2)
     # message with invalid ID
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'item_activity_marked', 'event_ID': 11, 'action': 'insert'}})
    _steps(1)
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'item_activity_marked', 'event_ID': 1, 'action': 'insert'}})
    for _ in range(5):
        _steps(1)
        my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 1, 'product_code': '5000159304245', 'quantity': 2}})
        _steps(5)
        my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'extend_event', 'event_ID': 1}})
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'add_product', 'event_ID': 1, 'product_code': '5000159304245', 'quantity': 2}})
    _steps(5)
    my_plu_handler.push_message({'cmd':'plu_event_info', 'payload':{'msg_type': 'finish_event', 'event_ID': 1, 'reason': 'done'}})
    _steps(5)