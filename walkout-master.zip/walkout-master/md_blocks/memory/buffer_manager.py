import numpy as np
try:
    import pycuda.driver as cuda
    import pycuda.autoinit  # noqa
except:
    import subprocess
    import sys
    print('Trying to install pycuda. script will exit after installation is finished')
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pycuda"])
    import pycuda.driver as cuda
    import pycuda.autoinit  # noqa

class BufferManager(object):
    '''
    A module responsible on all buffer allocations in the MD side
    '''
    def __init__(self, debug=False):
        self.cuda_driver = cuda
        self.buffers = dict()
        self.debug = debug
    
    def allocate(self, name, shape, dtype, managed=True):
        if name in self.buffers:
            if shape==self.buffers[name]['shape'] and dtype==self.buffers[name]['dtype']:
                if self.debug:
                    print('BufferManager Debug: Warning, Trying to allocate an existing buffer, Ignoring')
                return
            else:
                pass
                # release current buffer and re-allocate
                self.buffers[name]['buff'].base.free()
                del self.buffers[name]

        if managed:
            buff = self.cuda_driver.managed_empty(shape=shape, dtype=dtype, mem_flags=self.cuda_driver.mem_attach_flags.GLOBAL)
        else:
            buff = self.cuda_driver.pagelocked_empty(shape=shape, dtype=dtype)
        buff_type = 'managed' if managed else 'page-locked'
        buff_ptr, read_only = buff.__array_interface__['data']
        # Register buffer
        self.buffers[name] = \
        dict(buff=buff, ptr=buff_ptr, shape=shape, dtype=dtype, type=buff_type, size=buff.nbytes)

    def list_buff(self):
        print('List of allocated buffers:')
        for k, v in self.buffers.items():
            print('%s: shape=' % k ,v['shape'],', dtype=', v['dtype'], ', type=%s, ptr=%d' % (v['type'], v['ptr']))
    
    def buff_names(self):
        return list(self.buffers.keys())
    
    def get(self, name):
        return self.buffers[name]['buff']
    
    def pointer(self, name):
        return self.buffers[name]['ptr']

    def shape(self, name):
        return self.buffers[name]['shape']
    
    def init_buffer(self, name, init_object):
        buff_ptr = self.pointer(name)
        buff_shape = self.shape(name)
        (h, w) = buff_shape[:2]
        ch = 1 if len(buff_shape)==2 else buff_shape[2]
        return init_object(name, buff_ptr, h, w, ch)
    
    def init_buffer_list(self, names, init_object):
        ret = []
        for name in names:
            ret.append(self.init_buffer(name, init_object))
        return ret
    
    def allocate_default_cam_buffers(self, cam_sizes_dict):
        self.allocate('left_cam_raw', (int(cam_sizes_dict['height_left']), int(cam_sizes_dict['width_left']), 3), np.uint8)
        self.allocate('right_cam_raw', (int(cam_sizes_dict['height_right']), int(cam_sizes_dict['width_right']), 3), np.uint8)
        self.allocate('back_cam_raw', (int(cam_sizes_dict['height_back']), int(cam_sizes_dict['width_back']), 3), np.uint8)
    
    def allocate_default_vx_buffers(self, cam_sizes_dict, fd_detector=True):
        algo_shape_1d = (320, 240)
        algo_shape_3d = (320, 240, 3)
        algo_shape_4d = (320, 240, 4)
        self.allocate('spatial_th', algo_shape_1d, np.uint8)
        self.allocate('disparity', algo_shape_1d, np.uint8)
        self.allocate('grayL_resized', algo_shape_1d, np.uint8)
        self.allocate('grayB_resized', algo_shape_1d, np.uint8)
        self.allocate('frameL_resized', algo_shape_3d, np.uint8)
        self.allocate('frameB_resized', algo_shape_3d, np.uint8)
        self.allocate('cart_disp_mask', algo_shape_1d, np.uint8)
        self.allocate('left_remap', (int(cam_sizes_dict['width_left']), int(cam_sizes_dict['height_left']), 3), np.uint8) #transposed
        self.allocate('frameDelta', algo_shape_1d, np.uint8)
        self.allocate('frameDeltaBack', algo_shape_1d, np.uint8)
        self.allocate('frameDeltaMaskBack', algo_shape_1d, np.uint8)
        self.allocate('frameL_resized_masked', algo_shape_4d if fd_detector else algo_shape_3d, np.uint8)
        self.allocate('frameB_resized_masked', algo_shape_4d if fd_detector else algo_shape_3d, np.uint8)


if __name__=='__main__':
    my_buff_manager = BufferManager()
    my_buff_manager.allocate('left', (480, 640), np.uint8, managed=True)
    my_buff_manager.allocate('right', (640, 480), np.int32, managed=False)
    my_buff_manager.list_buff()