import misc
from config import config
import os
import cv2
import numpy as np
import yaml
import random
from cv_blocks.events.movement_vector import MVElement

class DatasetSaver(object):
    '''
    Module responsible for saving data for training & validation of network
    '''
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.save_product_detector_data = config.get('save_product_detector_data', 'selective')
            self.save_product_classifier_data = config.get('save_product_classifier_data', 'brute_force')
            self.save_event_detector_data = config.get('save_event_detector_data', 'selective')
            self.save_diff_detector_data = config.get('save_diff_detector_data', 'selective')
            self.save_single_crop_data = config.get('save_single_crop_data', 'ignore')
            self.save_every_detection_frame = config.get('save_every_detection_frame', 'ignore')
            for s in vars(self).values():
                assert s in ('brute_force', 'selective', 'ignore')
            self.save_hands = config.get('save_hands', True)
            # Selective mode parameters
            self.product_detector_conf_th = config.get('product_detector_conf_th', 0.5)
            self.product_detector_n_img_per_event = config.get('product_detector_n_img_per_event',  1)
            self.product_classifier_take_tracker_imgs = config.get('product_classifier_take_tracker_imgs',  False)
            self.diff_detector_conf_th = config.get('diff_detector_conf_th', 0.9)
            self.event_detector_conf_th_low = config.get('event_detector_conf_th_low', 0.1)
            self.event_detector_conf_th_high = config.get('event_detector_conf_th_high', 0.9)
            self.event_detector_keep_every_n_frame = config.get('event_detector_keep_every_n_frame', 8)
            self.event_detector_confident_keep_every_n_frame = config.get('event_detector_confident_keep_every_n_frame', 64)
            self.max_product_detector_test_frames_per_event = config.get('max_product_detector_test_frames_per_event', 3)
            self.crop_classifier_conf_th_low = config.get('crop_classifier_conf_th_low', 0.05)
            self.crop_classifier_conf_th_high = config.get('crop_classifier_conf_th_high', 0.95)

    def __init__(self, md_module, root_dir, movie_name, cart_config=None, ds_config=dict()):
        self.params = self.Config(ds_config)
        if self.params.save_every_detection_frame == 'brute_force':
            self.last_saved_image_frame = dict()
        self.md_module = md_module
        self.data_for_training = config.SAVE_DATASET_FOR_TRAINING
        if not self.data_for_training:
            self.potential_test_frames = dict(front=[], back=[])
            self.event_id_counter = 0
        self.event_logic_module = md_module.event_logic
        self.root_dir = root_dir
        self.movie_name = movie_name
        self.dataset_path = root_dir
        self.cart_config = cart_config
        # Initialize directories
        if self.params.save_product_detector_data!='ignore' or self.params.save_every_detection_frame != 'ignore':
            self.product_detector_dir = os.path.join(self.dataset_path, 'product_detector')
            os.makedirs(self.product_detector_dir, exist_ok=True)
        if self.params.save_product_classifier_data!='ignore':
            self.product_classifier_dir = os.path.join(self.dataset_path, 'product_classifier')
            os.makedirs(self.product_classifier_dir, exist_ok=True)
        if self.params.save_event_detector_data!='ignore':
            self.event_detector_dir = os.path.join(self.dataset_path, 'event_detector')
            os.makedirs(self.event_detector_dir, exist_ok=True)
        if self.params.save_diff_detector_data!='ignore':
            self.diff_detector_dir = os.path.join(self.dataset_path, 'diff_detector')
            os.makedirs(self.diff_detector_dir, exist_ok=True)
        if self.params.save_single_crop_data!='ignore':
            self.crop_classifier_dir = os.path.join(self.dataset_path, 'crop_classifier')
            os.makedirs(self.crop_classifier_dir, exist_ok=True)
            self.crop_classifier_module = self.md_module.event_classifier.margin_event_detector.in_out_decider.cls
        self.write_run_log()

    def write_run_log(self):
        log_path = os.path.join(self.dataset_path, '..', 'metadata.yaml')
        if os.path.exists(log_path):
            return
        nets_info = dict(product_classifier=config.LATEST_YAEEN_TRT_MODEL_NAME,
                         product_detector=config.LATEST_DETECTOR_TRT_MODEL_NAME,
                         event_detector=config.DEFAULT_EVENT_DETECTOR_WEIGHTS,
                         diff_detector=config.DEFAULT_DIFF_DETECTOR_WEIGHTS)
        version_info = misc.document_git_stat()
        data_info = dict(product_classifier=self.params.save_product_classifier_data,
                         product_detector=self.params.save_product_detector_data,
                         event_detector=self.params.save_event_detector_data,
                         diff_detector=self.params.save_diff_detector_data,
                         single_crops=self.params.save_single_crop_data)
        info = dict(nets_info=nets_info, version_info=version_info, data_info=data_info)
        yaml.dump(info, open(log_path, 'w'))

    def save_event_data(self, event_data):
        '''
        Save Event related data (product detector, product classifier)
        '''
        if self.md_module.stream.isRealTime:
            # due to saving of last movement vector + not overloading the system with savings of full frames at realtime
            raise NameError('saving for dataset is supported only not in realtime')

        movement_vec = event_data['movement_vector_for_saving']
        probabilities_mat = event_data['classification_prob_mat']
        event_id = event_data['review_id'] if event_data['review_id'] else event_data['event_id']

        # Save all possible data from event
        indices_to_save = [i for i in range(len(movement_vec))]
        class_of_interest = self.md_module.movie_script.get_class_of_interest_according_script(event_data['event_frame'])
        print('saving movement vector of size {} to class {}'.format(len(movement_vec),class_of_interest))

        if self.params.save_product_classifier_data!='ignore' or self.params.save_product_detector_data!='ignore':
            # If balanced data for product detector is enabled, keep 1 random nominal image for every marginal image
            if self.params.product_detector_n_img_per_event > 0:
                prod_detector_nominal_idx = self.get_random_img_idx(movement_vec)
            else:
                prod_detector_nominal_idx = []
            for idx in indices_to_save:
                item = movement_vec[idx]
                # use image from cart bottom also for producct classifier data
                if item.source=='CB':
                    item.dataset_image['cart_bottom_rgb_crop'] = item.cropped_image
                    item.dataset_image['cart_in_out'] = cv2.resize(item.cropped_image, (64, 64))
                probabilities = probabilities_mat[idx]
                maxIndexes = probabilities.argsort()[-2:][::-1]
                c1 = self.event_logic_module.idx2product(maxIndexes[0])
                p1 = probabilities[maxIndexes[0]]
                sample_name = '{}_event_id_{}_frame_{}_cam_{}_source_{}_cls_{}'.format \
                    (self.movie_name, event_id, item.global_frame_number, item.cam_name, item.source, class_of_interest)
                isHand = c1 == self.event_logic_module.params.hand_item_text
                seekHand = class_of_interest == self.event_logic_module.params.hand_item_text
                hand_to_be_saved = (seekHand or self.params.save_hands) and isHand
                if (not isHand) or hand_to_be_saved:
                    for img_type, image in item.dataset_image.items():
                        if img_type in ['front_full', 'front_frame_delta', 'front_mask',
                                        'back_full', 'back_frame_delta', 'back_mask']:
                            nn_type = 'product_detector'
                            should_save = self.should_save_product_detector(item) or idx in prod_detector_nominal_idx
                            if should_save:
                                save_dir = os.path.join(self.product_detector_dir, class_of_interest, img_type)
                        elif img_type == 'cart_in_out':
                            continue
                        else:
                            nn_type = 'product_classifier'
                            should_save = self.should_save_product_classifier(item)
                            if should_save:
                                save_dir = os.path.join(self.product_classifier_dir, class_of_interest, img_type)

                        
                        if should_save:
                            img_name = '{}_{}_{}'.format(nn_type, img_type, sample_name)
                            misc.save_image_to_disk(image, img_name , path=save_dir,add_date=False)
                            if img_type in ('front_frame_delta', 'back_frame_delta'):
                                # Save also detector v2 visualization
                                img_type_viz = img_type.replace('frame_delta', 'viz')
                                rgb_img = item.dataset_image[img_type.replace('frame_delta', 'full')]
                                fd_img = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
                                viz_img = np.hstack((rgb_img, fd_img))
                                img_name_viz = '{}_{}_{}'.format(nn_type, img_type_viz, sample_name)
                                save_dir_viz = os.path.join(self.product_detector_dir, class_of_interest, img_type_viz)
                                misc.save_image_to_disk(viz_img, img_name_viz , path=save_dir_viz,add_date=False)
        if self.params.save_single_crop_data and len(movement_vec[0].dataset_image.keys()) > 0:
            front_crops = [mv for mv in movement_vec if mv.cam_name=='front']
            back_crops = [mv for mv in movement_vec if mv.cam_name=='back']
            self.save_mv_crops_data(front_crops, 'front', 'inside_cart')
            self.save_mv_crops_data(back_crops, 'back', 'inside_cart')

    def get_random_img_idx(self, movement_vec):
        if self.params.save_product_detector_data in ('ignore', 'brute_force'):
            return []
        try:
            sample_probs = np.array([1. if el.detector_conf > self.params.product_detector_conf_th and el.source=='MD' else 0. \
                for el in movement_vec])
            sample_probs /= sample_probs.sum()
            return np.random.choice(len(movement_vec), self.params.product_detector_n_img_per_event, p=sample_probs, replace=False)
        except:
            # fail-safe
            return []

    def save_diff_snapshot_data(self, item):
        class_of_interest = self.md_module.movie_script.get_class_of_interest_according_script(item['cur_frame'])
        if class_of_interest=='UnLabelled':
            return
        if self.should_save_diff_detector(item):
            frame_str = 'frames_{}_{}'.format(item['ref_frame'], item['cur_frame'])
            sample_name = '{}_{}_{}_cls_{}'.format \
                (self.movie_name, frame_str, item['cam_name'], class_of_interest)
            save_dir = os.path.join(self.diff_detector_dir, class_of_interest)
            img_name = '{}_{}'.format('diff_detector', sample_name)
            img_rgb = cv2.cvtColor(item['img'], cv2.COLOR_BGR2RGB)
            misc.save_image_to_disk(img_rgb, img_name , path=save_dir,add_date=False)

    def save_event_detector_data(self, item):
        if item['frame'] % self.params.event_detector_keep_every_n_frame !=0:
            return
        class_of_interest = self.md_module.movie_script.get_class_of_interest_according_script(item['frame'])
        if class_of_interest=='UnLabelled':
            return
        if self.should_save_event_detector(item):
            frame_str = 'frame_{}'.format(item['frame'])
            sample_name = '{}_{}_{}_cls_{}'.format \
                (self.movie_name, frame_str, item['cam_name'], class_of_interest)
            save_dir = os.path.join(self.event_detector_dir, class_of_interest)
            img_name = '{}_{}'.format('event_detector', sample_name)
            img = item['img']
            misc.save_image_to_disk(img, img_name, path=save_dir, add_date=False)
    
    def should_save_product_detector(self, item):
        if self.data_for_training:
            if self.params.save_product_detector_data=='ignore':
                return False
            if self.params.save_product_detector_data=='brute_force':
                return True
            # Selective mode - keep only low-confidence images
            return item.detector_conf!=-1 and item.detector_conf < self.params.product_detector_conf_th
        return False

    def should_save_product_classifier(self, item):
        if self.data_for_training:
            if self.params.save_product_classifier_data=='ignore':
                return False
            tracker_box = item.source=='MD' and item.detector_conf < 0
            if tracker_box and not self.params.product_classifier_take_tracker_imgs:
                return False
            else:
                return True
        return False

    def should_save_diff_detector(self, item):
        if self.data_for_training:
            if self.params.save_diff_detector_data=='ignore':
                return False
            if self.params.save_diff_detector_data=='brute_force':
                return True
            # Selective mode - keep only low-confidence images
            # Don't keep empty diffs - diff may be visible from other cams only
            max_score = np.array([d['box'].score for d in item['diffs']]).max() if len(item['diffs'])> 0 else 1.
            return max_score < self.params.diff_detector_conf_th
        return False

    def should_save_event_detector(self, item):
        if self.data_for_training:
            if self.params.save_diff_detector_data=='ignore':
                return False
            if self.params.save_diff_detector_data=='brute_force':
                return True
            # Selective mode - keep only low-confidence images
            save_margin = item['score'] < self.params.event_detector_conf_th_high and \
                          item['score'] > self.params.event_detector_conf_th_low
            # Confident classifications
            save_conf = item['frame'] % self.params.event_detector_confident_keep_every_n_frame == 0 and \
                        item['score'] < self.params.event_detector_conf_th_high * 1.1 and \
                        item['score'] > self.params.event_detector_conf_th_low * 0.1
            return save_margin or save_conf
        return False

    def save_test_images(self):
        # save detector images if event detector;s confidence is high enough
        if self.md_module.maybe_during_event or self.md_module.in_dynamic_state:
            retDict = dict()
            retDict['front_full'] = cv2.cvtColor(self.md_module.frameL_resized, cv2.COLOR_BGR2RGB)
            retDict['front_frame_delta'] = np.copy(self.md_module.frameDelta)
            retDict['front_mask'] = np.copy(self.md_module.cart_disp_mask)
            retDict['frame_number'] = self.md_module.global_frame_num
            self.potential_test_frames['front'].append(retDict)
            retDict = dict()
            retDict['back_full'] = cv2.cvtColor(self.md_module.frameB_resized, cv2.COLOR_BGR2RGB)
            retDict['back_frame_delta'] = np.copy(self.md_module.frameDeltaBack)
            retDict['back_mask'] = np.copy(self.md_module.frameDeltaMaskBack)
            retDict['frame_number'] = self.md_module.global_frame_num
            self.potential_test_frames['back'].append(retDict)
        else:
            elements = len(self.potential_test_frames['front'])
            if elements >= self.params.max_product_detector_test_frames_per_event:
                self.event_id_counter += 1
                class_of_interest = self.md_module.movie_script.get_class_of_interest_according_script(
                    self.md_module.global_frame_num)
                elements_per_cluster = elements / self.params.max_product_detector_test_frames_per_event
                for camera in ('front', 'back'):
                    images_to_save = []
                    for i in range(self.params.max_product_detector_test_frames_per_event):
                        images_to_save.append(random.choice(self.potential_test_frames[camera][int(i*elements_per_cluster):int((i+1)*elements_per_cluster)]))
                    for images_batch in images_to_save:
                        for img_type, img in images_batch.items():
                            if img_type in ['front_full', 'front_frame_delta', 'front_mask',
                                            'back_full', 'back_frame_delta', 'back_mask']:
                                sample_name = '{}_event_id_{}_frame_{}_cam_{}_source_{}_cls_{}'.format \
                                    (self.movie_name, self.event_id_counter, images_batch['frame_number'], camera, 'ED',
                                     class_of_interest)
                                nn_type = 'product_detector'
                                save_dir = os.path.join(self.product_detector_dir, class_of_interest, img_type)
                                img_name = '{}_{}_{}'.format(nn_type, img_type, sample_name)
                                misc.save_image_to_disk(img, img_name, path=save_dir, add_date=False)
            self.potential_test_frames = dict(front=[], back=[])

    def save_front_cam_data(self, rect):
        """
        Returns front cam data for dataset
        """
        retDict = dict()
        # product classifier
        (x, y, w, h) = rect
        resize_factor = int(1/self.md_module.stereo_factor)
        # cart in/out context crop
        retDict['cart_in_out'] = self.md_module.context_image_front

        # product classifier
        retDict['front_rgb_crop'] = cv2.cvtColor(self.md_module.crop_img, cv2.COLOR_BGR2RGB)
        retDict['front_mask_crop'] = cv2.resize(self.md_module.cart_disp_mask[y: y+h, x: x+w], (0, 0), fx=resize_factor, fy=resize_factor)
        retDict['front_wnoise_crop'] = np.copy(self.md_module.crop_img_RGB)
        # product detector
        retDict['front_full'] = cv2.cvtColor(self.md_module.frameL_resized, cv2.COLOR_BGR2RGB)
        retDict['front_frame_delta'] = np.copy(self.md_module.frameDelta)
        retDict['front_mask'] = np.copy(self.md_module.cart_disp_mask)
        return retDict
    
    def save_back_cam_data(self, rect):
        retDict = dict()
        # cart in/out context crop
        retDict['cart_in_out'] = self.md_module.context_image_back if self.md_module.context_image_back is not None else \
            self.md_module.crop_img_back_RGB

        # product classifier
        (x, y, w, h) = rect
        retDict['back_rgb_crop'] = self.md_module.crop_img_back_RGB
        resize_factor = int(self.md_module.crop_img_back_RGB.shape[0] / h)
        retDict['back_mask_crop'] = cv2.resize(self.md_module.frameDeltaMaskBack[y: y+h, x: x+w], (0, 0), fx=resize_factor, fy=resize_factor)
        retDict['back_wnoise_crop'] = self.generate_masked_img(retDict['back_rgb_crop'], retDict['back_mask_crop']) # currently not used
        # product detector
        retDict['back_full'] = cv2.cvtColor(self.md_module.frameB_resized, cv2.COLOR_BGR2RGB)
        retDict['back_frame_delta'] = np.copy(self.md_module.frameDeltaBack)
        retDict['back_mask'] = np.copy(self.md_module.frameDeltaMaskBack)
        return retDict

    def generate_masked_img(self, img, mask):
        sz = img.shape
        mask_resized = cv2.resize(mask, (img.shape[1], img.shape[0]))
        wnoise_img = np.asarray(self.md_module.wnoise_img.crop((0, 0, sz[1], sz[0])))
        out = np.copy(img)
        out[mask_resized!=255] = wnoise_img[mask_resized!=255]
        if sz[0]*sz[1] > 128*128:
            out = cv2.resize(out, (128, 128))
        return out

    def save_all_detections(self, items, cam_name):
        for det_id, item in enumerate(items):
            if not isinstance(item, MVElement):
                mv_item = MVElement(item[1], cam_name)
            else:
                mv_item = item
            frame_num = mv_item.global_frame_number
            if cam_name not in self.last_saved_image_frame.keys() or \
                    frame_num - self.last_saved_image_frame[cam_name] >= 5:
                self.last_saved_image_frame[cam_name] = frame_num
                dataset_images = mv_item.dataset_image
                for img_type, image in dataset_images.items():
                    if img_type in ['front_full', 'front_frame_delta', 'front_mask',
                                    'back_full', 'back_frame_delta', 'back_mask']:
                        class_of_interest = 'All'
                        nn_type = 'product_detector'
                        save_dir = os.path.join(self.product_detector_dir, class_of_interest, img_type)
                        sample_name = '{}_event_id_{}_frame_{}_cam_{}_source_{}_cls_{}'.format \
                            (self.movie_name, '0000', mv_item.global_frame_number, cam_name, mv_item.source,
                             class_of_interest)
                        img_name = '{}_{}_{}'.format(nn_type, img_type, sample_name)
                        misc.save_image_to_disk(image, img_name, path=save_dir, add_date=False)
                        if img_type in ('front_frame_delta', 'back_frame_delta'):
                            # Save also detector v2 visualization
                            img_type_viz = img_type.replace('frame_delta', 'viz')
                            rgb_img = dataset_images[img_type.replace('frame_delta', 'full')]
                            fd_img = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
                            viz_img = np.hstack((rgb_img, fd_img))
                            img_name_viz = '{}_{}_{}'.format(nn_type, img_type_viz, sample_name)
                            save_dir_viz = os.path.join(self.product_detector_dir, class_of_interest, img_type_viz)
                            misc.save_image_to_disk(viz_img, img_name_viz , path=save_dir_viz,add_date=False)

    def save_mv_crops_data(self, items, cam_name, movie_type, save_context=True):
        if self.params.save_single_crop_data=='ignore':
            return
        for det_id, item in enumerate(items):
            if not isinstance(item, MVElement):
                mv_item = MVElement(item[1], cam_name)
            else:
                mv_item = item
            # det_id, item_content = item
            bbox = mv_item.coords
            frame = mv_item.global_frame_number
            dataset_images = mv_item.dataset_image
            if len(dataset_images.keys())==0:
                continue
            img_rgb_crop = dataset_images['cart_bottom_rgb_crop'] if  'cart_bottom_rgb_crop' in dataset_images else \
                dataset_images['front_rgb_crop'] if cam_name=='front' else dataset_images['back_rgb_crop']
            disparity = mv_item.depth
            if self.should_save_img_crop(bbox, disparity):
                p_inside_cart = self.crop_classifier_module.predict([img_rgb_crop, img_rgb_crop])[0]
                class_of_interest = 'predicted_out' if p_inside_cart < self.params.crop_classifier_conf_th_low else \
                                    'predicted_in' if p_inside_cart > self.params.crop_classifier_conf_th_high else \
                                    'predicted_margin'
                if self.params.save_single_crop_data=='selective' and class_of_interest!='predicted_margin':
                    continue
                nn_type = 'crop_classifier'
                img_type = 'front_rgb_crop' if cam_name=='front' else 'back_rgb_crop'
                save_dir = os.path.join(self.crop_classifier_dir, class_of_interest, img_type)
                sample_name = '{}_event_id_{}_frame_{}_cam_{}_source_{}_cls_{}'.format \
                    (self.movie_name, '0000', mv_item.global_frame_number, cam_name, mv_item.source,
                        class_of_interest)
                img_name = '{}_{}_{}'.format(nn_type, img_type, sample_name)
                cart_in_out_img = dataset_images['cart_in_out']
                misc.save_image_to_disk(cart_in_out_img, img_name, path=save_dir, add_date=False)

    def should_save_img_crop(self, box, disparity):
        if disparity is None:
            plane_line = self.cart_config['camera_config']['back']['decision_lines']['middle']
        elif disparity < self.cart_config['camera_config']['front']['decision_disparity']['far']:
            plane_line = self.cart_config['camera_config']['front']['decision_lines']['top']
        elif disparity < self.cart_config['camera_config']['front']['decision_disparity']['near']:
            plane_line = self.cart_config['camera_config']['front']['decision_lines']['middle']
        else:
            plane_line = self.cart_config['camera_config']['front']['decision_lines']['bottom']
        yc = box.centroid()[1]  # rectangle center
        is_below_plane = yc > plane_line
        return is_below_plane