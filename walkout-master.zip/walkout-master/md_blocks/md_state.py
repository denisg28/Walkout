import os
import pickle
import numpy as np
import streams.stereo.vx._main_stereo_matching as msm
import cv2
import base64

class MdState:
    def __init__(self, md_module, encode_img=True, save_disp_data=True,
                 save_fd_data=True, save_cb_imgs=False, save_cch_state=True):

        self.frame_num = md_module.global_frame_num
        self.encode_img = encode_img
        #state from MD
        if save_disp_data:
            self.cart_disp_th = md_module.buffer_manager.get('spatial_th').copy()
            self.cart_disp_th_integ = md_module.spatial_th_integ.copy()
        if save_fd_data:
            fd_integ_front, fd_integ_back = msm.get_fd_integ_imgs(md_module.vx_prcss)
            self.frame_delta_f = fd_integ_front.copy()
            self.frame_delta_b = fd_integ_back.copy()
        if save_cch_state:
            self.cart_content_handler_state = md_module.cart_content_handler.get_state()
        # Cart bottom state
        self.cart_bottom_state = md_module.cart_bottom_detector.get_state(save_imgs=save_cb_imgs)

    def save_state_to_disk(self,path):
        state_dict = dict()
        for k, val in vars(self).items():
            if self.encode_img and k in ('cart_disp_th', 'cart_disp_th_integ', 'frame_delta_f', 'frame_delta_b'):
                _, buffer = cv2.imencode('.jpg', val)
                img_as_txt = base64.b64encode(buffer)
                state_dict[k] = img_as_txt
            else:
                state_dict[k] = val

        fp = os.path.join(path,'state.pkl')
        with open(fp, 'wb') as f:
            pickle.dump(state_dict, f, pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load_state_from_disk(cls,path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    @staticmethod
    def load_md_state(md_module, video_capture):
        md_state = MdState.load_state_from_disk(os.path.join(video_capture[0],'state.pkl'))
        # Load & decode state frames
        if md_state['encode_img']:
            for img_name in ('cart_disp_th', 'cart_disp_th_integ', 'frame_delta_f', 'frame_delta_b'):
                jpg_original = base64.b64decode(md_state[img_name])
                jpg_as_np = np.frombuffer(jpg_original, dtype=np.uint8)
                img_cv = cv2.imdecode(jpg_as_np, flags=1)
                md_state[img_name] = img_cv[:,:,0] # TODO-handle color frames!

        md_module.global_frame_num = md_state['frame_num'] - 1 # in the loop it self it will increase to frame_num
        md_module.spatial_th_integ = md_state['cart_disp_th_integ']
        if hasattr(md_module, 'spatial_th'):
            md_module.spatial_th[:] = md_state['cart_disp_th']
        else:
            md_module.buffer_manager.get('spatial_th')[:] = md_state['cart_disp_th']
        msm.set_fd_integ_imgs(md_module.vx_prcss,md_state['frame_delta_f'], md_state['frame_delta_b'])
        md_module.gray = dict(front=np.zeros((320,240)), back = np.zeros((320,240)))
        md_module.viz_frameL_resized = 0
        # Cart bottom state
        md_module.cart_bottom_detector.set_state(md_state['cart_bottom_state'])
        if 'cart_content_handler_state' in md_state:
            md_module.cart_content_handler.set_state(md_state['cart_content_handler_state'])
            md_module.cart_content_handler.print_cart_state()


if __name__=="__main__":
    import numpy as np
    state_a = MdState("a","b","c","d")
    state_a.save_state_to_disk(".")
    state_b = MdState.load_state_from_disk('state.pkl')
    state_a_dict = state_a.__dict__
    state_b_dict = state_b.__dict__
    # state_b_dict['tomer'] = 5 # fail compare check

    #compare the 2 dicts:
    assert state_b_dict == state_a_dict