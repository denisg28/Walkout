#!/bin/bash

# start NodeJS server
pkill -f node
WALKOUT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

# mount SD card to /usr/local/sd_card
save_dir="/usr/local/sd_card"
mkdir -p ${save_dir}
if mountpoint -q -- "${save_dir}"; then
  printf '%s\n' "${save_dir} already mounted"
else
  sudo mount /dev/mmcblk2p1 ${save_dir}
  sudo chmod -R 777 ${save_dir}
fi

python3 ${WALKOUT_DIR}/utils/generate_run_config.py

pushd ${WALKOUT_DIR}/webapp/server/
yarn
yarn start &
popd

sleep 3

chromium-browser --kiosk --disable-pinch --start-fullscreen --disable-gpu http://localhost:3001
