#!/bin/bash

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

Help()
{
   # Display Help
   echo "installation app for walkout SW"
   echo
   echo "Syntax: install.sh [option]"
   echo "option:"
   echo "   '' / vx : install visionworks"
   echo "   webapp  : install webapp - server+client"
   echo "   all     : install both vx and webapp"
   echo
}

while getopts ":h" option; do
   case $option in
      h) # display Help
         Help
         exit;;
   esac
done

#parameter validation
if [ "$1" == "all" ] || [ "$1" == "vx" ] || [ "$1" == "" ] || [ "$1" == "webapp" ]; then
    printf "${GREEN}Installation Script\n${NC}"
else
    printf "${RED}bad parameters given to install.sh. check --help function \n${NC}"
    exit
fi
WALKOUT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
#webapp installation
if [ "$1" == "all" ] || [ "$1" == "webapp" ]; then
    printf "${RED}Installing webapp \n${NC}"
    printf "${RED}Installing  webapp - server side\n${NC}"
    pushd ${WALKOUT_DIR}/webapp/server/
    yarn
    printf "${RED}Installing  webapp - client side\n${NC}"

    pushd ${WALKOUT_DIR}/webapp/client/
    yarn
    yarn build

    popd
fi
#vx installation
if [ "$1" == "all" ] || [ "$1" == "vx" ] || [ "$1" == "" ]; then

    printf "${RED}Installing Vision works\n${NC}"
    pushd ${WALKOUT_DIR}/ourFirstCNN/streams/stereo/vx/
    make
    popd
    printf "${RED}Installing Swig YOLO\n${NC}"
    pushd ${WALKOUT_DIR}/ourFirstCNN/tensorrt_lib/swig/swig_yolo
    make
    popd
    printf "${RED}Installing Swig YAEEN\n${NC}"
    pushd ${WALKOUT_DIR}/ourFirstCNN/tensorrt_lib/swig/swig_yaeen
    make
    popd
    printf "${RED}Installing USB tools\n${NC}"
    pushd ${WALKOUT_DIR}/cv_blocks/usb/
    cc usb_reset.c -o usb_reset
    chmod +x usb_reset
    popd
fi

printf "${GREEN}DONE!\n${NC}"
