import boto3
import sys
import socket
import time
import argparse
import os

def is_instance_available(ec2_client, ami_id, instance_type, key_name):
    reservations = ec2_client.describe_instances()['Reservations']
    for r in reservations:
        for instance in r['Instances']:
            if instance['State']['Name']=='stopped' and \
               instance['ImageId']==ami_id and \
               instance['KeyName']==key_name and \
               instance['InstanceType']==instance_type:
                return instance["InstanceId"]
    return None


REGRESSION_MACHINE_AMI = 'ami-0913325fd8269ae6d'
EC2_REGION = 'us-east-2'
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='parser')
    parser.add_argument('--ami-id', help='ami to use',type=str, default=REGRESSION_MACHINE_AMI)
    parser.add_argument('--region', help='instance region',type=str, default=EC2_REGION)
    parser.add_argument('--key-file', help='aws .pem file',type=str, required=True)
    parser.add_argument('--gitlab-key-file', help='gitlab credentials file',type=str, default=None)
    parser.add_argument('--instance-type', help='instance type',type=str, default='p2.xlarge')
    parser.add_argument('--ec2-profile-name', help='ec2 profile name',type=str, default='ec2')
    args = parser.parse_args()

    key_name = os.path.basename(args.key_file).split('.pem')[0]
    
    # Check if an existing machine is availabe
    # ========================================
    try:
        boto3.setup_default_session(profile_name=args.ec2_profile_name)
    except:
        pass
        # print('Failed to run boto3 with profile: %s' % args.ec2_profile_name)
    ec2 = boto3.resource('ec2', region_name=args.region)
    ec2_client = boto3.client('ec2', region_name=args.region)
    available_instance_id = is_instance_available(ec2_client, args.ami_id, args.instance_type, key_name)

    if available_instance_id is not None:
        # print('Found existing instance: %s' % available_instance_id)
        instance = ec2.Instance(id=available_instance_id)

    else:
        # print('Launching a new instance:')
        # TODO - provide gitlab credentials for first time clone - currently done manually!
        # assert args.gitlab_key_file is not None and os.path.exists(args.gitlab_key_file), 'You must provide gitlab credentials'
        # Launch new instance
        # ===================
        instance = ec2.create_instances(
            ImageId = args.ami_id,
            MinCount = 1,
            MaxCount = 1,
            InstanceType = args.instance_type,
            SecurityGroups=['launch-wizard-1'], # TODO - make sure valid security group exists
            KeyName = key_name)

        instance = instance[0]

    instance.start()
    instance.wait_until_running()
    print(instance.public_ip_address, instance.id)