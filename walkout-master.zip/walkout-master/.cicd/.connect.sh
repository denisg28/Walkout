#!/bin/bash

set -f
REG_DATA_DIR="regression_data"

AWS_DNS=$(python3 .cicd/.aws.py ON "$REG_EC2_REGION" "$REG_EC2_ID")
echo "$AWS_DNS"
# Run Regression Script
ssh -o StrictHostKeyChecking=no $EC2_REG_USER@$AWS_DNS -i ~/.ssh/ssh_ec2.pem << EOF
    mkdir -p ~/$REG_DATA_DIR;
    cd walkout;
    git fetch;
    git pull $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME;
    git checkout $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME;
    git pull;
    cd ~/walkout;
    source ~/.bashrc;
    ./install.sh;
    cd ourFirstCNN/;
    echo '$REG_MOVIE_LIST' > recording_list/regression_movies.csv;
    source ~/py3_env/bin/activate;
    export PYTHONPATH=/home/$EC2_REG_USER/walkout;
    python WalkoutExecutor.py --movies-file recording_list/regression_movies.csv  --root-dir ~/$REG_DATA_DIR;
EOF