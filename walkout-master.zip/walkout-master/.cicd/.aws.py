import boto3
import sys
import socket
import time

retries = 5
retry_delay = 3
retry_count = 0

try:
    boto3.setup_default_session(profile_name='ec2')
except:
    pass
ec2 = boto3.client('ec2', region_name=sys.argv[2])
instance_id = sys.argv[3]
ec2client = boto3.resource('ec2', region_name= sys.argv[2])
instance = ec2client.Instance(id=instance_id)
action = sys.argv[1]

if action == 'ON':
    instance.start()
    instance.wait_until_running()
    while retry_count <= retries:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex((instance.public_ip_address, 22))
        if result == 0:
            print(instance.public_dns_name)
            break
        else:
            time.sleep(retry_delay)

else:
    instance.stop()
    print("instance(s) stoped!")
