
class BasePlaceRecognizer(object):
    def __init__(self, )