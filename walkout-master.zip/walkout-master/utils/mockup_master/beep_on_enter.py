from pynput.keyboard import Key, Listener

try:
    from cart_blocks.indications.sound_maker import SoundMaker
except:
    print('no sound effects driver is initialized')

sound_maker = SoundMaker()

sound_file = 'materials/barcode_beep3.mp3'
#'/home/walkout01/git_repo/walkout/cart_blocks/indications/sound_files/insert_beep2.mp3'

def show(key):
  
    #print('You Entered {0}'.format( key))
  
    if key == Key.enter:
        # Stop listener
        # return False
        print('You Entered {0}'.format( key))
        sound_maker.make_sound_from_file(sound_file)
        print("scan again")
  
print("pending your input ! ")
# Collect all event until released
with Listener(on_press = show) as listener:   
    listener.join()

