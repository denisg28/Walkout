# How to run
python mockup_master.py < config yaml >  < override delay >
 - config yaml: a file to describe slideshow rules and flow as described below
 - override delay: delay in second, sets time to auto jump feature as described below
# yaml structure
 - screen_0:
    -   < screen_0 content here - must have screen_0 - main/default screen>
 - screen_name_1:
    -  < screen_name_1 content here > 
 - screen_name_2:
    -  < screen_name_2 content here >
 - general:
    -  < general configurations here >
 
# screen contents
 - image_path - relative path or full path to jpg/png/gif image
 - repeat_gif - default= False - if True will repeat gif animations
 - buttons- to be added in an indented format as following
    - <button_name>:
       - coordinates : [x,y,w,h] - coordinates of button, 
                 use [0, 0, 0, 0] for button without press area
       - jump_to_screen : <screen_name_X> - one of the screens defined in yaml. if this parameter is missing screen will not be changed
       - key_press: <key> - single char bind key to trigger button. i.e "a"
       - make_sound : <sound path> - relative/full path to sound file - i.e .mp3 file
       - make_led : <color> : green/blue/red/off
 - auto_jump_screen: <screen_id>, if this parameter exists slide show will move to next screen after auto_jump_delay
 - auto_jump_delay: time in seconds

# general configurations contents
 -  enable_sound: True/False - enable cart sound using sound_maker class
 -  enable_led: True/False - enable cart LEDs using quasarled class

# Yaml sample
- screen_0:
     - image_path: materials/main_screen.png
     - buttons:
        - button_name1:
            - coordinates : [1200, 500 ,200,100]
            - jump_to_screen : screen_2
            - make_sound : materials/barcode_beep2.mp3
            - make_led : green
            - key_press: a
        - button_name2:
            - coordinates : [0, 0, 0, 0]
            - jump_to_screen : screen_3
            - make_led : red
            - key_press: b
- screen_2:
     - image_path: materials/screen2.png
     - buttons:
        - back:
            - coordinates : [400, 500,200,100]
            - jump_to_screen : screen_0
            - key_press: c
- screen_3:
     - image_path: materials/animation.gif
     - repeat_gif: True
     - buttons:
        - back:
            - coordinates: [0,0,0,0]
            - jump_to_screen: screen_0
            - key_press: b
- general:
     -  enable_sound: True
     -  enable_led: True

