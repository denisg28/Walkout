from PIL import Image
import numpy as np
import cv2
import os, sys
import time
import yaml

try:
    from cart_blocks.indications.quasar_leds import QuasarLeds, COLORS
except:
    print('no LED driver is initialized')

try:
    from cart_blocks.indications.sound_maker import SoundMaker
except:
    print('no sound effects driver is initialized')

sys.path.append(os.path.join(os.path.dirname(__file__)))

class Button(object):
    def __init__(self,coordinates,link_to_screen,sound=None,set_led=None,key=None):
        #coordinates: x,y,w,h
        self.x1 = coordinates[0]
        self.y1 = coordinates[1]
        self.x2 = coordinates[0] + coordinates[2]
        self.y2 = coordinates[1] + coordinates[3]
        self.link = link_to_screen
        if sound is not None :
            self.sound = sound
        if set_led is not None:
            self.set_led = set_led
        if key is not None:
            self.key = key

    def has_led_action(self):
        if hasattr(self,"set_led"):
            return True
        return False

    def get_led_color(self):
        return self.set_led

    def has_sound(self):
        if hasattr(self,"sound"):
            return True
        return False

    def get_sound(self):
        if hasattr(self,"sound"):
            return self.sound
        return None

    def get_key(self):
        if hasattr(self,"key"):
            return self.key
        else:
            return ""

    def is_clicked(self,click_pos):
        x, y = click_pos
        return self.x1 <= x and x <= self.x2 and self.y1 <= y and y <= self.y2

    def get_linked_screen(self):
        return self.link

class Screen(object):
    def __init__(self,id, img_file, buttons,repeat=True,auto_jump=(None,None)):
        print("starting {}".format(img_file))
        assert( os.path.exists(img_file))
        self.id = id
        if img_file[-3:]=="gif":
            self.img = self.load_gif_image(img_file)
        else:
            self.img = [cv2.imread(img_file)]
        self.buttons = self.define_buttons(buttons,self.id)
        self.idx=0
        self.repeat = repeat

        screen,delay = auto_jump
        if screen is not None and delay is not None:
            self.auto_jump_screen = screen
            self.delay = delay
            self.auto_jump_time = time.time() + self.delay



    def get_auto_jump_screen(self):
        if hasattr(self,"auto_jump_screen") and  hasattr(self,"auto_jump_time"):
            return self.auto_jump_screen
        return None

    def is_auto_jump_timer_up(self):
        return time.time() > self.auto_jump_time

    def get_image(self):
        self.idx += 1
        if self.idx >= len(self.img):
            if self.repeat:
                self.idx = 0
            else:
                self.idx -=1
        return self.img[self.idx]

    def define_buttons(self,buttons,parent_screen):
        buttons_list = []
        sound = set_led = key = None
        for button in buttons:
            try:
                coordinates = buttons[button]["coordinates"]
            except KeyError:
                raise KeyError('button name: {} in {} has no key : "coordinates"'.format(button,parent_screen))
            try:
                link_to_screen = buttons[button]["jump_to_screen"]
            except KeyError:
                print('warning button name: {} in {} has no key : "jump_to_screen" - no screen change on button press'.format(button,parent_screen))

                link_to_screen = parent_screen
            if "make_sound" in buttons[button].keys():
                sound = buttons[button]["make_sound"]
            if "make_led" in buttons[button].keys():
                set_led = buttons[button]["make_led"]
            if "key_press" in buttons[button].keys():
                key = buttons[button]["key_press"]
            btn = Button(coordinates,link_to_screen,sound,set_led,key)
            buttons_list.append(btn)

        return buttons_list

    def load_gif_image(self,img_file):
        out = []
        if not os.path.isfile(img_file):
            # this is gif in dir of PNGs
            path = img_file
            prefix_name = img_file.split('/')[-1].split('_gif')[0]
            idx = 0
            file = os.path.join(path, prefix_name + "-{}.png".format(idx))
            while os.path.isfile(file):
                file = os.path.join(path, prefix_name + "-{}.png".format(idx))
                img = cv2.imread(file)
                out.append(img)
                idx += 1
                #print(idx)
            return out
        else:
            im = Image.open(img_file)
            try:
                while 1:
                    open_cv_image = np.array(im.convert('RGB'))
                    open_cv_image[:, :, ::-1].copy()
                    # Convert RGB to BGR
                    open_cv_image = cv2.cvtColor(open_cv_image, cv2.COLOR_RGB2BGR)
                    out.append(open_cv_image)
                    im.seek(im.tell() + 1)
            except EOFError:
                pass  # end of sequence
                return out

    def init_jump_timer(self):
        if self.get_auto_jump_screen() is not None:
            self.auto_jump_time = time.time() + self.delay


class SlideShow(object):

    def __init__(self,path_to_yml,override_delay=None):
        config = yaml.load(open(path_to_yml))
        self.screens = {}
        for screen in config.keys():
            if screen != "general":
                img = config[screen]["image_path"]
                repeat_gif = False
                if "repeat_gif" in config[screen].keys():
                    repeat_gif = config[screen]["repeat_gif"]
                if "buttons" in config[screen].keys():
                    buttons = config[screen]["buttons"]

                linked_screen = delay = None
                if "auto_jump_screen" in config[screen].keys() or "auto_jump_delay" in config[screen].keys():
                    if "auto_jump_screen" in config[screen].keys():
                        linked_screen = config[screen]["auto_jump_screen"]
                    if "auto_jump_delay" in config[screen].keys():
                        delay = config[screen]["auto_jump_delay"]
                        if override_delay is not None:
                            delay = override_delay

                auto_jump = (linked_screen,delay)

                self.screens[screen] = Screen(screen, img, buttons,repeat_gif,auto_jump)

        enable_sound=enable_led = True
        try:
            enable_sound = config["general"]["enable_sound"]
        except KeyError:
            pass
        try:
            enable_led = config["general"]["enable_led"]
        except KeyError:
            pass

        if enable_sound:
            self.sound_maker = SoundMaker()
        else:
            print("sound is not initialized, check config yaml and driver")
        if 'cart_blocks.indications.quasar_leds' in sys.modules and enable_led:
            self.leds = QuasarLeds()
        else:
            print("LEDs are not initialized")

        try:
            self.activate_screen("screen_0")
        except KeyError:
            raise KeyError("screen_0 should exist in screens")


    def event_on_click(self,event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN:
            print('click on ({},{})'.format(x,y))
            #check if button pressed:
            btn = self.get_button_pressed((x,y))
            if btn is not None:
                self.do_btn_actions(btn)

    def get_button_pressed(self,click_pos):
        for button in self.active_screen.buttons:
            if button.is_clicked(click_pos):
                return button
        return None

    def run_slide_show(self):

        # cv2.namedWindow("window", cv2.WND_PROP_FULLSCREEN)
        cv2.namedWindow("window")
        cv2.setWindowProperty("window", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        cv2.setMouseCallback('window', self.event_on_click)

        while True:
            img_cp = np.copy(self.active_screen.get_image())
            if len(img_cp.shape)!=0: #solve race - sometimes image is not good due to glitch from button
                cv2.imshow("window", img_cp)
                key = cv2.waitKey(100)
            else:
                print("image is None due to glitch")
            self.handle_key_press(key)
            self.handle_screen_auto_jump()

            if key == 27 or key== ord("q"):
                break

    def do_btn_actions(self, btn):
        #print("btn {} was pressed".format(btn))
        self.activate_screen(btn.get_linked_screen())


        # play sound
        if btn.has_sound() and hasattr(self,"sound_maker"):
            self.sound_maker.make_sound_from_file(btn.get_sound())

        # use LED lights
        if btn.has_led_action() and hasattr(self,"leds"):
            if btn.get_led_color() == "red":
                color = COLORS.RED
            elif btn.get_led_color() == "green":
                color = COLORS.GREEN
            elif btn.get_led_color() == "blue":
                color = COLORS.BLUE
            else:
                color = 0
            self.leds.set_led_on(color)
        pass

    def btn_pressed_by_key(self, key):
        #            ord('q')
        for button in self.active_screen.buttons:
            if key == ord(button.get_key()):
                print("pressed {} key ".format(button.get_key()))
                return button
        return None

    def handle_key_press(self, key):
        #print("key {} was pressed".format(key))
        btn = self.btn_pressed_by_key(key)
        if btn is not None:
            self.do_btn_actions(btn)

    def handle_screen_auto_jump(self):
        jump_screen = self.active_screen.get_auto_jump_screen()
        if jump_screen is not None and self.active_screen.is_auto_jump_timer_up():
            self.activate_screen(jump_screen)


    def activate_screen(self, screen_to_jump):
        self.active_screen = self.screens[screen_to_jump]
        self.active_screen.init_jump_timer()
        print("moved to screen {}".format(self.active_screen.id))


if __name__=="__main__":

    if len(sys.argv)>=2:
        config_path = sys.argv[1]
        if not os.path.exists(config_path):
            raise ValueError("configuration yaml should be given as an argument for this SW")
    else:
        raise ValueError("configuration yaml should be given as an argument for this SW")

    override_delay = None
    if len(sys.argv) >= 3:
        override_delay = float(sys.argv[2])
        print("overriding all delays with {}".format(override_delay))
    s = SlideShow(config_path,override_delay)
    s.run_slide_show()