import cv2
from PIL import Image
import numpy as np
import os

def load_gif_image(img_file):
    out = []
    if not os.path.isfile(img_file):
        # this is gif in dir of PNGs
        path = img_file
        prefix_name = img_file.split('/')[-1].split('_gif')[0]
        idx = 0
        file = os.path.join(path, prefix_name + "-{}.png".format(idx))
        while os.path.isfile(file):
            file = os.path.join(path, prefix_name + "-{}.png".format(idx))
            img = cv2.imread(file)
            out.append(img)
            idx += 1
            print(idx)
        return out
    else:
        im = Image.open(img_file)
        try:
            while 1:

                open_cv_image = np.array(im.convert('RGB'))
                open_cv_image[:, :, ::-1].copy()
                # Convert RGB to BGR
                open_cv_image = cv2.cvtColor(open_cv_image, cv2.COLOR_RGB2BGR)
                out.append(open_cv_image)
                im.seek(im.tell() + 1)
        except EOFError:
            pass  # end of sequence
            return out

img_file = '/home/walkout01/git_repo/walkout/utils/mockup_master/materials/exp1/exp1_2.gif'
img_file = '/home/walkout01/git_repo/walkout/utils/mockup_master/materials/exp1/exp1_2_gif'
img = load_gif_image(img_file)
idx = 0
while True:
    cv2.imshow('window',img[idx])
    cv2.waitKey(100)
    idx+=1