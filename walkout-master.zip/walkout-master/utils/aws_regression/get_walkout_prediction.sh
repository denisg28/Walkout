AWS_USR=$2
BRANCH_NAME=$3
REG_MOVIE_LIST=$4
REG_DATA_DIR="regression_data"
REG_EC2_REGION='us-east-2'
CURR_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
pushd ${CURR_DIR}
AWS_DNS=$(python3 ../../.cicd/.aws.py ON "$REG_EC2_REGION" "$1")
popd

echo "$AWS_DNS"
# Copy regression file to aws machine
scp -o StrictHostKeyChecking=no -i ~/.ssh/ssh_ec2.pem $REG_MOVIE_LIST $AWS_USR@$AWS_DNS:/home/$AWS_USR/walkout/ourFirstCNN/recording_list/ext_movies.csv
# # Run Regression Script
ssh -o StrictHostKeyChecking=no $AWS_USR@$AWS_DNS -i ~/.ssh/ssh_ec2.pem << EOF
    mkdir -p ~/$REG_DATA_DIR;
    cd walkout;
    git stash;
    git fetch;
    git checkout $BRANCH_NAME;
    git pull;
    cd ~/walkout;
    source ~/.bashrc;
    ./install.sh;
    cd ourFirstCNN/;
    source ~/py3_env/bin/activate;
    export PYTHONPATH=/home/$AWS_USR/walkout;
    python WalkoutExecutor.py --movies-file recording_list/ext_movies.csv  --root-dir ~/$REG_DATA_DIR --save-prediction;
EOF

# Copy back predicted purchase lists
rsync -Prav -e "ssh -i ~/.ssh/ssh_ec2.pem" --ignore-existing $AWS_USR@$AWS_DNS:/home/$AWS_USR/$REG_DATA_DIR . --include="*.walkout.csv" --exclude="*/*" 

pushd ${CURR_DIR}
AWS_DNS=$(python3 ../../.cicd/.aws.py OFF "$REG_EC2_REGION" "$1")
popd