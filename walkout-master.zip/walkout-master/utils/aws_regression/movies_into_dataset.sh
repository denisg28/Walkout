#!/bin/bash

RED='\033[0;31m'
NC='\033[0m' # No Color

if [ "$#" != 3 ] && [ "$#" != 4 ] && [ "$#" != 5 ]; then
    printf "${RED}Missing arguments, Usage:<KEY_FILE>  <BRANCH_NAME> <PATH_TO_MOVIE_LIST> <PARAMS_FILE>(optional) <RETAILER>(optional)\n${NC}"
    exit 1
fi

AWS_USR="ubuntu"
BRANCH_NAME=$2
REG_MOVIE_LIST=$3
if [ ! -f $REG_MOVIE_LIST ]; then
   echo "Path to movies list does not exist! aborting script."
   exit 1
fi
REG_DATA_DIR="regression_data"
REG_EC2_REGION='us-east-2'
KEY_FILE=$1
CURR_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

if [ "$#" == 3 ]; then
   PARAMS_FILE="None" 
   RETAILER="demo_latest"
elif [ "$#" == 4 ]; then
   PARAMS_FILE=$4
   RETAILER="demo_latest"
else
   PARAMS_FILE=$4
   RETAILER=$5
   if [ ${RETAILER} != "demo_latest" ] && [ ${RETAILER} != "Tiv-Taam" ] && [ ${RETAILER} != "asda_poc" ] && [ ${RETAILER} != "ALDI_STORE" ]&& [ ${RETAILER} != "jumbo" ] && [ ${RETAILER} != "bunting" ]; then
      echo "Invalid retailer name, abortig script"
      exit 1
   fi
fi

pushd ${CURR_DIR}
IFS=" " read AWS_DNS INTANCE_ID <<< $(python3 ../../.cicd/start_ec2_from_ami.py --key-file $KEY_FILE)
#AWS_DNS=$(python3 ../../.cicd/.aws.py ON "$REG_EC2_REGION" "$1")
popd

JOB_TIMESTAMP=`date '+%Y-%m-%d_%H_%M_%S'`
DATASET_DIR="/home/$AWS_USR/walkout/dataset_${JOB_TIMESTAMP}"
S3_DIR="visual_db_storage/dataset_job_${RETAILER}_${JOB_TIMESTAMP}"
echo "$AWS_DNS"
echo "$INTANCE_ID"

# Wait to make sure machine finished initializing
sleep 30

# Copy regression file to aws machine
scp -o StrictHostKeyChecking=no -i $KEY_FILE $REG_MOVIE_LIST $AWS_USR@$AWS_DNS:/home/$AWS_USR/walkout/ourFirstCNN/recording_list/ext_movies.csv
# Copy aws credentials to aws machine
scp -o StrictHostKeyChecking=no -i $KEY_FILE ~/.aws/credentials $AWS_USR@$AWS_DNS:/home/$AWS_USR/.aws/credentials
# Copy params file
if [ "$#" != 3 ]; then
    REMOTE_PARAM_FILE=/home/$AWS_USR/walkout/ext_params.yaml
    scp -o StrictHostKeyChecking=no -i $KEY_FILE $PARAMS_FILE $AWS_USR@$AWS_DNS:$REMOTE_PARAM_FILE
else
   REMOTE_PARAM_FILE="None"
fi
# Run Regression Script
ssh -o StrictHostKeyChecking=no $AWS_USR@$AWS_DNS -i $KEY_FILE << EOF
    rm -rf ~/$REG_DATA_DIR;
    mkdir -p ~/$REG_DATA_DIR;
    mkdir -p $DATASET_DIR;
    cd walkout;
    git stash;
    git fetch;
    git checkout $BRANCH_NAME;
    git pull;
    cd ~/walkout;
    aws s3 cp s3://walkout-main/RND/DB/${RETAILER}/database.sqlite3 webapp/server/database.sqlite3
    source ~/.bashrc;
    ./install.sh;
    cd ourFirstCNN/;
    source ~/py3_env/bin/activate;
    export PYTHONPATH=/home/$AWS_USR/walkout;
    python WalkoutExecutor.py --movies-file recording_list/ext_movies.csv  --root-dir ~/$REG_DATA_DIR --save-dataset --dataset-dir $DATASET_DIR --params $REMOTE_PARAM_FILE --det-during-event --delete-movies;
    cd ../utils/dataset_utils/;
    python dataset_statistics.py --dataset-path $DATASET_DIR --retailer $RETAILER --movies-file /home/$AWS_USR/walkout/ourFirstCNN/recording_list/ext_movies.csv;
EOF

# Upload to S3
ssh -o StrictHostKeyChecking=no $AWS_USR@$AWS_DNS -i $KEY_FILE << EOF
    aws s3 sync $DATASET_DIR/ s3://walkout-main/${S3_DIR}/ 
EOF

pushd ${CURR_DIR}
AWS_DNS=$(python3 ../../.cicd/.aws.py OFF "$REG_EC2_REGION" "$INTANCE_ID")
popd