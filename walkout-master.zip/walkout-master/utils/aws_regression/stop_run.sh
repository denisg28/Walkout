#!/bin/bash

RED='\033[0;31m'
NC='\033[0m' # No Color

if [ "$#" -ne 1 ]; then
    printf "${RED}Missing arguments, Usage: <REG_EC2_ID>\n${NC}"
    exit 1
fi

REG_EC2_REGION='us-east-2'
AWS_DNS=$(python3 .cicd/.aws.py OFF "$REG_EC2_REGION" "$1")
