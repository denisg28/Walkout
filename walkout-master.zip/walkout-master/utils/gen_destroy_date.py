from yaml import dump
from datetime import timedelta, datetime
# destroy date for 13 weeks from creation
destroy_date = str(datetime.now() + timedelta(weeks=13)).split(' ')[0]
data = dict(date = destroy_date)

with open('des.yaml', 'w') as outfile:
    dump(data, outfile, default_flow_style=False)