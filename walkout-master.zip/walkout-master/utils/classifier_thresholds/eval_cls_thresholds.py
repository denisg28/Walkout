import argparse
import pickle
import json
import pandas as pd

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='product classifier benchmark')
    parser.add_argument('--conf-mat-file', help='path to classifier confusion matrix file',type=str, required=True)
    parser.add_argument('--results-file', help='path to classifier results file',type=str, required=True)
    parser.add_argument('--accuracy-th', help='handle classes below this accuracy',type=float, default=0.93)
    parser.add_argument('--confision-th', help='minimum confusion rate to consider for single class',type=float, default=0.03)
    args = parser.parse_args()

    # Extract evaluated classes from confusion matrix
    # ===============================================
    eval_classes = []
    all_confused_classes = []
    conf_data = json.load(open(args.conf_mat_file, 'r'))
    for cls_name, cls_acc in conf_data.items():
        if cls_name in cls_acc and cls_acc[cls_name] > args.accuracy_th:
            continue
        all_confused_classes.append(cls_name)
        confusion_cls = []
        for other_cls_name, conf_prob in cls_acc.items():
            if other_cls_name==cls_name or conf_prob < args.confision_th:
                continue
            confusion_cls.append(other_cls_name)
            all_confused_classes.append(other_cls_name)
        eval_classes.append(dict(name=cls_name, confiusion_cls=confusion_cls))
    
    all_confused_classes = list(set(all_confused_classes))
    

    print('Found %d confusing products:' % (len(eval_classes)), eval_classes)

    # Open results file
    # =================
    all_results = pickle.load(open(args.results_file, 'rb'))

    # Collect All confused class events
    # =================================
    conf_cls_events = {cn:[] for cn in all_confused_classes}
    for rec_results in all_results:
        for event_result in rec_results:
            if event_result['name'] in all_confused_classes:
                is_correct = event_result['pred_probs'][0][0]==event_result['name']
                gt_score = [score for (name, score) in event_result['pred_probs'] if name==event_result['name']]
                assert len(gt_score)<=1
                gt_score = gt_score[0] if len(gt_score)==1 else 1e-6
                other_class = event_result['pred_probs'][1][0] if is_correct else event_result['pred_probs'][0][0]
                other_score = event_result['pred_probs'][1][1] if is_correct else event_result['pred_probs'][0][1]
                single_reg = dict(is_correct=is_correct, gt_score=gt_score, other_score=other_score, other_class=other_class)
                conf_cls_events[event_result['name']].append(single_reg)
                

    for class_name, class_events in conf_cls_events.items():
        cls_data = pd.DataFrame(class_events)
        cls_data['score_ratio'] = cls_data['gt_score'] / cls_data['other_score']
        cls_data['top12_ratio'] = cls_data['score_ratio']
        cls_data['top12_ratio'][~cls_data['is_correct']] = 1./cls_data['score_ratio']
        print('Class %s info:\n' % class_name)
        print('==============================')
        print(cls_data)

