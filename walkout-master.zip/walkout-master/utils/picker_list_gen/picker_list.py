import json
import external_io.CloudApi as CloudApi

def upload_single_picker_list(item_list,purpose,destination, user, password, toUpload,target_date = None, id=None,verbose=True):
    """
    item_list: list of items or list of tuples (item,direction)
    """
    if id==None:
        id='' # gen ID ?

    if purpose!='ob-single' and purpose!='ob-pile' and purpose!='test' :
        raise NameError('purpose should follow API')

    picker_list = {}

    picker_list['id'] = id
    picker_list['purpose'] = purpose
    picker_list['destination'] = destination
    if target_date is not None:
        picker_list['target_date'] = target_date
    else:
        picker_list['target_date'] = CloudApi.generate_target_date(0)



    event_list = []
    for idx,item in enumerate(item_list):

        if len(item) == 2:
            direction = item[1]
            item = item[0]
        else:
            direction = 1

        event = {}
        event["event"] = idx
        event["barcode"] = item
        event["direction"] = direction
        event_list.append(event)

    picker_list['list_of_events'] = event_list
    if verbose:
        print(json.dumps(picker_list, indent=4, sort_keys=True)) #pretty json print

    if toUpload:
        api = CloudApi.CloudApi(user, password)
        api.create_predefined_list([picker_list])


if __name__=='__main__':
    # l = ['7290016437621', '80050025',  '7290008464505',  '7891024030974',  '7290102398072']
    # l = ['7290016437621', '80050025' ]
    l = [('7290016437621',1), ('80050025',1) ,('7290016437621',-1)]
    purpose = 'test' #'ob-single' # 'ob-pile'
    destination = 'walkout' # branch name
    upload_single_picker_list(l, purpose,destination,toUpload=True, id=1111,verbose=True)