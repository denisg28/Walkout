#!/bin/bash

source $HOME/py3_env/bin/activate

BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color
VERSION=$(git rev-parse --short HEAD)
today=$(date +'%Y_%m_%d') 

printf "${BLUE}################ Build BringUp artifact ##################\n${NC}"
mkdir -p $HOME/bringup_
git checkout master
git stash
git pull
cp -r bringup_webapp $HOME/bringup_/webapp
cp -r jetson_startup $HOME/bringup_/jetson_startup
pushd $HOME/bringup_
pushd webapp
pushd server
rm -rf node_modules
popd
pushd client
yarn
yarn build
rm -rf node_modules
rm -rf src
rm *.json
rm yarn*
popd
printf "${BLUE}################## Create Artifact Zip ########################\n${NC}"
popd
zip -r Walkout_artifact_bringup_$VERSION.zip *  > /tmp/zip.log
rm /tmp/zip.log
printf "${BLUE}################## Upload Artifact to AWS ########################\n${NC}"
aws s3 cp Walkout_artifact_bringup_$VERSION.zip s3://walkout-main/RND/artifacts/$today/Walkout_artifact_bringup_$VERSION.zip

printf "${BLUE}################## remove directories ########################\n${NC}"
popd
rm -rf $HOME/bringup_
printf "${GREEN}####################### DONE!!! ##############################\n${NC}"