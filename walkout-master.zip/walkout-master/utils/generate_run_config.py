import argparse
import os
import yaml
import json

if __name__ == '__main__':
    """
    This command should be ran before run_motion_detect.py with the same inputs arguments.
    by default, you will get "user_files/config_out.json" file with the final external configuration to run the app.
    This can be used by the application to get the configuration BEFORE running motion detect
    """
    DEFAULT_CONF_FILE = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'user_files',
                                     'config_params.yaml')
    DEFAULT_BARANCH_FILE = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'user_files',
                                     'config_branch.yaml')
    DEFAULT_CART_FILE = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..','..', 'config_files',
                                     'config_cart.yaml')
    DEFAULT_OUT_FILE = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'user_files',
                                     'config_out.yaml')

    parser = argparse.ArgumentParser(description='object detector benchmark')
    parser.add_argument('--config', '-c', help='Path to config override of default config',
                        type=str, default=DEFAULT_CONF_FILE)
    parser.add_argument('--config-branch', help='Path to branch config override',
                        type=str, default=DEFAULT_BARANCH_FILE)
    parser.add_argument('--config-cart', help='Path to cart config override',
                        type=str, default=DEFAULT_CART_FILE)
    parser.add_argument('--output', help='Path to output config file',
                        type=str, default=DEFAULT_OUT_FILE)

    args = parser.parse_args()
    assert os.path.exists(args.config)

    # override order - general config->branch(supermarket) config->cart config
    default_params = yaml.safe_load(open(args.config, 'r'))
    if os.path.exists(args.config_branch):
        branch_params = yaml.safe_load(open(args.config_branch, 'r'))
        for k, v in branch_params.items():
            default_params[k] = v
    if os.path.exists(args.config_cart):
        cart_params = yaml.safe_load(open(args.config_cart, 'r'))
        for k, v in cart_params.items():
            default_params[k] = v
    
    # Write output
    if args.output.endswith('.json'):
        with open(args.output, 'w') as fp:
            json.dump(default_params, fp)
    elif args.output.endswith('.yaml'):
        with open(args.output, 'w') as fp:
            yaml.dump(default_params, fp)