import os
import argparse
from cv_blocks.misc.aws_download import download_cart_data

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Get Data stored on AWS for a specific date')
    parser.add_argument('--date', help='Date of data to download', type=str, required=True)
    parser.add_argument('--dst-dir', help='Path to destination directory', type=str, required=True)

    args = parser.parse_args()

    os.makedirs(args.dst_dir, exist_ok=True)
    download_cart_data(os.path.join('cart_data', args.date), args.dst_dir)