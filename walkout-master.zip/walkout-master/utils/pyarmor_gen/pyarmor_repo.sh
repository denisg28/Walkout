#!/bin/bash

BASE_DIR=$1
SRC_DIR=$2
DST_DIR=$3

pushd ${BASE_DIR}
cp -r ${SRC_DIR} ${DST_DIR}

pyarmor init --src ${DST_DIR} ${DST_DIR}
pushd ${DST_DIR}
pyarmor config --entry "ourFirstCNN/MotionDetect.py, ourFirstCNN/run_motion_detect.py, utils/generate_run_config.py, cv_blocks/usb/usb_reset.py, utils/scripts/walkoutAZ.py"
pyarmor build
pyarmor build --no-runtime
popd