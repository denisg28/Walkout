import os
import argparse
import subprocess as sp
import shutil

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='generate slimmer repo')
    parser.add_argument('--base-dir', help='Path of source repo', type=str, required=True)
    parser.add_argument('--src-dir', help='Path of source repo', type=str, required=True)
    parser.add_argument('--dst-dir', help='Path to destination', type=str, default=None)
    args = parser.parse_args()

    if args.dst_dir is None:
        args.dst_dir = args.src_dir + '_pyarmor'

    src_repo = os.path.join(args.base_dir, args.dst_dir, 'dist')
    dst_repo = os.path.join(args.base_dir, args.dst_dir)

    # Duplicate original repo & run pyarmor
    # =====================================
    cmd = ['./pyarmor_repo.sh', args.base_dir, args.src_dir, args.dst_dir]
    print(' '.join(cmd))
    p = sp.Popen(cmd)
    p.wait()


    # Override python files with obfuscated files
    # ===========================================
    for root,dir,files in os.walk(src_repo):
        for file in files:
            src_path = os.path.join(root, file)
            dst_root = root.replace(src_repo, dst_repo)
            if not os.path.exists(dst_root):
                os.makedirs(dst_root)
            dst_path = os.path.join(dst_root, file)
            shutil.move(src_path, dst_path)

    # Remove dist dir
    shutil.rmtree(src_repo, ignore_errors=True)
