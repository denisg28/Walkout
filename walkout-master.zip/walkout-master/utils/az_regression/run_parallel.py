import argparse
import pandas as pd
import os
import subprocess as sp
from datetime import datetime
import time
import numpy as np



if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Python runner for parallel regression')
    parser.add_argument('--branch', help='which branch to use',type=str, default='master')
    parser.add_argument('--exp-dir', help='output exp dir',type=str, required=True)
    parser.add_argument('--movies-list', help='list of movies to run',type=str, required=True)
    parser.add_argument('--key-file', help='aws .pem file',type=str, required=True)
    parser.add_argument('--param-file', help='external parameter file',type=str, required=True)
    parser.add_argument('--retailer', help='which retailer to use',type=str, default='demo_latest')
    parser.add_argument('--num-workers', help='how many instances to use',type=int, default=1)
    args = parser.parse_args()

    # Split list to sublists
    assert os.path.exists(args.movies_list)
    assert os.path.exists(args.param_file)
    assert args.num_workers <=5 # Current Azure quata limitation
    all_movies = pd.read_csv(args.movies_list, comment='#', names=['movie'], index_col=False, skip_blank_lines=True)['movie'].tolist()
    sublist_size = (len(all_movies) // args.num_workers) + 1
    movies_sublists = []
    for n in range(args.num_workers):
        subset = all_movies[n*sublist_size:(n+1)*sublist_size]
        movies_sublists.append(subset)
    # Join last list the remainer
    if len(all_movies) > sublist_size * args.num_workers:
        movies_sublists[-1] += all_movies[sublist_size * args.num_workers :]
    assert len(all_movies)==np.array([len(l) for l in movies_sublists]).sum()

    # Create task directory
    timestamp = datetime.now().strftime("%Y-%m-%d_%H_%M_%S")
    exp_subdir = 'exp_%s' % timestamp
    exp_dir = os.path.join(args.exp_dir, exp_subdir)
    os.makedirs(exp_dir)

    list_paths = []
    for list_idx, single_list in enumerate(movies_sublists):
        list_path = os.path.join(exp_dir, 'movies_chunk_%d.csv' % list_idx)
        pd.DataFrame(single_list).to_csv(list_path, header=False, index=False)
        list_paths.append(list_path)

    all_proc = []
    # Run all sub-tasks
    for list_idx, single_list_path in enumerate(list_paths):
        cmd = ['screen', '-m', './run.sh', args.key_file, args.branch, single_list_path, exp_dir, args.param_file, args.retailer]
        print(' '.join(cmd))
        p = sp.Popen(cmd)
        all_proc.append(p)
        time.sleep(10) # Wait 10 seconds to allow machines to change state
    
    for p in all_proc:
        p.wait()

