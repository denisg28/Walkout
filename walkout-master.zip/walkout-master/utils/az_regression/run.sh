#!/bin/bash

set -euo pipefail
#set -x

RED='\033[0;31m'
NC='\033[0m' # No Color
OS_USR="ubuntu"
AZ_RESOURCE_GROUP='algo_rescource'
AZ_LATEST_ALGO_IMAGE_ID='/subscriptions/e839cecb-0619-4c76-9204-acf4da54102e/resourceGroups/'${AZ_RESOURCE_GROUP}'/providers/Microsoft.Compute/images/Regression-image-20210127165410'
AZ_LATEST_ALGO_IMAGE_NAME='Regression-image-20210127165410'
AZ_VM_SIZE='Standard_NC6_Promo'
AZ_ZONE='westeurope'
SSH_KEY_PUBLIC_FILE='/tmp/azure_algo_key.pub'

if [ "$#" -lt 4 ] || [ 6 -lt "$#" ]; then
    printf "${RED}Missing arguments, Usage:run.sh <KEY_FILE> <BRANCH_NAME> <PATH_TO_MOVIE_LIST> <OUTPUT_DIR> <PARAMS_FILE>(optional) <RETAILER>(optional)\n${NC}"
    exit 1
fi

SSH_KEY_PRIVATE_FILE=$1
BRANCH_NAME=$2
REG_MOVIE_LIST=$3
OUTPUT_DIR=$4

REG_DATA_DIR="regression_data"
REG_CACHE_DIR="regression_cache"
CURR_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

if [ "$#" == 4 ]; then
   PARAMS_FILE="None" 
   RETAILER="demo_latest"
elif [ "$#" == 5 ]; then
   PARAMS_FILE=$5
   RETAILER="demo_latest"
else
   PARAMS_FILE=$5
   RETAILER=$6

   if [ ${RETAILER} != "demo_latest" ] && [ ${RETAILER} != "Tiv-Taam" ] && 
      [ ${RETAILER} != "jumbo" ] && [ ${RETAILER} != "asda_poc" ] && 
      [ ${RETAILER} != "evergreen" ] && [ ${RETAILER} != "morrisons" ] && 
      [ ${RETAILER} != "ALDI_STORE" ] && [ ${RETAILER} != "bunting" ] && [ ${RETAILER} != "edeka" ]; then
      echo "Invalid retailer name, abortig script"
      exit 1
   fi

fi

# Install azure cli from here: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt
# sudo apt install -y jq azure-cli

function get_stopped_candidate(){
   VM_NAME=$(az vm list -d -g ${AZ_RESOURCE_GROUP} --query \
    "[?storageProfile.imageReference.id == '${AZ_LATEST_ALGO_IMAGE_ID}']|[?hardwareProfile.vmSize=='${AZ_VM_SIZE}']|[?powerState == 'VM stopped'].{name:name}" \
                                                                                                                                                         -o table | sed -n 3p)
   if [ -z "$VM_NAME" ]
   then
      VM_NAME=$(az vm list -d -g ${AZ_RESOURCE_GROUP} --query \
          "[?storageProfile.imageReference.id == '${AZ_LATEST_ALGO_IMAGE_ID}']|[?hardwareProfile.vmSize=='${AZ_VM_SIZE}']|[?powerState == 'VM deallocated'].{name:name}" \
                                                                                                                                                         -o table | sed -n 3p)
   fi                                                                                                                                                         
}

if [ ! -f ${SSH_KEY_PUBLIC_FILE} ]
then
   echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDCOEIS1A2a4cOkDV8pVfu8cCgaaQTKlmPa6XgdXlYYpdjhvswHTvfn9IYc17a9hyX71IGdFv0GcdvdJTXg+iffZrgk7os32M3IcP3KkIPrbBXMR9mn2FdngYo7WEneNM1AI94t5Me1iNP84m9JKdxCkGY9DSCJOwvCMPkpFfuBj7ljsM4cXNHUJEXDiExv1FGfB5NHJljwL5VTRp87pV5cj8Of2lKVxIRyycmXg9VrnN3yCSncsp6ZFNOYIwAs3T1kvv11VdgR9pb9mVxPe49JVli/OdLylGXYXJbOUKldkE8pml1njnC01DEJ2Qow76FYkWdnMpuX4YEAfE/6PSH/Flc4x8MgpVNhYAOUV0LNv/VCvy+Meee4h5Nnd3ZlVJFGMTPeZcOGPKfcpNq3rai2v1p5tqSL5YVwZ1RFF1T3ES8YEJSBVkKJUqL/DSJnyZWNsCVZOktsY5oIpAc11TJUe6WaAi/Ec4E1izVIJbABcFowJ28WMPZIkMER+yryX0M= generated-by-azure' > "${SSH_KEY_PUBLIC_FILE}"
fi

get_stopped_candidate
echo ${VM_NAME}

if [ ! -z "$VM_NAME" ]
then
   az vm start -g algo_rescource -n ${VM_NAME}
   VM_IP=$(az vm list -d -g ${AZ_RESOURCE_GROUP} --query "[?name=='${VM_NAME}'].{IP:publicIps}" |jq -r '.[0].IP')
else
   VM_NAME="Regression-$(date +%Y-%m-%d_%H-%M-%S)"
   ANS=$(az vm create --resource-group ${AZ_RESOURCE_GROUP} -l ${AZ_ZONE} --size ${AZ_VM_SIZE} --name ${VM_NAME} --image ${AZ_LATEST_ALGO_IMAGE_NAME} --ssh-key-values ${SSH_KEY_PUBLIC_FILE})
   rm -rf ${SSH_KEY_PUBLIC_FILE}

   if [[ ${ANS} == *'running'* ]]
   then
      VM_IP=$(echo ${ANS} | jq -r '.publicIpAddress')
   fi
fi

echo 'regression VM instance IP is ' ${VM_IP}

### let stopped machine go up
sleep 30

if [ ${PARAMS_FILE} != "None" ]
then
    scp -o StrictHostKeyChecking=no -i $SSH_KEY_PRIVATE_FILE $PARAMS_FILE $OS_USR@$VM_IP:/home/$OS_USR/walkout/ext_params.yaml
fi


scp -o StrictHostKeyChecking=no -i $SSH_KEY_PRIVATE_FILE $REG_MOVIE_LIST $OS_USR@$VM_IP:/home/$OS_USR/walkout/ourFirstCNN/recording_list/ext_movies.csv

ssh -o StrictHostKeyChecking=no $OS_USR@$VM_IP -i $SSH_KEY_PRIVATE_FILE 'bash -s' << EOF "
    source /home/${OS_USR}/.bashrc;
    sudo chmod 777 -R /mnt;
    rm -rf /mnt/${REG_DATA_DIR};
    mkdir -p /mnt/${REG_DATA_DIR};
    rm -rf /mnt/${REG_CACHE_DIR};
    mkdir -p /mnt/${REG_CACHE_DIR};
    cd walkout;
    git stash;
    git fetch;
    git checkout $BRANCH_NAME;
    git pull;
    cd ~/walkout;
    aws s3 cp s3://walkout-main/RND/DB/${RETAILER}/database.sqlite3 webapp/server/database.sqlite3
    source ~/.bashrc;
    ./install.sh;
    cd ourFirstCNN/;
    source ~/py3_env/bin/activate;
    export PYTHONPATH=/home/${OS_USR}/walkout;
    python WalkoutExecutor.py --movies-file recording_list/ext_movies.csv  --root-dir /mnt/${REG_DATA_DIR} --params /home/${OS_USR}/walkout/ext_params.yaml --log-failures --delete-movies --cache-dir /mnt/${REG_CACHE_DIR}; "
EOF

# Copy back regression results
scp -r -o StrictHostKeyChecking=no -i $SSH_KEY_PRIVATE_FILE $OS_USR@$VM_IP:/mnt/$REG_CACHE_DIR/results/ $OUTPUT_DIR

#az vm deallocate -g ${AZ_RESOURCE_GROUP} -n ${VM_NAME}
