import xmltodict
import pprint
import json

with open('product.xml') as fd:
    xml = xmltodict.parse(fd.read())

data = xml['ProductSet']['Product']
Upc = xml['ProductSet']['Upc']

Products = {}
for item in Upc:
    Products[item['Upc']] = item['ProductCode']

ProductSet = {}
for item in data:
    ProductSet[item['ProductCode']] = {
        'name': item['Description'],
        'price': float(item['UnitPriceBase']) if 'UnitPriceBase' in item else -1
    }

json_ = {}
for key, value in Products.items():
    json_[key] = {'name': ProductSet[value]['name'],
                  'price': ProductSet[value]['price']
                  }
j = json.dumps(json_, indent=4, ensure_ascii=False)
with open('product.json', 'w') as f:
    f.write(j)
