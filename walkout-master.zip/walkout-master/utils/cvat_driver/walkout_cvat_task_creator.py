import logging
import os
import time
import argparse
from random import shuffle

import numpy as np
import requests
import sys
from http.client import HTTPConnection
projectPath = os.path.dirname(os.path.join(os.path.dirname(__file__), '../'))
sys.path.append(projectPath)
from cvat_driver.core.core import CLI, CVAT_API_V1,ResourceType
from cv_blocks.misc.aws_download import remote_ls, upload_file
log = logging.getLogger(__name__)
import json
from pathlib import Path
import zipfile
import shutil
import pandas as pd

LABELS_PATH=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tasks_labels')
CVAT_S3_MACHINE_MOUNT = 'walkout-main'


class DbApi:
    def __init__(self, user, password, retailer, url="http://database.walkout.co"):
        self.url = "http://database.walkout.co"
        auth = requests.post(url='{}/auth/login'.format(url),
                             json={'email': user, 'password': password})
        if auth.status_code != 200:
            print(auth.json())
            sys.exit(1)
        self.retailer = retailer
        self.jwt = auth.cookies['jwt']

    def get_images(self, products):
        products_urls = {}
        for product in products:
            response = requests.get(url='{}/api/v1/products/get_products_by_product_code/{}/{}'.format(
                self.url, self.retailer, product), cookies={'jwt': self.jwt})
            if response.status_code == 200:
                # response.raw.decode_content = True
                products_urls[product] = response.json()['image_url']
        return products_urls

def config_log(level):
    log = logging.getLogger('core')
    log.addHandler(logging.StreamHandler(sys.stdout))
    log.setLevel(level)
    if level <= logging.DEBUG:
        HTTPConnection.debuglevel = 1

def upload_http_image_to_s3(image_url, data_name):
    filename = image_url.split('/')[-1] + '.jpg'
    full_local_path = os.path.join('/tmp', filename)
    r = requests.get(image_url, stream=True)
    if r.status_code == 200:
        # Set decode_content value to True, otherwise the downloaded image file's size will be zero.
        r.raw.decode_content = True
        # Open a local file with wb ( write binary ) permission.
        with open(full_local_path, 'wb') as f:
            shutil.copyfileobj(r.raw, f)
        print('Sample image sucessfully Downloaded to: ', filename)
        uploaded_path = upload_file(full_local_path, 'RND/images/{}/{}'.format(data_name, filename))
        os.remove(full_local_path)
        return uploaded_path
    return None

def execute_action(action,arg_dict,loglevel,server_host,server_port,auth):
    response = None
    with requests.Session() as session:
        api = CVAT_API_V1('%s:%s' % (server_host, server_port))
        cli = CLI(session, api, auth)
        actions = {'create': cli.tasks_create,
                   'delete': cli.tasks_delete,
                   'ls': cli.tasks_list,
                   'frames': cli.tasks_frame,
                   'dump': cli.tasks_dump,
                   'https':True,
                   'upload': cli.tasks_upload}
        config_log(loglevel)
        try:
            response = actions[action](**arg_dict)
        except (requests.exceptions.HTTPError,
                requests.exceptions.ConnectionError,
                requests.exceptions.RequestException) as e:
            log.critical(e)
    return response

def get_all_images(path,grep_list=[], max_img_per_sku=None, skus=None, local=False):
    assert isinstance(grep_list, (list, tuple))
    if local:
        assert(os.path.exists(path))
        result = list(Path(path).rglob("*.jpg"))
        files = [str(img_path) for img_path in result]
        if len(grep_list)>0:
            l_grep =[]
            for grep_val in grep_list:
                l_grep += [img for img in files if grep_val in img]
            files = list(set(l_grep)) # get uniqe images only
    else:
        files = remote_ls(path, recursive=True, filter_str=['.png', '.jpeg', '.jpg'])
        files = ['%s/%s' % (CVAT_S3_MACHINE_MOUNT, f) for f in files]

    if len(grep_list)>0:
        l_grep =[]
        for grep_val in grep_list:
            l_grep += [img for img in files if grep_val in img]
        files = list(set(l_grep)) # get unique images only
    
    if max_img_per_sku is not None and len(files) > max_img_per_sku * len(skus):
        filtered_list = []
        for single_sku in skus:
            sku_images = [s for s in files if single_sku in s]
            shuffle(sku_images)
            filtered_list += sku_images[:max_img_per_sku]
        return filtered_list
    else:
        return files

def create_empty_xml(item_count,tag_label ="event",label_attribute = 'event type'):
    strng = '<?xml version="1.0" encoding="utf-8"?>\n\t<annotations>\n\t\t<version>1.1</version>\n'

    for i in range(item_count):
        strng += '\t\t\t<image id="{}" name="na"> <tag label="{}">  <attribute name="{}"></attribute> </tag> </image>\n'.format(i,tag_label,label_attribute)

    strng += '\t</annotations>'
    file_name = "output.xml"
    with open(file_name, "w") as text_file:
        text_file.write(strng)

    return os.path.join(str(Path().absolute()), file_name)

def get_product_list(src_dir, local):
    if local:
        products = os.listdir(src_dir)
    else:
        products = remote_ls(src_dir, dirs_only=True)
    return products

def get_sample_images(images_root_dir, local, data_name, images_source, products=None, db_api=None):
    s3_images_path = 'RND/images/{}'.format(data_name)
    if images_source == 'memento':
        from utils.database_gen.MementoDBConnector import MementoDBConnector
        memento = MementoDBConnector(data_name)
        product_images = {}
        for product_code, value in memento.get_data_for_cvat().items():
            if product_code in products:
                product_images[product_code] = (value['front image'][0])
        return product_images
    if local:
        classifier_sample_images_dir = os.path.join(images_root_dir, 'product_images')
        if not os.path.exists(classifier_sample_images_dir):
            try:
                from cv_blocks.misc.aws_download import download_cart_data
                download_cart_data(s3_images_path,classifier_sample_images_dir, include=products)
            except:
                raise NameError("couldn't download product images")
        return [os.path.join(classifier_sample_images_dir, f) for f in os.listdir(classifier_sample_images_dir)]
    else:
        if images_source == 'db':
            product_images = db_api.get_images(products)
        else:  # images_source == 's3'
            product_images = remote_ls(s3_images_path)
            if products is not None:
                product_images = [os.path.join(CVAT_S3_MACHINE_MOUNT, s3_images_path, pi) \
                    for pi in product_images if os.path.splitext(pi)[0] in products]
        return product_images

def generate_task(task_type, images_root_dir, server_host, server_port, auth, data_name, images_source,
                  max_imgs_pd, max_imgs_ed, max_imgs_dd, max_imgs_pc, max_imgs_cc, max_imgs_mc, categories_cc,
                  products_list, task_name=None, task_prefix=None, local=False, db_api=None):
    assert task_prefix not in ('', None)
    loglevel = logging.INFO
    img_dir = os.path.join(images_root_dir, 'product_classifier')
    labels_json = '{}/labels_{}.json'.format(LABELS_PATH,task_type)
    with open(labels_json) as f:
        labels_dict = json.load(f)
    if task_type not in ('crop_classifier', 'multi_classifier'):
        try:
            products = get_product_list(img_dir, local)
        except:
            products = None
            max_imgs_pd = None
    if task_type=='diff_detector':
        arg_dict = get_params(images_root_dir, task_type,task_name, max_img_per_sku=max_imgs_dd, skus=products, segment_size=100, local=local)
        if task_prefix is not None:
            arg_dict['name'] = task_prefix + '_' + arg_dict['name']
        action = 'create'
        execute_action(action, arg_dict, loglevel, server_host, server_port, auth)

    if task_type == 'product_detector':
        arg_dict = get_params(images_root_dir, task_type,task_name, max_img_per_sku=max_imgs_pd, skus=products, segment_size=100, local=local)
        if task_prefix is not None:
            arg_dict['name'] = task_prefix + '_' + arg_dict['name']
        action = 'create'
        execute_action(action, arg_dict, loglevel, server_host, server_port, auth)
    elif task_type == 'product_detector_v2':
        arg_dict = get_params(images_root_dir, task_type,task_name, max_img_per_sku=max_imgs_pd, skus=products, segment_size=100, local=local)
        if task_prefix is not None:
            arg_dict['name'] = task_prefix + '_' + arg_dict['name']
        action = 'create'
        response = execute_action(action, arg_dict, loglevel, server_host, server_port, auth)
        task_id = response['id']

        # Upload empty tags
        print('\033[93mTask:%s waiting for task to be ready before uploading annotations\033[00m' % task_type)
        while True:
            time.sleep(1)
            response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
            ed_result = [r for r in response if r['id']==task_id]
            assert len(ed_result)==1
            ed_result = ed_result[0]
            task_ready = ed_result['mode']!='' and len(ed_result['segments']) > 0 and ed_result['size'] > 0
            if task_ready:
                break

        image_count = ed_result['size']
        xml_path = create_empty_xml(image_count)
        arg_dict = {'task_id': task_id,
                    'fileformat': "CVAT 1.1",
                    'filename': xml_path}
        response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)

    elif task_type == 'event_detector':
        arg_dict = get_params(images_root_dir, task_type, segment_size=500, local=local, max_total=max_imgs_ed)
        if task_prefix is not None:
            arg_dict['name'] = task_prefix + '_' + arg_dict['name']
        arg_dict['img_quality'] = 30
        action = 'create'
        response = execute_action(action, arg_dict, loglevel, server_host, server_port, auth)
        task_id = response['id']

        # Upload empty tags
        print('\033[93mTask:%s waiting for task to be ready before uploading annotations\033[00m' % task_type)
        while True:
            time.sleep(1)
            response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
            ed_result = [r for r in response if r['id']==task_id]
            assert len(ed_result)==1
            ed_result = ed_result[0]
            task_ready = ed_result['mode']!='' and len(ed_result['segments']) > 0 and ed_result['size'] > 0
            if task_ready:
                break

        image_count = ed_result['size']
        xml_path = create_empty_xml(image_count)
        arg_dict = {'task_id': task_id,
                    'fileformat': "CVAT 1.1",
                    'filename': xml_path}
        response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)

    elif task_type=='crop_classifier':
        crop_cat_task_ids = dict()
        for single_category in categories_cc:
            # Get all valid images per category
            category_dir = os.path.join(images_root_dir, 'crop_classifier', single_category)
            grep_list = ['back_rgb_crop', 'front_rgb_crop']
            resources = get_all_images(category_dir, grep_list, max_img_per_sku=max_imgs_cc, local=local)
            print('\033[93mTask:%s/%s sending %d images for annotation\033[00m' % (task_type, single_category, len(resources)))
            batches = int(np.ceil(len(resources) / 10000))
            for batch in range(batches):
                resource_type = ResourceType.LOCAL if local else ResourceType.SHARE
                arg_dict = {'resources': resources[batch*10000:min(len(resources) + 1, (batch + 1)*10000)],
                            'resource_type': resource_type,
                            'name': task_type + '_' + single_category,
                            'bug': '',
                            'labels': labels_dict,
                            'z_order': False,
                            'segment_size':500,
                            'overlap': 0,
                            }
                if task_prefix is not None:
                    arg_dict['name'] = task_prefix + '_' + arg_dict['name']
                action = 'create'
                response = execute_action(action, arg_dict, loglevel, server_host, server_port, auth)
                crop_cat_task_ids[single_category] = response['id']
        
                print('\033[93mTask:%s/%s waiting for task to be ready before uploading annotations\033[00m' % (task_type, single_category, ))
                # Upload empty tags
                while True:
                    time.sleep(1)
                    response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
                    cc_results = [r for r in response if r['id']==crop_cat_task_ids[single_category]]
                    cc_result = cc_results[-1]
                    task_ready = cc_result['mode']!='' and len(cc_result['segments']) > 0 and cc_result['size'] > 0
                    if task_ready:
                        image_count = cc_result['size']
                        xml_path = create_empty_xml(image_count, "crop", "item_location")
                        arg_dict = {'task_id': crop_cat_task_ids[single_category],
                                    'fileformat': "CVAT 1.1",
                                    'filename': xml_path}
                        response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)
                        break

    elif task_type == 'product_classifier':
        prod_task_ids = dict()
        if products_list is not None:
            temp_products = []
            mapping = {}
            for product in products:
                if product in products_list['product_name'].to_list():
                    temp_products.append(products_list[products_list['product_name']==product]['barcode'].item())
                    mapping[product] = temp_products[-1]
                else:
                    temp_products.append(product)
                    mapping[product] = product
        else:
            temp_products = products
        sample_images_path = get_sample_images(images_root_dir, local, data_name=data_name, products=temp_products,
                                               images_source=images_source, db_api=db_api)
        for i, product in enumerate(products):
            print (i, product)
            if product == 'UnLabelled':
                continue
            # set 1st image to be a sample
            if images_source == 's3' or images_source == 'db':
                if products_list is not None:
                    result = [im for im in sample_images_path if mapping[product] in im]
                else:
                    if images_source == 's3':
                        result = [im for im in sample_images_path if product in im]
                    else:  # images_source == 'db'
                        result = [sample_images_path[product]] if product in sample_images_path.keys() else []
                if len(result)==1:
                    sample_image = str(result[0])
                    resources = [sample_image]
                else:
                    print("No sample image for {}".format(product))
                    resources = []
            else:
                result = sample_images_path.get(product, None)
                sample_image = upload_http_image_to_s3(result, data_name) if result is not None else None
                if sample_image is not None:
                    resources = [sample_image]
                else:
                    print("No sample image for {}".format(product))
                    resources = []

            # set rest of images
            product_dir = os.path.join(img_dir, product)
            grep_list = ['back_rgb_crop', 'front_wnoise_crop', 'cart_bottom_rgb_crop']
            resources += get_all_images(product_dir, grep_list, max_img_per_sku=max_imgs_pc, local=local, skus=[product])
            print('\033[93mTask:%s/%s sending %d images for annotation\033[00m' % (task_type, product, len(resources)))

            resource_type = ResourceType.LOCAL if local else ResourceType.SHARE
            arg_dict = {'resources': resources,
                        'resource_type': resource_type,
                        'name': task_type + '_' + product,
                        'bug': '',
                        'labels': labels_dict,
                        'z_order': False,
                        'segment_size':500,
                        'overlap': 0,
                        }
            if task_prefix is not None:
                arg_dict['name'] = task_prefix + '_' + arg_dict['name']
            action = 'create'
            response = execute_action(action, arg_dict, loglevel, server_host, server_port, auth)
            prod_task_ids[product] = response['id']

        # Upload empty annotations
        # for product in products: bugfix - wait until task is ready before uploading annotations
            print('\033[93mTask:%s/%s waiting for task to be ready before uploading annotations\033[00m' % (task_type, product, ))
            if product == 'UnLabelled':
                continue
            counter = 0
            while (counter<10):
                time.sleep(1)
                response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
                if response:
                    counter = 0
                    product_result = [r for r in response if r['id']==prod_task_ids[product]]
                    assert len(product_result)==1
                    product_result = product_result[0]
                    task_ready = product_result['mode']!='' and len(product_result['segments']) > 0 and product_result['size'] > 0
                    if task_ready:
                        break
                else:
                    counter +=1
                
            image_count = product_result['size']
            xml_path = create_empty_xml(image_count,"valid_image","valid")
            arg_dict = {'task_id': prod_task_ids[product],
                        'fileformat': "CVAT 1.1",
                        'filename': xml_path}
            response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)

    elif task_type=='multi_classifier':
        # Get all valid images per category
         # note we take the image from another task
        category_dir = os.path.join(images_root_dir, 'product_classifier')
        grep_list = ['back_rgb_crop', 'front_rgb_crop']
        resources = get_all_images(category_dir, grep_list, max_img_per_sku=None, local=local)
        print('\033[93mTask:%s sending %d images for annotation\033[00m' % (task_type, len(resources)))

        resource_type = ResourceType.LOCAL if local else ResourceType.SHARE
        arg_dict = {'resources': resources,
                    'resource_type': resource_type,
                    'name': task_type,
                    'bug': '',
                    'labels': labels_dict,
                    'z_order': False,
                    'segment_size':500,
                    'overlap': 0,
                    }
        if task_prefix is not None:
            arg_dict['name'] = task_prefix + '_' + arg_dict['name']
        action = 'create'
        response = execute_action(action, arg_dict, loglevel, server_host, server_port, auth)
        task_id = response['id']
        
        print('\033[93mTask:%s waiting for task to be ready before uploading annotations\033[00m' % (task_type, ))
        # Upload empty tags
        while True:
            time.sleep(1)
            response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
            mc_result = [r for r in response if r['id']==task_id]
            assert len(mc_result)==1
            mc_result = mc_result[0]
            task_ready = mc_result['mode']!='' and len(mc_result['segments']) > 0 and mc_result['size'] > 0
            if task_ready:
                break

        image_count = mc_result['size']
        xml_path = create_empty_xml(image_count, "multi", "item_quantity")
        arg_dict = {'task_id': task_id,
                    'fileformat': "CVAT 1.1",
                    'filename': xml_path}
        response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)

    pass

def upload_empty_annotations(task_type, images_root_dir, server_host, server_port, auth, task_prefix=None, local=False,
                              categories_cc=('predicted_in', 'predicted_margin', 'predicted_out')):
    assert task_prefix not in ('', None)
    loglevel = logging.INFO
    response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
    tasks = [r for r in response if task_type in r['name'] and task_prefix in r['name']]
    if task_type == 'product_classifier':
        img_dir = os.path.join(images_root_dir, 'product_classifier')
        products = get_product_list(img_dir, local)
        for product in products:
            if product == 'UnLabelled':
                continue
            print('\033[93mTask:%s/%s - uploading empty annotations\033[00m' % (task_type, product))
            product_results = [t for t in tasks if product in t['name']]
            for product_result in product_results:
                image_count = product_result['size']
                xml_path = create_empty_xml(image_count, "valid_image", "valid")
                arg_dict = {'task_id': product_result['id'],
                            'fileformat': "CVAT 1.1",
                            'filename': xml_path}
                response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)
    elif task_type in ('event_detector', 'product_detector_v2'):
        print('\033[93mTask:%s - uploading empty annotations\033[00m' % (task_type))
        for ed_task in tasks:
            image_count = ed_task['size']
            xml_path = create_empty_xml(image_count)
            arg_dict = {'task_id': ed_task['id'],
                        'fileformat': "CVAT 1.1",
                        'filename': xml_path}
            response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)
    elif task_type == 'crop_classifier':
        for single_category in categories_cc:
            print('\033[93mTask:%s/%s - uploading empty annotations\033[00m' % (task_type, single_category))
            cat_results = [t for t in tasks if single_category in t['name']]
            for cat_result in cat_results:
                image_count = cat_result['size']
                xml_path = create_empty_xml(image_count, "crop", "item_location")
                arg_dict = {'task_id': cat_result['id'],
                            'fileformat': "CVAT 1.1",
                            'filename': xml_path}
                response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)
    elif task_type == 'multi_classifier':
        print('\033[93mTask:%s - uploading empty annotations\033[00m' % (task_type))
        for mc_task in tasks:
            image_count = mc_task['size']
            xml_path = create_empty_xml(image_count, "multi", "item_quantity")
            arg_dict = {'task_id': mc_task['id'],
                        'fileformat': "CVAT 1.1",
                        'filename': xml_path}
            response = execute_action('upload', arg_dict, loglevel, server_host, server_port, auth)


def download_results(task_type, images_root_dir, server_host, server_port, auth, task_prefix=None):
    assert task_prefix not in ('', None)

    # Query Completed tasks
    loglevel = logging.INFO
    response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
    completed_tasks = [r for r in response if task_type in r['name'] and task_prefix in r['name'] and r['status']=='completed']
    print('\033[93mTask:%s Found %d completed tasks\033[00m' % (task_type, len(completed_tasks)))
    if task_type=='product_classifier':
        # Download task results
        for r in completed_tasks:
            cls_name = r['name'].split('product_classifier_')[-1]
            results_path = '/tmp/product_classifier_annotations_%s.zip' % cls_name
            arg_dict = {'task_id': r['id'],
                        'fileformat': "CVAT for images 1.1",
                        'filename': results_path}
            response = execute_action('dump', arg_dict, loglevel, server_host, server_port, auth)
            result_file = os.path.join(os.path.splitext(results_path)[0], 'annotations.xml')
            os.makedirs(os.path.dirname(result_file), exist_ok=True)
            with zipfile.ZipFile(results_path,'r') as zip_ref: 
                zip_ref.extractall(os.path.dirname(result_file))
            # Copy to cloud location
            aws_dst = os.path.join(images_root_dir, 'product_classifier', cls_name, 'annotations.xml')
            print('\033[93mUploading %d annotations for product %s\033[00m' % (r['size'], cls_name))
            upload_file(result_file, aws_dst)
    elif task_type in ('product_detector', 'diff_detector'):
        # Download task results
        assert len(completed_tasks) <= 1
        for r in completed_tasks:
            results_path = '/tmp/%s_annotations_%s.zip' % (task_type, task_prefix)
            arg_dict = {'task_id': r['id'],
                        'fileformat': "COCO 1.0",
                        'filename': results_path}
            response = execute_action('dump', arg_dict, loglevel, server_host, server_port, auth)
            result_file = os.path.join(os.path.splitext(results_path)[0], 'instances_default.json')
            os.makedirs(os.path.dirname(result_file), exist_ok=True)
            with zipfile.ZipFile(results_path,'r') as zip_ref: 
                zip_ref.extractall(os.path.dirname(result_file))
            result_file = os.path.join(os.path.splitext(results_path)[0], 'annotations', 'instances_default.json')
            assert os.path.exists(result_file)
            # Copy to cloud location
            aws_dst = os.path.join(images_root_dir, task_type, 'annotations.json')
            print('\033[93mUploading %d annotations for %s\033[00m' % (r['size'], task_type))
            upload_file(result_file, aws_dst)
    elif task_type=='event_detector':
        # Download task results
        assert len(completed_tasks) <= 1
        for r in completed_tasks:
            results_path = '/tmp/%s_annotations_%s.zip' % (task_type, task_prefix)
            arg_dict = {'task_id': r['id'],
                        'fileformat': "CVAT for images 1.1",
                        'filename': results_path}
            response = execute_action('dump', arg_dict, loglevel, server_host, server_port, auth)
            result_file = os.path.join(os.path.splitext(results_path)[0], 'annotations.xml')
            os.makedirs(os.path.dirname(result_file), exist_ok=True)
            with zipfile.ZipFile(results_path,'r') as zip_ref: 
                zip_ref.extractall(os.path.dirname(result_file))
            assert os.path.exists(result_file)
            # Copy to cloud location
            aws_dst = os.path.join(images_root_dir, task_type, 'annotations.xml')
            print('\033[93mUploading %d annotations for %s\033[00m' % (r['size'], task_type))
            upload_file(result_file, aws_dst)
    elif task_type=='product_detector_v2':
        # Download task results
        assert len(completed_tasks) <= 1
        for r in completed_tasks:
            results_path = '/tmp/%s_annotations_%s.zip' % (task_type, task_prefix)
            arg_dict = {'task_id': r['id'],
                        'fileformat': "CVAT for images 1.1",
                        'filename': results_path}
            response = execute_action('dump', arg_dict, loglevel, server_host, server_port, auth)
            result_file = os.path.join(os.path.splitext(results_path)[0], 'annotations.xml')
            os.makedirs(os.path.dirname(result_file), exist_ok=True)
            with zipfile.ZipFile(results_path,'r') as zip_ref: 
                zip_ref.extractall(os.path.dirname(result_file))
            assert os.path.exists(result_file)
            # Copy to cloud location
            aws_dst = os.path.join(images_root_dir, 'product_detector', '%s_annotations.xml' % task_type)
            print('\033[93mUploading %d annotations for %s\033[00m' % (r['size'], task_type))
            upload_file(result_file, aws_dst)
    elif task_type=='crop_classifier':
        # Download task results
        categories_counter = dict()
        for r in reversed(completed_tasks):
            category_name = r['name'].split('crop_classifier_')[-1]
            if category_name not in categories_counter:
                categories_counter[category_name] = 0
            else:
                categories_counter[category_name] += 1
            results_path = '/tmp/crop_classifier_annotations_%s.zip' % category_name
            arg_dict = {'task_id': r['id'],
                        'fileformat': "CVAT for images 1.1",
                        'filename': results_path}
            response = execute_action('dump', arg_dict, loglevel, server_host, server_port, auth)
            result_file = os.path.join(os.path.splitext(results_path)[0], 'annotations.xml')
            os.makedirs(os.path.dirname(result_file), exist_ok=True)
            with zipfile.ZipFile(results_path,'r') as zip_ref: 
                zip_ref.extractall(os.path.dirname(result_file))
            assert os.path.exists(result_file)
            # Copy to cloud location
            aws_dst = os.path.join(images_root_dir, 'crop_classifier', category_name, 'annotations_{}.xml'.format(categories_counter[category_name]))
            print('\033[93mUploading %d annotations for product %s\033[00m' % (r['size'], category_name))
            upload_file(result_file, aws_dst)
    elif task_type=='multi_classifier':
        # Download task results
        for idx, r in enumerate(reversed(completed_tasks)):
            results_path = '/tmp/%s_annotations_%s.zip' % (task_type, task_prefix)
            arg_dict = {'task_id': r['id'],
                        'fileformat': "CVAT for images 1.1",
                        'filename': results_path}
            response = execute_action('dump', arg_dict, loglevel, server_host, server_port, auth)
            result_file = os.path.join(os.path.splitext(results_path)[0], 'annotations.xml')
            os.makedirs(os.path.dirname(result_file), exist_ok=True)
            with zipfile.ZipFile(results_path,'r') as zip_ref: 
                zip_ref.extractall(os.path.dirname(result_file))
            assert os.path.exists(result_file)
            # Copy to cloud location
            aws_dst = os.path.join(images_root_dir, 'product_classifier', 'multi_classifier_annotations_%02d.xml' % (idx))
            print('\033[93mUploading %d annotations for %s\033[00m' % (r['size'], task_type))
            upload_file(result_file, aws_dst)
    
def delete_results(task_type, images_root_dir, server_host, server_port, auth, task_prefix=None, completed_only=False):
    assert task_prefix not in ('', None)

    # Query Completed tasks
    loglevel = logging.INFO
    response = execute_action('ls', {'use_json_output': True}, loglevel, server_host, server_port, auth)
    all_tasks = [r for r in response if task_type in r['name'] and task_prefix in r['name']]
    if completed_only:
        all_tasks = [r for r in all_tasks if r['status']=='completed']
        print('\033[93mTask:%s deleting %d completed tasks\033[00m' % (task_type, len(all_tasks)))
    else:
        print('\033[93mTask:%s deleting %d tasks\033[00m' % (task_type, len(all_tasks)))
    if len(all_tasks) > 0:
        task_ids = [r['id'] for r in all_tasks]
        arg_dict = {'task_ids': task_ids}
        response = execute_action('delete', arg_dict, loglevel, server_host, server_port, auth)

def get_params(images_root_dir, task_type,task_name=None, segment_size=200, max_img_per_sku=None, skus=None, local=False, max_total=None):
    if task_type=='product_detector_v2':
        img_dir = os.path.join(images_root_dir, 'product_detector')
    else:
        img_dir = os.path.join(images_root_dir, task_type)
    grep_list = []
    if task_type=='product_detector':
        grep_list = ['back_full', 'front_full']
    elif task_type=='product_detector_v2':
        grep_list = ['back_viz', 'front_viz']
    resources = get_all_images(img_dir, grep_list, max_img_per_sku=max_img_per_sku, skus=skus, local=local)
    if max_total is not None:
        shuffle(resources)
        resources = resources[:max_total]
    print('\033[93mTask:%s sending %d images for annotation\033[00m' % (task_type, len(resources)))


    labels_json = '{}/labels_{}.json'.format(LABELS_PATH,task_type)
    if task_name is None:
        task_name = task_type

    with open(labels_json) as f:
        labels_dict = json.load(f)
    resource_type = ResourceType.LOCAL if local else ResourceType.SHARE
    arg_dict = {'resources': resources,
                'resource_type': resource_type,
                'name': task_name,
                'bug': '',
                'overlap': 0,
                'labels': labels_dict,
                'z_order': task_type == 'diff_detector' or task_type == 'product_detector',
                'segment_size': segment_size
                }
    return arg_dict


ALL_VALID_TASKS = ['product_detector','diff_detector', 'product_classifier', 'event_detector', 'crop_classifier', 'multi_classifier',
                   'product_detector_v2']
DEFAULT_TASKS = ['diff_detector', 'product_classifier', 'event_detector', 'crop_classifier', 'product_detector_v2']
VISUAL_DB_DIR = 'visual_db_storage'
DEFAULT_HOST = 'annotation.walkout.co'
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='object detector benchmark')
    parser.add_argument('--op', help='operation to tack(create|download)',type=str, required=True)
    parser.add_argument('--input-dir', help='root images directory',type=str, required=True)
    parser.add_argument('--dataset-name', help='what dataset to load sample images from',type=str, default='demo_latest')
    parser.add_argument('--images-source', help='images source: s3 / memento',type=str, default='db')
    parser.add_argument('--tasks', help='what type of tasks to create',type=str, default='all')
    parser.add_argument('--task-prefix', help='common name to all tasks',type=str, default=None)
    parser.add_argument('--local', help='use local dataset', action='store_true')
    parser.add_argument('--db-dir', help='data remote dir',type=str, default='visual_db_storage')
    parser.add_argument('--host', help='annotation server address',type=str, default=DEFAULT_HOST)
    parser.add_argument('--port', help='annotation server port',type=str, default='443')
    parser.add_argument('--images-prod-detector', help='maximum amount of product detector images per product',type=int, default=100)
    parser.add_argument('--images-prod-classifier', help='maximum amount of product classifier images per product',type=int, default=None)
    parser.add_argument('--images-event-detector', help='maximum amount of event detector images for all products',type=int, default=5000)
    parser.add_argument('--images-diff-detector', help='maximum amount of diff detector images per product',type=int, default=50)
    parser.add_argument('--images-crop-classifier', help='maximum amount of crop classifier images per product',type=int, default=None)
    parser.add_argument('--crop-classifier-subtask', help='subtasks for crop classifier',type=str, default='predicted_margin')
    parser.add_argument('--images-multi-classifier', help='maximum amount of multi classifier images for all products',type=int, default=5000)
    parser.add_argument('--remove-uncompleted', help='delete also uncompleted tasks', action='store_true')
    parser.add_argument('--products-list', help='path to products list csv', type=str, default=None)
    parser.add_argument('--user', help='username for db website', type=str, default=None)
    parser.add_argument('--password', help='password for db website', type=str, default=None)
    parser.add_argument('--retailer', help='retailer name', type=str, default=None)

    args = parser.parse_args()
    auth = ('walkout', 'FocusGever')

    assert args.op in ('create', 'download', 'delete', 'annotations')

    if args.tasks=='all':
        args.tasks = DEFAULT_TASKS
    else:
        args.tasks = args.tasks.split(',')
    
    for t in args.tasks:
        assert t in ALL_VALID_TASKS

    if args.images_source == 'db' and 'product_classifier' in args.tasks:
        assert args.user and args.password and args.retailer, \
            'Please provide user name, password and retailer name to get sample images for product classifier tasks'
        db_api = DbApi(args.user, args.password, args.retailer)
    else:
        db_api = None

    args.input_dir = args.input_dir.split(',')
    if not args.local:
        for i, input_dir in enumerate(args.input_dir):
            args.input_dir[i] = '%s/%s' % (args.db_dir, input_dir)
    for input_dir in args.input_dir:
        print("Input dir: {}".format(input_dir))
        task_prefix = input_dir.split('/')[-1] if args.task_prefix is None else args.task_prefix
        for task in args.tasks:
            print("starting task: {}".format(task))
            categories_cc = args.crop_classifier_subtask.split(',')
            if args.op=='create':
                products_list_csv = pd.read_csv(args.products_list, dtype='object') if args.products_list is not None else None
                generate_task(task, input_dir, args.host, args.port, auth, data_name=args.dataset_name,
                              task_prefix=task_prefix, local=args.local, images_source=args.images_source,
                              max_imgs_pd=args.images_prod_detector, max_imgs_ed=args.images_event_detector,
                              max_imgs_dd=args.images_diff_detector, max_imgs_pc=args.images_prod_classifier,
                              max_imgs_cc=args.images_crop_classifier, max_imgs_mc=args.images_multi_classifier,
                              categories_cc=categories_cc, products_list=products_list_csv, db_api=db_api)
            elif args.op=='download':
                download_results(task,input_dir, args.host, args.port, auth, task_prefix=task_prefix)
            elif args.op=='delete':
                delete_results(task,input_dir, args.host, args.port, auth, task_prefix=task_prefix,
                               completed_only=not args.remove_uncompleted)
            elif args.op == 'annotations':
                upload_empty_annotations(task, input_dir, args.host, args.port, auth, task_prefix=task_prefix,
                                         local=args.local, categories_cc=categories_cc)
