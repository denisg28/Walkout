import argparse
import boto3
import os
import re
from tqdm import tqdm
from random import shuffle

def get_object_list(bucket='walkout-main', prefix=None, filters=[]):
    s3 = boto3.resource('s3')
    my_bucket = s3.Bucket(bucket)
    s3_list = []
    excepted_list = []
    for object_summary in tqdm(my_bucket.objects.filter(Prefix=prefix)):
        object_name = object_summary.key
        if len(filters) > 0:
            valid = False
            for flt in filters:
                if flt in object_name:
                    valid = True; break
            if valid:
                s3_list.append(object_name)
        else:
            s3_list.append(object_name)

    return s3_list

def filter_file_list(file_list, filters=[]):
    output_list = []
    for object_name in file_list:
        if len(filters) > 0:
            valid = False
            for flt in filters:
                if flt in object_name:
                    valid = True; break
            if valid:
                output_list.append(object_name)
        else:
            output_list.append(object_name)

    return output_list

def parse_filters(args):
    product_classifier_filters = args.product_classifier_filters.split(',')
    product_detector_filters = args.product_detector_filters.split(',')
    event_detector_filters = args.event_detector_filters.split(',')
    diff_detector_filters = args.diff_detector_filters.split(',')
    all_filters = product_classifier_filters + product_detector_filters + event_detector_filters + diff_detector_filters
    return dict(product_classifier=product_classifier_filters,
                product_detector=product_detector_filters,
                event_detector=event_detector_filters,
                diff_detector=diff_detector_filters,
                all=all_filters)

def get_task_specific_files(task_name, filters, per_sku=False):
    all_task_samples = filter_file_list(file_list, filters=filters[task_name])
    if per_sku:
        task_samples_per_sku = dict()
        for single_sku in product_list:
            task_samples_per_sku[single_sku] = filter_file_list(all_task_samples, filters=[single_sku])
        return task_samples_per_sku
    else:
        return all_task_samples

def write_local_target(file_dict, task_name, local_dir, job_name, bucket='walkout-main', n_samples='all'):
    n_samples = int(n_samples) if n_samples!='all' else n_samples
    s3_client = boto3.resource('s3')
    bucket = s3_client.Bucket(bucket)
    target_dir = os.path.join(local_dir, job_name, task_name)
    for name, file_list in tqdm(file_dict.items()):
        target_subdir = os.path.join(target_dir, name)
        os.makedirs(target_subdir, exist_ok=True)
        if n_samples!='all':
            shuffle(file_list)
            download_list = file_list[:n_samples]
        else:
            download_list = file_list
        for single_file in download_list:
            try:
                bucket.download_file(single_file, os.path.join(target_subdir, os.path.basename(single_file)))
            except:
                print('\033[93mFailed to get file %s. maybe file does not exist\033[00m' % os.path.basename(single_file))

STORAGE_ROOT = 'visual_db_storage'
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='prepare data to be sent to annotation')
    parser.add_argument('--job-name', help='job name from database',type=str, required=True)
    parser.add_argument('--product-classifier-filters', help='txt patterns for product classifer',type=str, default='front_wnoise_crop,back_rgb_crop,cart_bottom_rgb_crop')
    parser.add_argument('--product-classifier-samples', help='how many samples for product detector(per product)',type=str, default='all')
    parser.add_argument('--product-detector-filters', help='txt patterns for product detector',type=str, default='front_full,back_full')
    parser.add_argument('--product-detector-samples', help='how many samples for product classifier(per product)',type=str, default='100')
    parser.add_argument('--event-detector-filters', help='txt patterns for event detector',type=str, default='event_detector')
    parser.add_argument('--event-detector-samples', help='how many samples for event detector(total)',type=str, default='all')
    parser.add_argument('--diff-detector-filters', help='txt patterns for diff detector',type=str, default='diff_detector')
    parser.add_argument('--diff-detector-samples', help='how many samples for diff detector(total)',type=str, default='all')
    parser.add_argument('--local-dir', help='path to all local directory',type=str, default=None)
    parser.add_argument('--s3-dir', help='path to all directory in s3',type=str, default=None)
    args = parser.parse_args()

    assert args.local_dir is not None or args.s3_dir is not None, 'Output path not given'
    # Parse filters
    filters = parse_filters(args)

    # Get All valid file list
    print('Getting Valid file list...')
    prefix = os.path.join(STORAGE_ROOT, args.job_name)
    file_list = get_object_list(prefix=prefix, filters=filters['all'])
    print('Found %d valid files' % len(file_list))

    # Get unique scanned product SKUs
    print('Getting product SKUs...')
    product_list_classifier = list(set([l.split('product_classifier')[1].split('/')[1] for l in file_list if 'product_classifier' in l]))
    product_list_detector = list(set([l.split('product_detector')[1].split('/')[1] for l in file_list if 'product_detector' in l]))
    product_list = list(set(product_list_classifier+product_list_detector))
    # Filter tagger error - some events are associated to sku and are thrown to SKU level
    # Should not happen in the future
    product_list = [p for p in product_list if 'event_id' not in p]
    print('Found %d unique SKUs' % len(product_list))

    # Download image list from s3
    # Write samples
    if args.local_dir:
        images_list = [os.path.join('RND/images/demo_latest', '%s.png' % p) for p in product_list]
        write_local_target(dict(product_images=images_list), '.', args.local_dir, args.job_name)

    # Prepare Product classifier samples
    product_classifier_samples_per_sku = get_task_specific_files('product_classifier', filters, per_sku=True)
    print('\033[92mProduct classifier samples per SKU:\033[00m')
    for sku, sku_files in product_classifier_samples_per_sku.items():
        print('%s: %d samples' % (sku, len(sku_files)))
    # Write samples
    if args.local_dir:
        write_local_target(product_classifier_samples_per_sku, 'product_classifier', args.local_dir, args.job_name,
        n_samples=args.product_classifier_samples)

    # Prepare Product detector samples
    product_detector_samples_per_sku = get_task_specific_files('product_detector', filters, per_sku=True)
    print('\033[92mProduct detector samples per SKU:\033[00m')
    for sku, sku_files in product_detector_samples_per_sku.items():
        print('%s: %d samples' % (sku, len(sku_files)))
    # Write samples
    if args.local_dir:
        write_local_target(product_detector_samples_per_sku, 'product_detector', args.local_dir, args.job_name,
        n_samples=args.product_detector_samples)
    
    # Prepare event detector samples
    event_detector_samples_per_sku = get_task_specific_files('event_detector', filters, per_sku=False)
    print('\033[92mEvent detector samples:\033[00m')
    print('%s: %d samples' % ('Total', len(event_detector_samples_per_sku)))
    # Write samples
    if args.local_dir:
        write_local_target(dict(all=event_detector_samples_per_sku), 'event_detector', args.local_dir, args.job_name,
        n_samples=args.event_detector_samples)

    # Prepare diff detector samples
    diff_detector_samples_per_sku = get_task_specific_files('diff_detector', filters, per_sku=True)
    print('\033[92mDiff detector samples per SKU:\033[00m')
    for sku, sku_files in diff_detector_samples_per_sku.items():
        print('%s: %d samples' % (sku, len(sku_files)))
    # Write samples
    if args.local_dir:
        write_local_target(diff_detector_samples_per_sku, 'diff_detector', args.local_dir, args.job_name,
        n_samples=args.diff_detector_samples)
    
    print('\033[92mD:\033[00m')