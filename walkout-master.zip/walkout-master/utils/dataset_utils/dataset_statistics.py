import argparse
import os
import pandas as pd
import yaml

def get_file_list(dataset_dir, filters=[]):
    output_list = []
    for root, dir, files in os.walk(dataset_dir):
        for f in files:
            if len(filters) > 0:
                valid = False
                for flt in filters:
                    if flt in f:
                        valid = True; break
                if valid:
                    output_list.append(os.path.join(root, f))

    return output_list

def parse_filters(args):
    product_classifier_filters = args.product_classifier_filters.split(',')
    product_detector_filters = args.product_detector_filters.split(',')
    event_detector_filters = args.event_detector_filters.split(',')
    diff_detector_filters = args.diff_detector_filters.split(',')
    all_filters = product_classifier_filters + product_detector_filters + event_detector_filters + diff_detector_filters
    return dict(product_classifier=product_classifier_filters,
                product_detector=product_detector_filters,
                event_detector=event_detector_filters,
                diff_detector=diff_detector_filters,
                all=all_filters)
    
def generate_batch_summary(dataset_path, movies_file, retailer, output_images):
    batch_info = dict()
    batch_info['retailer'] = retailer
    if movies_file is not None and os.path.exists(movies_file):
        movie_list = pd.read_csv(movies_file, comment='#', names=['movie'], index_col=False, skip_blank_lines=True)['movie'].tolist()
        batch_info['recordings'] = movie_list
    else:
        batch_info['recordings'] = None
    batch_info['output_images'] = output_images
    yaml.dump(batch_info, open(os.path.join(dataset_path,'batch_summary.yaml'), 'w'))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='prepare data to be sent to annotation')
    parser.add_argument('--dataset-path', help='dataset path database',type=str, required=True)
    parser.add_argument('--product-classifier-filters', help='txt patterns for product classifer',type=str, default='front_wnoise_crop,back_rgb_crop,cart_bottom_rgb_crop')
    parser.add_argument('--product-detector-filters', help='txt patterns for product detector',type=str, default='front_full,back_full')
    parser.add_argument('--event-detector-filters', help='txt patterns for event detector',type=str, default='event_detector')
    parser.add_argument('--diff-detector-filters', help='txt patterns for diff detector',type=str, default='diff_detector')
    parser.add_argument('--retailer', help='name of dataset retailer',type=str, default=None)
    parser.add_argument('--movies-file', help='path to movie list',type=str, default=None)
    args = parser.parse_args()

    assert os.path.exists(args.dataset_path)
    # Parse filters
    filters = parse_filters(args)

    # Get unique scanned product SKUs
    product_classifier_file_list = get_file_list(args.dataset_path, filters=filters['product_classifier'])
    print('Getting product SKUs...')
    product_list = list(set([l.split('product_classifier')[1].split('/')[1] for l in product_classifier_file_list if 'product_classifier' in l]))
    # Filter tagger error - some events are associated to sku and are thrown to SKU level
    # Should not happen in the future
    product_list = [p for p in product_list if 'event_id' not in p]
    print('Found %d unique SKUs' % len(product_list))

    data_stat = dict()
    for sku in product_list:
        data_stat[sku] = dict()
    
    # Number of events for product classifier
    for sku in data_stat.keys():
        events = list(set(['_'.join(f.split('/')[-6:-2]) for f in product_classifier_file_list if  '/%s/' % sku in f]))
        data_stat[sku]['product_events'] = len(events)

    # Number of images for product classifier
    for sku in data_stat.keys():
        images = [f for f in product_classifier_file_list if '/%s/' % sku in f]
        data_stat[sku]['product_classifier_images'] = len(images)
    
    # Product detector images
    product_detector_file_list = get_file_list(args.dataset_path, filters=filters['product_detector'])
    for sku in data_stat.keys():
        images = [f for f in product_detector_file_list if '/%s/' % sku in f]
        data_stat[sku]['product_detector_images'] = len(images)

    # Product detector images
    event_detector_file_list = get_file_list(args.dataset_path, filters=filters['event_detector'])
    for sku in data_stat.keys():
        images = [f for f in event_detector_file_list if '/%s/' % sku in f]
        data_stat[sku]['event_detector_images'] = len(images)

    # Diff detector images
    diff_detector_file_list = get_file_list(args.dataset_path, filters=filters['diff_detector'])
    for sku in data_stat.keys():
        images = [f for f in diff_detector_file_list if '/%s/' % sku in f]
        data_stat[sku]['diff_detector_images'] = len(images)

    data_stat = pd.DataFrame.from_dict(data_stat, orient='index')
    data_stat.loc['Total'] = data_stat.sum(numeric_only=True)
    data_stat.to_csv(os.path.join(args.dataset_path,'data_statistics.csv'))
    print('\033[92mFinished to write dataset statistics\033[00m')

    # Generate batch summary
    output_images = data_stat.to_dict()
    generate_batch_summary(args.dataset_path, args.movies_file, args.retailer, output_images)
