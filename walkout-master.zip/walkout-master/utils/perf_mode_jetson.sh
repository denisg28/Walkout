sudo nvpmodel -m 0
sudo jetson_clocks
