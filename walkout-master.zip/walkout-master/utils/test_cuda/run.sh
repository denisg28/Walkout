nvcc hello-world.cu -L /usr/local/cuda/lib -lcudart -o hello-world
./hello-world