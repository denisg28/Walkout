import sys
from datetime import datetime
import sqlite3
from sqlite3 import Error
import os
import uuid
from PIL import Image, ImageDraw
import requests
import csv

END_POINT = 'http://database.walkout.co'  # 'http://localhost:8000'


def transparent_image(imagefile):
    img = Image.open(imagefile)
    transparent_area = (50, 80, 100, 200)
    mask = Image.new('L', img.size, color=255)
    draw = ImageDraw.Draw(mask)
    draw.rectangle(transparent_area, fill=0)
    img.putalpha(mask)
    name = imagefile.split('/')[-1].split('.')[0]
    img.save("{}.png".format(name), "PNG")


def image_to_blob(imagefile):
    # transparent_image(imagefile)
    # name = imagefile.split('/')[-1].split('.')[0]
    # name += '.png'
    # delimeter = '/'
    # image_path = imagefile.split('/')[:-1]
    # image_path.append(name)
    # image_path = delimeter.join(image_path)
    if imagefile is None:
        return None
    with open(imagefile, "rb") as image:
        data = image.read()
        return data


class SqliteConnector:
    def __init__(self):
        self.table_types = {}
        self.tables = ['Products', 'UPC']
        sqlite_name = 'database.sqlite3'
        self.new_db_version = str(uuid.uuid4())
        try:
            if os.path.exists(os.getcwd() + '/{}'.format(sqlite_name)):
                self.sqliteConnection = sqlite3.connect(sqlite_name)
                self.sqliteConnection.text_factory = str
                self.cursor = self.sqliteConnection.cursor()
            else:
                print("no file named {} was found!".format(sqlite_name))
                sys.exit(1)
        except Error as e:
            print("sqlite error - {}".format(e))
            sys.exit(1)

    def close(self):
        self.cursor.close()

    def check_if_product_code_exist(self, product_code):
        query = " SELECT * FROM Products WHERE product_code == " + "'" + product_code + "'"
        self.cursor.execute(query)
        rows = self.cursor.fetchall()
        return True if len(rows) > 0 else False

    def check_if_upc_exist(self, barcode):
        query = " SELECT * FROM UPC WHERE barcode == " + "'" + barcode + "'"
        self.cursor.execute(query)
        rows = self.cursor.fetchall()
        return True if len(rows) > 0 else False

    def insert_products(self, product_code, image, en_name, local_name, aisle, column, shelf,
                        price, plu=None, createdAt=None, updatedAt=None):
        if len(local_name) == 0:
            local_name = en_name
        insert_query = """ INSERT INTO Products
                                  (product_code,image,en_name,local_name,aisle,column,shelf,price,plu_code,createdAt,updatedAt)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        try:
            product_image = image_to_blob(image)
            data_tuple = (product_code, product_image,
                          en_name, local_name, aisle, column, shelf, price, plu,
                          datetime.now() if createdAt is None else datetime.strptime(
                              createdAt, "%Y-%m-%dT%H:%M:%S.%fZ"),
                          datetime.now() if updatedAt is None else datetime.strptime(updatedAt,
                                                                                     "%Y-%m-%dT%H:%M:%S.%fZ"))
            self.cursor.execute(insert_query, data_tuple)
            self.sqliteConnection.commit()
        except Error as e:
            print("error with product {}, error message - {}".format(product_code, e))
            # sys.exit(1)

    def remove_last_version(self):
        for table in ['Versions']:
            delete_table_query = "DELETE FROM {};".format(table)
            delete_sqlite_sequence_query = "DELETE FROM sqlite_sequence WHERE name = '{}';".format(
                table)
            self.cursor.execute(delete_table_query)
            self.sqliteConnection.commit()
            self.cursor.execute(delete_sqlite_sequence_query)
            self.sqliteConnection.commit()

    def generate_db_version(self):
        insert_query = """ INSERT INTO Versions
                                  (version,createdAt,updatedAt)
                                   VALUES (?, ?, ?)"""
        try:
            data_tuple = (self.new_db_version,
                          datetime.now(), datetime.now())
            self.cursor.execute(insert_query, data_tuple)
            self.sqliteConnection.commit()
        except Error as e:
            print("error with db version, error message - {}".format(e))
            sys.exit(1)

    def insert_promotions(self, path):
        default_path = os.path.join(path, 'default_ads')
        for dirname, dirnames, filenames in os.walk(default_path):
            for filename in filenames:
                image = image_to_blob(os.path.join(dirname, filename))
                insert_query = """ INSERT INTO Promotions (promotion,createdAt,updatedAt) VALUES (?, ?, ?)"""
                try:
                    data_tuple = (image, datetime.now(), datetime.now())
                    self.cursor.execute(insert_query, data_tuple)
                    self.sqliteConnection.commit()
                except Error as e:
                    print(
                        "error with {} promotion, error message - {}".format(filename, e))
                    sys.exit(1)
        self.insert_deals(path)

    def insert_deals(self, path):
        deals_ads_path = os.path.join(path, 'deals_ads')
        deals_csv_path = os.path.join(path, 'deals.csv')
        deals_ads_images = {}
        deals = {}
        for dirname, dirnames, filenames in os.walk(deals_ads_path):
            for filename in filenames:
                deals_ads_images[filename.split('.')[0]] = os.path.join(dirname, filename)
        try:
            with open(deals_csv_path, 'r', encoding='utf-8') as file:
                headers = next(file).split(',')
                headers = [x.split('\n')[0] for x in headers]
                deals_list = list(csv.reader(file))
                for line in deals_list:
                    ad_image = None
                    try:
                        ad_image = deals_ads_images[line[headers.index('deal_ID')]]
                    except:
                        pass
                    deals[line[headers.index('deal_ID')]] = {
                        'discount_type': int(line[headers.index('discount_type')]),
                        'params': [], 'items': [], 'ad_image': ad_image}
                    for i in range(1, 6):
                        deals[line[headers.index('deal_ID')]]['params'].append(
                            float(line[headers.index('parameter{}'.format(i))]) if len(
                                line[headers.index('parameter{}'.format(i))]) > 0 else None)
                    for i in range(1, 21):
                        deals[line[headers.index('deal_ID')]]['items'].append(
                            line[headers.index('product_code{}'.format(i))] if len(
                                line[headers.index('product_code{}'.format(i))]) > 0 else None)
                for key, value in deals.items():
                    insert_query = """ INSERT INTO Deals (dealID,discount_type,parameter1,parameter2,parameter3,
                    parameter4,parameter5,ad_image,createdAt,updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
                    image = image_to_blob(value['ad_image'])
                    try:
                        params = tuple(value['params'])
                        data_tuple = (key, value['discount_type']) + params + (image, datetime.now(), datetime.now())
                        self.cursor.execute(insert_query, data_tuple)
                        self.sqliteConnection.commit()
                    except Error as e:
                        print(
                            "error with {} deals, error message - {}".format(key, e))
                        sys.exit(1)
                    for item in value['items']:
                        if item is not None:
                            insert_item_query = """ INSERT INTO DealsProducts (product_code,dealID,createdAt,updatedAt)
                             VALUES (?, ?, ?, ?)"""
                            try:
                                data_tuple = (item, key, datetime.now(), datetime.now())
                                self.cursor.execute(insert_item_query, data_tuple)
                                self.sqliteConnection.commit()
                            except Error as e:
                                print(
                                    "error with {} DealsProducts, error message - {}".format(item, e))
                                sys.exit(1)

        except Exception as e:
            print("no deals for this retailer, {}".format(e))

    def insert_logos(self, path):
        for dirname, dirnames, filenames in os.walk(path):
            for filename in filenames:
                image = image_to_blob(os.path.join(dirname, filename))
                insert_query = """ INSERT INTO Logos (logo_name,logo,createdAt,updatedAt) VALUES (?, ?, ?, ?)"""
                try:
                    data_tuple = (filename.split(
                        '.')[0], image, datetime.now(), datetime.now())
                    self.cursor.execute(insert_query, data_tuple)
                    self.sqliteConnection.commit()
                except Error as e:
                    print("error with {} logo, error message - {}".format(filename, e))
                    sys.exit(1)

    def insert_instructions(self, path):
        for dirname, dirnames, filenames in os.walk(path):
            for filename in filenames:
                image = image_to_blob(os.path.join(dirname, filename))
                insert_query = """ INSERT INTO Instructions (gif_name,gif,createdAt,updatedAt) VALUES (?, ?, ?, ?)"""
                try:
                    data_tuple = (filename.split(
                        '.')[0], image, datetime.now(), datetime.now())
                    self.cursor.execute(insert_query, data_tuple)
                    self.sqliteConnection.commit()
                except Error as e:
                    print("error with {} logo, error message - {}".format(filename, e))
                    sys.exit(1)

    def insert_UPC(self, product_code, barcode):
        insert_query = """ INSERT INTO UPC
                                  (product_code,barcode,createdAt,updatedAt)
                                   VALUES (?, ?, ?, ?)"""
        try:
            data_tuple = (product_code, barcode,
                          datetime.now(), datetime.now())
            self.cursor.execute(insert_query, data_tuple)
            self.sqliteConnection.commit()
        except Error as e:
            print("error with UPC product {}, error message - {}".format(product_code, e))
            sys.exit(1)

    def get_data(self, table):
        query = " SELECT * FROM " + "'" + table + "'"
        self.cursor.execute(query)
        return self.cursor.fetchall()

    def validate_new_database(self):
        products = self.get_data('Products')
        products = [item[0] for item in products]
        upcs = self.get_data('UPC')
        upcs = [item[1] for item in upcs]
        return all(elem in upcs for elem in products)

    def add_fields_to_table(self, table_name, fields):
        for key, val in fields_dict.items():
            query = " ALTER TABLE {} ADD COLUMN {} {}".format(
                table_name, key, val)
            self.cursor.execute(query)
        self.sqliteConnection.commit()

    def update_db_version(self, username, userpassword, retailer):
        auth = requests.post(url='{}/auth/login'.format(END_POINT),
                             json={'email': username, 'password': userpassword})
        post = requests.post(url='{}/api/versions/update_version'.format(END_POINT),
                             cookies={'jwt': auth.cookies['jwt']},
                             data={'retailer': retailer, 'DB_version': self.new_db_version})
        print(post.text)


if __name__ == '__main__':
    retailer = sys.argv[1]
    opt = sys.argv[2]
    username = sys.argv[3]
    userpassword = sys.argv[4]
    if opt == 'update_table':
        table_name = sys.argv[5]
        fields = sys.argv[6:len(sys.argv)]
        fields_dict = {fields[i]: fields[i + 1] for i in range(0, len(fields), 2)}
        try:
            db = SqliteConnector()
            db.add_fields_to_table(table_name, fields)
            db.remove_last_version()
            db.generate_db_version()
            db.update_db_version(username, userpassword, retailer)
        except:
            sys.exit(1)
    elif opt == 'upload':
        try:
            db = SqliteConnector()
            db.generate_db_version()
            db.update_db_version(username, userpassword, retailer)
        except:
            sys.exit(1)
