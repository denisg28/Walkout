import xmltodict
from colorama import Fore
import csv
from datetime import datetime


class CatalogExtractor:
    def __init__(self, retailer):
        self.read_retailer_catalog = True
        self.ProductsSet = {}
        self.bakery_items = {
            'barcode': ['0000', '4061458115056', '4061458114967', '4061458125871', '4061458125666', '4061458115063', '4061458125598',
                        '4061458127141', '4061458125956', '4061458125635', '4061458125857', '4061458115100', '4061458115094',
                        '4061458125864',
                        '4061458126007', '4061458125895', '4061458126038', '4061458115070', '0000', '4061458114912', '4061458125727',
                        '4061458114936', '4061458114950', '4061458114981', '4061458125840', '4061458114943', '4061458115025',
                        '4061458125697',
                        '00000', '4061458125703', '4061458114929', '0000', '4061458127158', '4061458114998', '0000', '4061458115001',
                        '4061458125642'],
            'product_code': ['700558', '39186', '1268', '48548', '46588', '49884', '43802', '10643', '52307', '55090', '52244',
                             '44879', '39996', '702714', '47004', '12284', '54559', '703256', '702965', '49768', '54610', '46722', '10154',
                             '14374',
                             '39611', '48155', '38393', '708230', '706145', '48831', '49762', '45385', '10641', '14373', '33539', '36695',
                             '42194'],
            'plu_code': [363, 341, 302, 318, 390, 350, 368, 361, 343, 362, 325, 392, 352, 382, 316,
                         379, 333, 331, 306, 300, 355, 315, 363, 303, 345, 317, 321, 340, 337, 320, 312, 331,
                         378, 304, 307, 307, 383]}
        self.Upc = {}
        if retailer == 'ALDI_STORE':
            self.get_aldi_data()
        elif retailer == 'Tiv-Taam':
            self.get_tivtaam_data()

        # self.ProductsSet = json.dumps(self.ProductsSet, indent=4, ensure_ascii=False)
    def get_bakery(self):
        return self.bakery_items

    def get_tivtaam_data(self):
        try:
            with open('catalog.csv', 'r', encoding='utf-8') as file:
                print(Fore.BLUE + '######### PARSE CSV FILE ##########' + Fore.RESET)
                headers = next(file).split(',')
                headers = [x.split('\n')[0] for x in headers]
                db_list = list(csv.reader(file))
                for line in db_list:
                    self.ProductsSet[line[headers.index('barcode')]] = {
                        'name': line[headers.index('name')],
                        'plu': None,
                        'price': float(line[headers.index('price')]),
                        'product_code': line[headers.index('barcode')]
                    }
        except Exception as e:
            self.read_retailer_catalog = False
            print("no csv catalog file found", e)

    def get_aldi_data(self):
        try:
            with open('product.xml') as fd:
                print(Fore.BLUE + '######### PARSE XML FILE ##########' + Fore.RESET)
                xml = xmltodict.parse(fd.read())
        except FileNotFoundError:
            self.read_retailer_catalog = False
            print('no xml file found')
            return
        Products_table = xml['ProductSet']['Product']
        Retail_table = xml['ProductSet']['Retail']
        Upc_table = xml['ProductSet']['Upc']
        self.Upc = {}
        Products = {}
        Prices = {}
        for item in Upc_table:
            self.Upc[item['Upc']] = item['ProductCode']

        for item in Retail_table:
            if 'Retail' in item:
                try:
                    if Prices[item['ProductCode']]['date'] > datetime.strptime(Prices[item['ProductCode']]['ValidFrom'],
                                                                               '%Y.%m.%d %H:%M:%S'):
                        Prices[item['ProductCode']] = {
                            'date': datetime.strptime(item['ValidFrom'], '%Y.%m.%d %H:%M:%S'),
                            'price': float(item['Retail'])
                        }
                except KeyError:
                    Prices[item['ProductCode']] = {
                        'date': datetime.strptime(item['ValidFrom'], '%Y.%m.%d %H:%M:%S'),
                        'price': float(item['Retail'])}

        for item in Products_table:
            bakery = self.get_bakery()
            try:
                if str(item['ProductCode']) in bakery['product_code']:
                    PLU = item['PLU']
                else:
                    PLU = None
            except:
                PLU = None
            Products[item['ProductCode']] = {
                'name': item['Description'],
                'price': float(item['UnitPriceBase']) if 'UnitPriceBase' in item else -1,
                'PLU': PLU
            }

        for barcode, code in self.Upc.items():
            try:
                price = Prices[code]['price']
            except KeyError:
                price = Products[code]['price'] if Products[code]['price'] != -1 else 0
            self.ProductsSet[barcode] = {
                'product_code': code,
                'name': Products[code]['name'],
                'price': price,
                'plu': Products[code]['PLU']
            }

    def get_barcodes_of_product_code(self, product_code):
        res = []
        for key, value in self.Upc.items():
            if value == product_code:
                res.append(key)
        return res

    def is_catalog_readable(self):
        return self.read_retailer_catalog

    def get_catalog(self):
        return self.ProductsSet
