import pandas as pd
import json
import os

tiv_taam_csv = pd.read_csv('/home/walkout03/Desktop/tiv_taam_lists/tiv_taam_sorted.csv', dtype=object)
products_list = tiv_taam_csv['barcode'].to_list()
duplicates_list = 0
for i in range(len(products_list) - 1):
    if products_list[i] in products_list[i + 1:]:
        duplicates_list += 1
scripts_dir = '/home/walkout03/Desktop/scripts'
scripts = [
    'calibration_2020-11-29-13_41_57script.json',
    'calibration_2020-11-29-13_44_20script.json',
    'calibration_2020-11-29-13_58_48script.json',
]
# scripts = ['calibration_2020-11-29-14_29_40script.json',]
products_scanned = []
duplicates = 0
for script_path in scripts:
    script = json.load(open(os.path.join(scripts_dir, script_path)))
    for product in script:
        if product[1] in products_scanned:
            duplicates += 1
        if product[1] != '':
            products_scanned.append(product[1])
print("total in list: {} (with {} duplicates), total scanned: {} (with {} duplicates)".format(
    len(products_list), duplicates_list, len(products_scanned), duplicates))

# products scanned that are not in products list
missing_in_list = []
duplicates = []
for product_scanned in products_scanned:
    if product_scanned not in products_list:
        if product_scanned in missing_in_list:
            duplicates.append(product_scanned)
        missing_in_list.append(product_scanned)
print("scanned but not in the csv: {} (with {} duplicates)".format(len(missing_in_list), len(duplicates)))
print("duplicates: {}".format(duplicates))
print("missing in list:")
for missing_product in missing_in_list:
    print(missing_product)

# products in list that are not scanned
missing_in_store = []
duplicates = []
for product_in_list in products_list:
    if product_in_list not in products_scanned:
        if product_in_list in missing_in_store:
            duplicates.append(product_in_list)
        missing_in_store.append(product_in_list)
print("in the csv but not scanned: {} (with {} duplicates)".format(len(missing_in_store), len(duplicates)))
print("duplicates: {}".format(duplicates))
print("missing in list:")
for missing_product in missing_in_store:
    print(missing_product)