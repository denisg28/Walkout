import pandas as pd
import argparse
import tqdm

parser = argparse.ArgumentParser(description='find diff between old and new csvs')
parser.add_argument('--new-csv-path', help='load new csv path', type=str, default=None)
parser.add_argument('--old-csv-path', help='load old csv path', type=str, default=None)
parser.add_argument('--save-diff-path', help='save path of the new generated csv file', type=str, default=None)
args = parser.parse_args()

old_csv = pd.read_csv(args.old_csv_path, dtype=object)
new_csv = pd.read_csv(args.new_csv_path, dtype=object)

product_in_new_csv = new_csv['product_name'].to_list()
product_in_old_csv = old_csv['product_name'].to_list()

for product in tqdm.tqdm(product_in_new_csv):
    if product in product_in_old_csv:
        new_csv = new_csv[new_csv.product_name != product]

new_csv = new_csv.sort_values(by=['aisle', 'column', 'shelf'])
new_csv.to_csv(args.save_diff_path, index=False)
