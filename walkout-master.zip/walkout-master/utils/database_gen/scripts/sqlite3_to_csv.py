import sqlite3
import os
from tqdm import tqdm
import argparse
import pandas as pd

LOCAL_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../webapp/server/database.sqlite3')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='create csv from sqlite db')
    parser.add_argument('--sqlite-path', help='path to sqlite db', type=str, default=LOCAL_DB_PATH)
    parser.add_argument('--save-csv-path', help='save path of the new generated csv file', type=str, default=None)
    parser.add_argument('--include-prod-wo-image', help='include products with no image in the db', action='store_true')
    args = parser.parse_args()

    assert args.save_csv_path is not None
    sqliteConnection = sqlite3.connect(args.sqlite_path)
    sqliteConnection.text_factory = str
    cursor = sqliteConnection.cursor()
    cursor.execute("PRAGMA table_info (Products)")
    prod_db_map = cursor.fetchall()
    prod_info_map = dict()
    for info in prod_db_map:
        prod_info_map[info[1]] = info[0]

    sqliteConnection = sqlite3.connect(args.sqlite_path)
    sqliteConnection.text_factory = str
    cursor = sqliteConnection.cursor()
    # Get products
    cursor.execute("SELECT * FROM Products")
    rows = cursor.fetchall()
    assert rows is not None
    product_info = dict()
    barcode2products = dict()
    product_codes = [r[prod_info_map['product_code']] for r in rows]
    # Get barcodes
    print("Converting sqlite3 db to csv...")
    for prod_idx, prod_code in enumerate(tqdm(product_codes)):
        # Get product info
        cursor.execute("SELECT barcode FROM UPC WHERE product_code=?", (prod_code,))
        product_barcode = cursor.fetchone()[0].replace('\n', '')
        english_name = rows[prod_idx][prod_info_map['en_name']]
        local_name = rows[prod_idx][prod_info_map['local_name']]
        price = rows[prod_idx][prod_info_map['price']]
        has_image = rows[prod_idx][prod_info_map['image']] is not None
        aisle = rows[prod_idx][prod_info_map['aisle']]
        column = rows[prod_idx][prod_info_map['column']]
        shelf = rows[prod_idx][prod_info_map['shelf']]

        product_info[prod_code] = dict(product_name=prod_code,
                                       barcode=product_barcode,
                                       english_name=english_name,
                                       local_name=local_name,
                                       price=price,
                                       has_image=has_image,
                                       aisle=aisle,
                                       column=column,
                                       shelf=shelf)
        if product_barcode not in barcode2products:
            barcode2products[product_barcode] = [prod_code]
        else:
            barcode2products[product_barcode].append(prod_code)

    # Extra attributes
    attribute_dict = dict()
    # TODO - Add size & has_similar product info
    att_keys = ['product_name']
    num_products = len(product_info)
    for attribute in att_keys:
        # Collect attribute value per product
        attribute_dict[attribute] = dict()
        for _, val in product_info.items():
            prod_name = val['product_name']
            att_val = val[attribute]
            attribute_dict[attribute][prod_name] = att_val

    print('Initialized Product Catalog with %d products' % num_products)

    with open(args.save_csv_path, 'w') as f:
        valid_keys = ('product_name', 'barcode', 'english_name', 'local_name', 'price', 'has_image', 'aisle',
                      'column', 'shelf')
        f.write("%s,%s,%s,%s,%s,%s,%s,%s,%s\n" % valid_keys)

        for _, values in tqdm(product_info.items()):
            if not values['has_image'] and not args.include_prod_wo_image:
                continue
            out_row = tuple([str(values[vk]).replace(',', ' ').replace('\t', '') for vk in valid_keys])
            f.write("%s,%s,%s,%s,%s,%s,%s,%s,%s\n" % out_row)
    products_list = pd.read_csv(args.save_csv_path, dtype='object')
    products_list = products_list.sort_values(by=['aisle', 'column', 'shelf'])
    products_list.to_csv(args.save_csv_path, index=False)
