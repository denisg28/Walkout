import requests
import shutil
import os
from threading import Timer
from colorama import Fore
import CatalogExtractor
import SqliteConnector
import MementoDBConnector
import sys
from pathlib import Path
import time
import csv

ALIVE_COUNT = 0


def alive_check():
    global ALIVE_COUNT
    print(Fore.GREEN + 'Alive Check #{}'.format(ALIVE_COUNT))
    ALIVE_COUNT += 1
    t = Timer(30.0, alive_check)
    t.daemon = True
    t.start()


def get_image_for_item(url, product_code):
    try:
        item_image = requests.get(url, stream=True)
        if item_image.status_code == 200:
            with open('{}.jpg'.format(product_code), 'wb') as f:
                item_image.raw.decode_content = True
                shutil.copyfileobj(item_image.raw, f)
            return os.getcwd() + '/{}.jpg'.format(product_code)
        else:
            return None
    except:
        return None


def create_images_dic(images_path):
    images = {}
    for dirname, dirnames, filenames in os.walk(images_path):
        for filename in filenames:
            if (filename.endswith('jpg') or filename.endswith('png')):
                images[filename.split('.')[0]] = '{}/{}'.format(images_path, filename)
    return images


if __name__ == '__main__':
    db_for = sys.argv[1]
    logos_path = sys.argv[2]
    promotion_path = sys.argv[3]
    instructions_path = sys.argv[4]
    retailer = sys.argv[5]
    images_path = sys.argv[6]
    local_images = []
    images = create_images_dic(images_path)
    start_time = time.time()
    alive_check()
    catalog = CatalogExtractor.CatalogExtractor(db_for)
    sq = SqliteConnector.SqliteConnector()
    memento = MementoDBConnector.MementoDBConnector(db_for)
    data_to_insert = memento.get_data_to_insert()
    memento_and_catalog_items = 0
    memento_items = 0
    image_not_found = []
    item_from_catalog_only = []
    data = catalog.get_catalog() if catalog.is_catalog_readable() else None
    if data is not None:
        print(Fore.BLUE + '######### CREATE DATABASE FROM COMBINED CATALOG AND MEMENTO  ##########' + Fore.RESET)
        for key, value in data.items():
            multiple_products_code = catalog.get_barcodes_of_product_code(
                value['product_code'])
            if key in data_to_insert:
                for item in data_to_insert[key]:
                    memento_and_catalog_items += 1
                    # Custom settings just for ALDI_STORE
                    if retailer == 'Aldi' and item['id'] in images:
                        image = images[item['id']]
                        local_images.append(item['id'])
                    else:
                        if item['barcode'] in images:
                            image = images[item['barcode']]
                            local_images.append(item['barcode'])
                        else:
                            image = get_image_for_item(item['front image'][0], item['id']) if 'front image' in item else None
                    sq.insert_products(item['id'], image, item['free name'], '', item['aisle'], item['column'],
                                       item['shelf'], value['price'], value['plu'], item['createdAt'], item['updatedAt'])
                    if len(multiple_products_code) == 0:
                        sq.insert_UPC(item['id'], item['barcode'])
                    else:
                        for product in multiple_products_code:
                            sq.insert_UPC(item['id'], product)
                    try:
                        os.unlink(image)
                    except:
                        image_not_found.append(key)
            elif "0" + key in data_to_insert:
                for item in data_to_insert["0" + key]:
                    memento_and_catalog_items += 1
                    # Custom settings just for ALDI_STORE
                    if retailer == 'Aldi' and item['id'] in images:
                        image = images[item['id']]
                        local_images.append(item['id'])
                    else:
                        if item['barcode'] in images:
                            image = images[item['barcode']]
                            local_images.append(item['barcode'])
                        else:
                            image = get_image_for_item(
                                    item['front image'][0], item['id']) if 'front image' in item else None
                    sq.insert_products(item['id'], image, item['free name'], '',
                                       item['aisle'], item['column'],
                                       item['shelf'], value['price'], value['plu'], item['createdAt'], item['updatedAt'])
                    if len(multiple_products_code) == 0:
                        sq.insert_UPC(item['id'], item['barcode'])
                    else:
                        for product in multiple_products_code:
                            sq.insert_UPC(item['id'], product)
                    try:
                        os.unlink(image)
                    except:
                        image_not_found.append("0" + key)
            else:
                item_from_catalog_only.append(
                    {'id': key, 'name': value['name'], 'price': value['price'], 'plu': value['plu']})
        print(Fore.BLUE + '######### CHECK CATALOG WITHOUT MEMENTO ##########' + Fore.RESET)
        for item in item_from_catalog_only:
            if not sq.check_if_upc_exist(item['id']):
                image = None
                if item['id'] in images:
                    image = images[item['id']]
                    local_images.append(item['id'])
                sq.insert_products(
                    item['id'], image, item['name'], '', 0, 0, 0, item['price'], item['plu'])
                sq.insert_UPC(item['id'], item['id'])
    else:
        print(Fore.BLUE + '######### CREATE DATABASE FROM MEMENTO ONLY  ##########' + Fore.RESET)
    for key, value in data_to_insert.items():
        for item in value:
            if not sq.check_if_product_code_exist(item['id']):
                memento_items += 1
                bakery = catalog.get_bakery()
                # Custom settings just for ALDI_STORE: start
                plu_code = None
                if retailer == 'Aldi':
                    # Add plu_code just for ALDI bakery
                    if str(item['product code']) in bakery['product_code']:
                        index = bakery['product_code'].index(item['product code'])
                        plu_code = bakery['plu_code'][index]
                    # Add new .png img
                    if item['id'] in images:
                        image = images[item['id']]
                        local_images.append(item['id'])
                    else:
                        image = get_image_for_item(
                                item['front image'][0], item['id']) if 'front image' in item else None
                else:
                    if item['barcode'] in images:
                        image = images[item['barcode']]
                        local_images.append(item['barcode'])
                    else:
                        image = get_image_for_item(
                            image, item['id']) if 'front image' in item else None
                sq.insert_products(item['id'], image, item['free name'], '',
                                    item['aisle'], item['column'], item['shelf'], item['price'], plu_code,
                                    item['createdAt'], item['updatedAt'])
                sq.insert_UPC(item['id'], item['barcode'])
                try:
                    os.unlink(image)
                except:
                    image_not_found.append(key)
    sq.insert_promotions(promotion_path)
    sq.insert_logos(logos_path)
    sq.insert_instructions(instructions_path)
    valid = sq.validate_new_database()

    print(Fore.GREEN + 'Database Valid!' if valid else Fore.RED + 'Database Not Valid!')
    sq.close()
    print(Fore.YELLOW + 'Item combined: {}, Item from memento only: {}, Item from catalog only: {}, '
                        'All items inserted: {}, local images: {}'.format(memento_and_catalog_items, memento_items, len(item_from_catalog_only),
                                                        memento_and_catalog_items + memento_items + len(item_from_catalog_only),len(local_images)))
    print(Fore.MAGENTA + "Database size: {} MB".format(
        '{0:.2f}'.format(float(Path('database.sqlite3').stat().st_size / (1024 * 1024))), '.2f'))
    if (len(image_not_found)) > 0:
        print(Fore.RED + "{} Image(s) not found".format(len(image_not_found)))
        print("\n".join(image_not_found))
    print(Fore.MAGENTA +
          "--- Total Time {} ---".format(time.strftime('%H:%M:%S', time.gmtime(time.time() - start_time))))
