import sqlite3
from sqlite3 import Error
import os
import sys
import SqliteConnector
import csv
from colorama import Fore
import sys
import requests
import shutil
import pathlib


def get_image_for_item(url, product_code, images_path):
    suffix = pathlib.Path(url).suffix
    image_name = '{}{}'.format(product_code, suffix)
    file = pathlib.Path('{}/{}'.format(images_path, image_name))
    if file.exists():
        print('FILE EXISTS {}'.format(product_code))
        return True
    try:
        item_image = requests.get(url, stream=True)
        if item_image.status_code == 200:
            with open(image_name, 'wb') as f:
                item_image.raw.decode_content = True
                shutil.copyfileobj(item_image.raw, f)
                file_path = os.getcwd() + '/{}'.format(image_name)
                shutil.move(file_path, images_path + '/{}'.format(image_name))
        else:
            return None
    except:
        return None


class CsvParser:
    def __init__(self, csv_path, promotion_path, logos_path, images_path, instructions_path):
        self.db = {}
        self.sq = SqliteConnector.SqliteConnector()
        self.promotion_path = promotion_path
        self.logos_path = logos_path
        self.images_path = images_path
        self.instructions_path = instructions_path
        try:
            with open(csv_path, 'r', encoding='utf-8') as file:
                headers = next(file).split(',')
                headers = [x.split('\n')[0] for x in headers]
                next(file)
                db_list = list(csv.reader(file))
                try:
                    SKU = headers.index('sku')
                except ValueError:
                    SKU = None
                try:
                    PLU = headers.index('plu')
                except ValueError:
                    PLU = None
                try:
                    URL = headers.index('url')
                except ValueError:
                    URL = None

                for line in db_list:
                    self.db[line[headers.index('product_name')]] = {
                        'product_code': line[headers.index('product_name')],
                        'en_name': line[headers.index('english_name')],
                        'local_name': line[headers.index('hebrew_name')],
                        'price': float(line[headers.index('price')]),
                        'image_url': None if URL is None else line[URL],
                        'sku': None if SKU is None else line[SKU],
                        'plu': None if PLU is None else line[PLU]}
        except Exception as e:
            print("csv error - {}".format(e))
            sys.exit(1)
        self.download_images()

    def download_images(self):
        for key, value in self.db.items():
            image = value['image_url']
            if image is not None and len(image) > 0:
                get_image_for_item(image, key, self.images_path)

    def insert_products(self, product_code, image):
        item = self.db[product_code]
        sku = item['sku']
        plu = item['plu'] if item['plu'] is not None and len(item['plu']) > 0 else None
        self.sq.insert_products(product_code if sku is None or len(sku) == 0 else sku, image,
                                item['en_name'], item['local_name'], 0, 0, 0, item['price'], plu)

    def insert_UPC(self, product_code):
        sku = self.db[product_code]['sku']
        self.sq.insert_UPC(product_code if sku is None or len(sku) == 0 else sku,
                           product_code.split('_')[0])

    def check_if_product_in_csv(self, product_code):
        try:
            item = self.db[product_code]
            return True
        except:
            return False

    def insert_promotions_and_logos_and_instructions(self):
        self.sq.insert_promotions(self.promotion_path)
        self.sq.insert_logos(self.logos_path)
        self.sq.insert_instructions(self.instructions_path)

    def validate_new_database(self):
        return self.sq.validate_new_database()

    def get_data(self):
        return self.db


if __name__ == '__main__':
    images_path = sys.argv[1]
    pathlib.Path(images_path).mkdir(parents=True, exist_ok=True)
    csv_path = 'catalog.csv'
    logos_path = sys.argv[2]
    promotion_path = sys.argv[3]
    instructions_path = sys.argv[4]
    csv_parser = CsvParser(csv_path, promotion_path, logos_path, images_path, instructions_path)
    data = csv_parser.get_data()
    images = {}
    for dirname, dirnames, filenames in os.walk(images_path):
        for filename in filenames:
            if len(filename.split('.')[0]) > 0:
                images[filename.split('.')[0]] = os.path.join(dirname, filename)

    for key, val in data.items():
        try:
            item_image = images[key]
        except KeyError:
            item_image = None
        csv_parser.insert_products(key, item_image)
        csv_parser.insert_UPC(key)

    csv_parser.insert_promotions_and_logos_and_instructions()
    valid = csv_parser.validate_new_database()
    print(Fore.GREEN + 'Database Valid!' if valid else Fore.RED + 'Database Not Valid!')
