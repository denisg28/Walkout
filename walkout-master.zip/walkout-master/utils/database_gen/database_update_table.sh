#!/bin/bash

RED='\033[0;31m'
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

pushd $DIR
if [ "$#" -lt 5 ]; then
    printf "${RED}Missing argument, Usage: <user email> <user pasword> <table name> <field name i.e image> <field definition i.e 'VARCHAR(255)'>\n${NC}"
    exit 1
fi

printf "${BLUE}############### Download Database from Aldi Retailer #############\n${NC}"
aws s3 cp s3://walkout-main/RND/DB/ALDI_STORE/database.sqlite3 database.sqlite3
python3 SqliteConnector.py "Aldi" "update_table" "$@"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with create database can't continue, exit now... ###########\n${NC}"
    rm database.sqlite3
    exit $exit_status
fi
aws s3 cp database.sqlite3 s3://walkout-main/RND/DB/ALDI_STORE/database.sqlite3
rm -rf database.sqlite3

printf "${BLUE}############### Download Database from Asda Retailer #############\n${NC}"
aws s3 cp s3://walkout-main/RND/DB/asda_poc/database.sqlite3 database.sqlite3
python3 SqliteConnector.py "Asda" "update_table" "$@"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with create database can't continue, exit now... ###########\n${NC}"
    rm database.sqlite3
    exit $exit_status
fi
aws s3 cp database.sqlite3 s3://walkout-main/RND/DB/asda_poc/database.sqlite3
rm -rf database.sqlite3

printf "${BLUE}############### Download Database from Jumbo Retailer #############\n${NC}"
aws s3 cp s3://walkout-main/RND/DB/jumbo/database.sqlite3 database.sqlite3
python3 SqliteConnector.py "Jumbo" "update_table" "$@"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with create database can't continue, exit now... ###########\n${NC}"
    rm database.sqlite3
    exit $exit_status
fi
aws s3 cp database.sqlite3 s3://walkout-main/RND/DB/jumbo/database.sqlite3
rm -rf database.sqlite3

printf "${BLUE}############### Download Database from Bunting Retailer #############\n${NC}"
aws s3 cp s3://walkout-main/RND/DB/bunting/database.sqlite3 database.sqlite3
python3 SqliteConnector.py "Bunting" "update_table" "$@"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with create database can't continue, exit now... ###########\n${NC}"
    rm database.sqlite3
    exit $exit_status
fi
aws s3 cp database.sqlite3 s3://walkout-main/RND/DB/bunting/database.sqlite3
rm -rf database.sqlite3

printf "${BLUE}############### Download Database from Walkout Retailer #############\n${NC}"
aws s3 cp s3://walkout-main/RND/DB/demo_latest/database.sqlite3 database.sqlite3
python3 SqliteConnector.py "Walkout" "update_table" "$@"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with create database can't continue, exit now... ###########\n${NC}"
    rm database.sqlite3
    exit $exit_status
fi
aws s3 cp database.sqlite3 s3://walkout-main/RND/DB/demo_latest/database.sqlite3
rm -rf database.sqlite3

printf "${BLUE}############### Download Database from Tivtaam Retailer #############\n${NC}"
aws s3 cp s3://walkout-main/RND/DB/Tiv-Taam/database.sqlite3 database.sqlite3
python3 SqliteConnector.py "Tivtaam" "update_table" "$@"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with create database can't continue, exit now... ###########\n${NC}"
    rm database.sqlite3
    exit $exit_status
fi
aws s3 cp database.sqlite3 s3://walkout-main/RND/DB/Tiv-Taam/database.sqlite3
rm -rf database.sqlite3

printf "${GREEN}############### DONE! #############\n${NC}"