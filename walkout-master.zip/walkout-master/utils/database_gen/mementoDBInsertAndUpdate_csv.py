import os
import sys
import csv
import sys
import requests
import MementoDBConnector

BARCODE = 0
PRICE = 1
HAS_IMAGE = 2
NAME = 3


def image_to_blob(imagefile):
    if imagefile is None:
        return None
    with open(imagefile, "rb") as image:
        return image.read()


class CsvParser:
    def __init__(self, csv_path, images_path):
        self.db = {}
        self.images = {}
        self.gen_images(images_path)
        try:
            with open(csv_path, 'r', encoding='utf-8') as file:
                next(file)
                db_list = list(csv.reader(file))
                for line in db_list:
                    try:
                        price = float(line[PRICE])
                    except:
                        price = 0
                    has_image = line[HAS_IMAGE]
                    image = None
                    if has_image.lower() == 'true' and line[BARCODE] in self.images:
                        image = self.images[line[BARCODE]]
                    self.db[line[BARCODE]] = {
                        'barcode': line[BARCODE], 'name': None if line[NAME].strip() == 'N/A' else line[NAME],
                        'price': price, 'image': image}
        except Exception as e:
            print("csv error - {}".format(e))
            sys.exit(1)

    def get_db(self):
        return self.db

    def gen_images(self, images_path):
        for dirname, dirnames, filenames in os.walk(images_path):
            for filename in filenames:
                if (filename.endswith('png') or filename.endswith('jpg')):
                    self.images[filename.split(
                        '.')[0]] = image_to_blob(os.path.join(dirname, filename))


if __name__ == '__main__':
    images_path = sys.argv[1]
    csv_path = sys.argv[2]
    retailer = sys.argv[3]
    csv_parser = CsvParser(csv_path, images_path)
    memento = MementoDBConnector.MementoDBConnector(retailer)
    memento_data = memento.get_data_to_insert()
    data_to_insert = csv_parser.get_db()
    for item in data_to_insert:
        if item not in memento_data:
            memento.post_data(data_to_insert[item])
    print('DONE', len(data_to_insert))
