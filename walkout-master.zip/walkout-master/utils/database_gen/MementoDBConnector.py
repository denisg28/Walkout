import requests
import json
import sys
from colorama import Fore
import time
from threading import Timer

ALIVE_COUNT = 0


def alive_check():
    global ALIVE_COUNT
    print(Fore.GREEN + 'Alive Check #{}'.format(ALIVE_COUNT))
    ALIVE_COUNT += 1
    t = Timer(10.0, alive_check)
    t.daemon = True
    t.start()


class MementoDBConnector:
    def __init__(self, db):
        DBS = ['ALDI_STORE', 'Tiv-Taam', 'playground']
        try:
            self.ID = DBS.index(db)
            print(Fore.BLUE + '######### CONNECT TO MEMENTO AND RETRIEVE DATA ##########' + Fore.RESET)
        except ValueError:
            print(Fore.RED + '########### There is no {} in memento db ###########'.format(db) + Fore.RESET)
            sys.exit(1)

        self.LIBRARY = ['R82MmUr27', 'tkXnHxOM4', 'ge7aBOmtY']
        self.TOKEN = ['DVGmV23OZWud6Ijapq9iwJfHG7Jm6q', 'NsFdnAwD62cMCdLPRb6QHEAyrRjMbB',
                      'MjjJsiLXkpdjxoICy4ZfIxYZC9lx1w']
        self.barcode_place = None
        self.entries_ = []
        self.data_to_insert = {}
        self.data_for_cvat = {}
        self.data_types = {}
        self.get_library()
        self.get_entries_of_library('')

    def get_library(self):
        library_request = requests.get(
            'https://api.mementodatabase.com/v1/libraries/{}?token={}'.format(self.LIBRARY[self.ID],
                                                                              self.TOKEN[self.ID]))
        if library_request.status_code == 200:
            data = json.loads(library_request.text)
            fields = data['fields']
            for field in fields:
                self.data_types[field['id']] = field['name']

    def get_entries_of_library(self, token):
        library_request = requests.get(
            'https://api.mementodatabase.com/v1/libraries/{}/entries?token={}&fields=all&pageToken={}'.format(
                self.LIBRARY[self.ID], self.TOKEN[self.ID], token))
        if library_request.status_code == 200:
            data = json.loads(library_request.text)
            entries = data['entries']
            pageToken = None
            try:
                pageToken = data['nextPageToken']
            except KeyError:
                pass

            for entry in entries:
                barcode = self.get_barcode(entry['fields'])
                if entry['status'] == 'active':
                    if self.data_to_insert.get(barcode) is not None:
                        self.data_to_insert[barcode].append(
                            {'id': entry['id'], 'createdAt': entry['createdTime'], 'updatedAt': entry['modifiedTime']})
                        for field in entry['fields']:
                            self.data_to_insert[barcode][len(self.data_to_insert[barcode]) - 1][
                                self.data_types[field['id']]] = field['value']
                    else:
                        self.data_to_insert[barcode] = [
                            {'id': entry['id'], 'createdAt': entry['createdTime'], 'updatedAt': entry['modifiedTime']}]
                        for field in entry['fields']:
                            self.data_to_insert[barcode][0][self.data_types[field['id']]] = field['value']
                    self.data_for_cvat[entry['id']] = {}
                    for field in entry['fields']:
                        self.data_for_cvat[entry['id']][self.data_types[field['id']]] = field['value']

            if pageToken is not None:
                self.get_entries_of_library(pageToken)
        elif library_request.status_code == 403:
            time.sleep(10)
            self.get_entries_of_library(token)

    def post_data(self, data):
        headers = {
            'Content-Type': 'application/json'
        }
        values = {
            "fields": [{"id": 1, "value": data['name']}, {"id": 2, "value": "Tiv Taam Caesarea"}, {"id": 3, "value": 0},
                       {"id": 4, "value": data['barcode']}, {"id": 5, "value": ''}, {"id": 6, "value": ''},
                       {"id": 9, "value": 0}, {"id": 8, "value": 0}, {"id": 10, "value": 0},
                       {"id": 11, "value": data['price']}]}
        body = '{}'.format(values)
        post_request = requests.post('https://api.mementodatabase.com/v1/libraries/{}/entries?token={}'.format(
            self.LIBRARY[self.ID], self.TOKEN[self.ID]), data=body.encode('utf-8'), headers=headers)
        if post_request.status_code == 201:
            if data['image'] is not None:
                request_data = json.loads(post_request.text)
                # self.post_image_data(request_data['id'], data['image'])
        elif post_request.status_code == 403:
            time.sleep(10)
            self.post_data(data)

    def post_image_data(self, id, image):
        images = {5: image, 6: image}
        headers = {
            'Content-Type': 'multipart/form-data; boundary=---BOUNDARY'
        }
        for key, value in images.items():
            values = """
            -----BOUNDARY
            Content-Disposition: form-data; name="image[file]"; filename="image.jpg"
            Content-Type: image/jpeg
            {}
            -----BOUNDARY""".format(open(value, 'rb').read())
            post_request = requests.post(
                'https://api.mementodatabase.com/v1/libraries/{}/entries/{}/files/{}?token={}'.format(
                    self.LIBRARY[self.ID], id, key, self.TOKEN[self.ID]), data=values, headers=headers)
            print(post_request.status_code)

    def get_barcode(self, entry):
        if self.barcode_place is None:
            key_list = list(self.data_types.keys())
            val_list = list(self.data_types.values())
            self.barcode_place = key_list[val_list.index('barcode')]
            for i in entry:
                if i['id'] == self.barcode_place:
                    return i['value']
        else:
            for i in entry:
                if i['id'] == self.barcode_place:
                    return i['value']

    def get_data_to_insert(self):
        return self.data_to_insert

    def get_data_for_cvat(self):
        return self.data_for_cvat


if __name__ == '__main__':
    db_for = sys.argv[1]
    alive_check()
    memento = MementoDBConnector(db_for)
    data = {}
    data_length = 0
    memento_data = memento.get_data_to_insert()
    for item in memento_data:
        data_length += len(memento_data[item])
    data['metadata'] = {'items': data_length}
    data['items'] = memento_data
    with open('{}.json'.format(db_for), 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
