#!/bin/bash

RED='\033[0;31m'
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

pushd $DIR
if [ "$#" -ne 4 ]; then
    printf "${RED}Missing argument, Usage: <Retailer: Aldi | Asda.. > <Retailer DB path: ALDI_STORE | demo_latest ...> <user email> <user pasword>\n${NC}"
    exit 1
fi

python3 SqliteConnector.py "$1" "upload" "$3" "$4"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with update database version can't continue, exit now... ###########\n${NC}"
    exit $exit_status
fi

printf "${BLUE}############### Upload Database to "$1" Retailer in "$2" path #############\n${NC}"
aws s3 cp database.sqlite3 s3://walkout-main/RND/DB/$2/database.sqlite3
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with upload database can't continue, exit now... ###########\n${NC}"
    exit $exit_status
fi

rm -rf database.sqlite3

printf "${GREEN}############### DONE! #############\n${NC}"