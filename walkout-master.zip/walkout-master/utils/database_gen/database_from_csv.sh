#!/bin/bash

RED='\033[0;31m'
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

source $HOME/py3_env/bin/activate
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

pushd $DIR
if [ "$#" -ne 2 ]; then
    printf "${RED}Missing argument, Usage: <Retailer name i.e Aldi> <s3 DB/images folder i.e demo170>\n${NC}"
    exit 1
fi

retailer_=$1
IMAGES=$HOME/tmp_images_"$2"
if ! [ -d "$IMAGES" ]; then
    mkdir $IMAGES
fi
pushd $IMAGES
printf "${BLUE}############### Sync S3 for $2 Images #############\n${NC}"
aws s3 sync s3://walkout-main/RND/images/$2/ .
popd
IFS='_' read -r -a retailer_name <<< "$2"
RETAILER=$HOME/tmp_retailer_"${retailer_name[0]}"
if ! [ -d "$RETAILER" ]; then
    mkdir $RETAILER
fi
pushd $RETAILER
printf "${BLUE}############### Download Logos from ${retailer_name[0]} Retailer #############\n${NC}"
aws s3 sync s3://walkout-main/RND/retailers/"${retailer_name[0]}"/ .
popd
PROMOTIONS=$HOME/tmp_promotions_"$2"
if ! [ -d "$PROMOTIONS" ]; then
    mkdir $PROMOTIONS
fi
pushd $PROMOTIONS
printf "${BLUE}############### Download Promotions from $2 Promotions #############\n${NC}"
aws s3 sync s3://walkout-main/RND/RETAILERS/$1/promotions/ .
popd

INSTRUCTIONS=$HOME/tmp_instructions_"$2"
if ! [ -d "$INSTRUCTIONS" ]; then
    mkdir $INSTRUCTIONS
fi
pushd $INSTRUCTIONS
printf "${BLUE}############### Download Instructions #############\n${NC}"
aws s3 sync s3://walkout-main/RND/instructions/ .
popd

printf "${BLUE}########### Download $2 Catalog ###########\n${NC}"
aws s3 sync s3://walkout-main/RND/catalog/$2/ .

cd demo
cp database.sqlite3 ../
cd ../
printf "${BLUE}############### Create Database for $2 ############\n${NC}"
python3 database_creator.py "$IMAGES" "$RETAILER" "$PROMOTIONS" "$INSTRUCTIONS"
exit_status=$?
if [ $exit_status -eq 1 ]; then
    printf "${RED}########### there was an error with create database can't continue, exit now... ###########\n${NC}"
    rm database.sqlite3
    exit $exit_status
fi

printf "${BLUE}########### upload new images to $2 folder ###########\n${NC}"
pushd $IMAGES
aws s3 sync . s3://walkout-main/RND/images/$2/
popd

printf "${BLUE}########### remove $2 tmp folders ###########\n${NC}"
rm -r $IMAGES
rm -r $RETAILER
rm -r $PROMOTIONS
rm -r $INSTRUCTIONS
rm -r *.csv
printf "${GREEN}############### DONE! #############\n${NC}"