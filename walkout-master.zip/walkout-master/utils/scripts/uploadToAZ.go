package main

import (
	"context"
	"fmt"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/Azure/azure-storage-queue-go/azqueue"

	"github.com/Azure/azure-storage-blob-go/azblob"
)

var (
	mediaType string
	requestID string
)

func compareSlToStr(a string, b []string) bool {
	for idx, val := range a {
		if string(val) != b[idx] {
			return false
		}
	}

	return true
}

func account4URL(account string) string {
        if "walkout" != account {
		return "walkout4"+account
	} else {
		return account
	}

}

func notifyQueue(account string, queue string, sasKey string, moviePackage string, numFiles int, fileType string) {
	URL, _ := url.Parse(fmt.Sprintf("https://%s.queue.core.windows.net/%s/messages?%s", account4URL(account), queue, sasKey))

	pLine := azqueue.NewPipeline(azqueue.NewAnonymousCredential(), azqueue.PipelineOptions{})

	messagesURL := azqueue.NewMessagesURL(*URL, pLine)

	messageString := fmt.Sprintf("{\n  \"name\": \"%s\",\n  \"waitingFor\":\"HNDL\",\n  \"numItems\":%d,\n  \"type\": \"%s\"\n}", moviePackage, numFiles, fileType)

	_, err := messagesURL.Enqueue(context.Background(), messageString, 0, 0)

	if err != nil {
		fmt.Println(fmt.Errorf("couldn't notify the storage queue, please check problem"))
		os.Exit(1)
	}

}

func main() {
	if 8 != len(os.Args) {
		fmt.Println(fmt.Errorf("Useage: uploadToAZ <basedir> <local file> <account> <container> <remote path> <SAS key> <should notify>"))
		os.Exit(1)
	}

	// Process args
	args := os.Args[1:]
	baseDir := args[0]
	fileName := args[1]
	account := args[2]
	container := args[3]
	remotePath := args[4]
	sasKey := args[5]
	shouldNotify, err := strconv.ParseBool(args[6])
	if err != nil {
		fmt.Println(fmt.Errorf("couldn't parse boolean for notification, assuming no notification is needed"))
	}

	//Strings manipulations
	//fileSlice := strings.Split(localFile, "/")
	//fileName := fileSlice[len(fileSlice)-1]
	localFile := baseDir+"/"+fileName
	uploadPath := remotePath + fileName
	typeSlice := strings.Split(fileName, ".")
	fileType := typeSlice[len(typeSlice)-1]
	// moviePostfix := packageSlice[len(packageSlice)-1]
	var moviePackage string

	if 0 == strings.Compare("avi", fileType) {
		mediaType = "video/avi"
		packageSlice := strings.Split(uploadPath, "_")
		moviePackage = strings.Join(packageSlice[:len(packageSlice)-1], "_")
	} else {
		mediaType = "text/" + fileType
		packageSlice := strings.Split(uploadPath, ".")
		moviePackage = strings.Join(packageSlice[:len(packageSlice)-1], ".")
	}

	// build objects for uploading data
	URL, _ := url.Parse(fmt.Sprintf("https://%s.blob.core.windows.net/%s/?%s", account4URL(account), container, sasKey))

	timeout, err := time.ParseDuration("1024m") // Azure documentation recommends 60 seconds per MB so this should give us up to 1 GB
	if err != nil {
		timeout = 0
	}
	pLine := azblob.NewPipeline(azblob.NewAnonymousCredential(), azblob.PipelineOptions{Retry: azblob.RetryOptions{MaxTries: 1, TryTimeout: timeout}})

	containerURL := azblob.NewContainerURL(*URL, pLine)
	blobURL := containerURL.NewBlockBlobURL(uploadPath)
	ctx := context.Background()
	file, err := os.Open(localFile)
	if err != nil {
		fmt.Println(fmt.Errorf("couldn't open file to upload, maybe it doesn't exist"))
		os.Exit(1)
	}
	fileInfo, err := file.Stat()
	if err != nil {
		fmt.Println(fmt.Errorf("couldn't open file to upload, maybe it doesn't exist"))
		os.Exit(1)
	}

	// Upload file to Azure storage
	// if size is less than 34MB we can use this method:
	// {
	// response, err := blobURL.Upload(ctx, pipeline.NewRequestBodyProgress(file, func(bytesTransferred int64) {
	// 	fmt.Printf("Uploaded %d / %d bytes.		%d%%	\r", bytesTransferred, fileInfo.Size(), ((bytesTransferred * 100) / fileInfo.Size()))
	// }), azblob.BlobHTTPHeaders{ContentType: mediaType}, azblob.Metadata{}, azblob.BlobAccessConditions{}, azblob.DefaultAccessTier, nil, azblob.ClientProvidedKeyOptions{})
	// }

	// else we should use this:
	response, err := azblob.UploadFileToBlockBlob(ctx, file, blobURL, azblob.UploadToBlockBlobOptions{BlockSize: azblob.BlobDefaultDownloadBlockSize, Progress: func(bytesTransferred int64) {
		fmt.Printf("Uploaded %d / %d bytes.		%d%%	\r", bytesTransferred, fileInfo.Size(), ((bytesTransferred * 100) / fileInfo.Size()))
	}, BlobHTTPHeaders: azblob.BlobHTTPHeaders{ContentType: mediaType}, Metadata: azblob.Metadata{}, AccessConditions: azblob.BlobAccessConditions{}, BlobAccessTier: azblob.DefaultAccessTier, BlobTagsMap: nil, ClientProvidedKeyOptions: azblob.ClientProvidedKeyOptions{}, Parallelism: 16})
	
	fmt.Printf("\n")

	if err != nil {
		fmt.Printf("ERROR!  %s", err.Error())
		os.Exit(1)
	}

	if 0 == strings.Compare("avi", fileType) {
		if shouldNotify == true {
			notifyQueue(account, container, sasKey, moviePackage, 5, "moviePack")
		}
	} else {
		if shouldNotify == true {
			notifyQueue(account, container, sasKey, moviePackage, 1, fileType)
		}
	}

	fmt.Printf(response.Response().Status + "\n")

	// // Verify upload (NOT Working for now)
	// URL, _ = url.Parse(fmt.Sprintf("https://%s.blob.core.windows.net/?%s", account, sasKey))

	// serviceURL := azblob.NewServiceURL(*URL, pLine)

	// whereString := fmt.Sprintf("Name='%s'", uploadPath)
	// timeoutInSeconds := int32(60)
	// maxResults := int32(1)
	// ans, err := serviceURL.FindBlobsByTags(ctx, &timeoutInSeconds, &requestID, &whereString, azblob.Marker{}, &maxResults)
	// if err != nil {
	// 	fmt.Printf("ERROR!  %s", err)
	// 	return
	// }
	// if len(ans.Blobs) < 1 {
	// 	fmt.Printf("ERROR!  Could not upload file")
	// 	return
	// }

	// fmt.Printf(ans.Status())
	return
}
