#!/usr/bin/python3

import time
import os
import sys
import subprocess
import argparse
import re
from datetime import datetime


date = datetime.now().strftime("%Y-%m-%d")
cartID = ""
remoteFilePath = ""
totalUpload = 0
uploadedSoFar = 0
retVal = 0


def keepUpToNProcesses( numProcesses: int , processList: list):
    global retVal
    global uploadedSoFar
    global totalUpload
    
    ### wait for N processes
    while numProcesses < len(processList):
        time.sleep(5)
        for proc in processList:
            res = proc.poll()
            if res is not None:
                fileName = proc.args[1]+"/"+proc.args[2]
                if 0 == res:
                    print('successfully uploaded '+ fileName, flush=True)
                    uploadedSoFar += os.path.getsize(fileName)               
                    os.remove(fileName)
                    print("uploaded "+str(uploadedSoFar)+"/"+str(totalUpload)+" - "+str(int(uploadedSoFar/totalUpload*100))+"%\n", file=sys.stderr, flush=True)
                else:
                    print("\nUploading of "+ fileName + " failed, next iteration will try again", file=sys.stderr, flush=True)   
                    retVal += 1 
                processList.remove(proc)



def runSync(args):
    global totalUpload
    global uploadedSoFar 
    global remoteFilePath
    global retVal

    account = args.account.lower()
    container = args.container.lower().replace('_','-')    
    uploadedSoFar = 0
           
    ### list local entries
    localList = os.listdir(args.source)
    
    ###iterate files, fork for sub directories and sum total size to upload
    # print("DEBUG: "+str(localList))
    dirList = []
    for file2Upload in localList:
        # print("DEBUG: "+str(file2Upload))
        fileFullPath=args.source + "/" + file2Upload
        if os.path.isdir(fileFullPath):
            dirList.append(file2Upload)
            if 0 == os.listdir(fileFullPath).__len__():
                os.removedirs(fileFullPath)
            else:
                localList.extend([file2Upload +"/"+ f for f in os.listdir(fileFullPath)])
                # print("DEBUG: "+str(localList))
        else:
            totalUpload += os.path.getsize(fileFullPath)
    
    for d in dirList:  
        localList.remove(d)
    # print("DEBUG: "+str(localList))
        
    print("found "+str(localList.__len__())+" files to upload", flush=True)
    print("Total size to upload from "+ args.source+": " +str(totalUpload), flush=True)
    print("uploaded 0/"+str(totalUpload)+" - 0%", file=sys.stderr, flush=True)
    
    iterations = 30
    count = 0
    
    while iterations != count and 0 != localList.__len__():
                
        ### upload non .avi files
        notAviFiles =  list(filter(lambda file: not file.endswith('.avi'), localList)) 
        print('uploading non .avi files to container', flush=True)
        print('account '+ account+' container: '+container, flush=True)
        print('non .avi files: ' + str(notAviFiles), flush=True)
        
        # threadList = []
        AZBinary = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../user_files/uploadToAZ')
        processList = []
        for entry in notAviFiles:
            localFile = args.source+"/"+entry
            if '_' in entry:
                entryPrefix = entry.split('_')[:-1]
                commonPrefix = '_'.join(entryPrefix)
            else:
                commonPrefix = entry.split('.')[0]
                
            filesWithCommonPrefix = len(list(filter(lambda p: commonPrefix in p, localList)))
            if 1 < filesWithCommonPrefix:
                shouldNotify = False
            else:
                shouldNotify = True
            
            #keep no more than 0 parallel uploads
            keepUpToNProcesses(0, processList)

            # using golang app
            proc = subprocess.Popen(args=[AZBinary, args.source, entry, account, container, remoteFilePath, args.SAS_key, str(shouldNotify)],stdout=sys.stderr)
            processList.append(proc)
            
                            
       
        ### wait for all processes
        keepUpToNProcesses(0, processList)
        # while 0 != len(processList):
        #     time.sleep(5)
        #     for proc in processList:
        #         res = proc.poll()
        #         if res is not None:
        #             if 0 == res:
        #                 print('successfully uploaded '+ proc.args[1], flush=True)
        #                 uploadedSoFar += os.path.getsize(proc.args[1])               
        #                 os.remove(proc.args[1])
        #                 print("uploaded "+str(uploadedSoFar)+"/"+str(totalUpload)+" - "+str(int(uploadedSoFar/totalUpload*100))+"%\n", file=sys.stderr, flush=True)
        #             else:
        #                 print("\nUploading of "+ proc.args[1] + " failed, next iteration will try again", file=sys.stderr, flush=True)   
        #                 retVal += 1 
        #             processList.remove(proc)
            
            
        ### upload .avi files
        aviFiles =  list(filter(lambda file: file.endswith('.avi'), localList)) 
        print('uploading .avi files to container', flush=True)
        print('account '+ account+' container: '+container, flush=True)
        print('.avi files: ' + str(aviFiles), flush=True)
        for movie in aviFiles:
            localFile = args.source+"/"+movie

            if movie.endswith('R.avi'):
                shouldNotify=True
            else:
                shouldNotify=False
        
            fileSize = os.path.getsize(localFile)
            if fileSize > 51200:
                #keep no more than 0 parallel uploads
                keepUpToNProcesses(0, processList)                
                
                # using golang app
                proc = subprocess.Popen(args=[AZBinary, args.source, movie, account, container, remoteFilePath, args.SAS_key, str(shouldNotify)],stdout=sys.stderr)
                processList.append(proc)
            else:
                print("the movie "+localFile+" is smaller the 50KB removing it from file system")
                totalUpload -= os.path.getsize(localFile)
                os.remove(localFile)
        
        
        ### wait for all processes
        keepUpToNProcesses(0, processList)
        # while 0 != len(processList):            
        #     for proc in processList:
        #         res = proc.poll()
        #         if res is not None:
        #             if 0 == res:
        #                 print('successfully uploaded '+ proc.args[1], flush=True)
        #                 uploadedSoFar += os.path.getsize(proc.args[1])               
        #                 os.remove(proc.args[1])
        #                 print("uploaded "+str(uploadedSoFar)+"/"+str(totalUpload)+" - "+str(int(uploadedSoFar/totalUpload*100))+"%\n", file=sys.stderr, flush=True)
        #             else:
        #                 print("\nUploading of "+ proc.args[1] + " failed, next iteration will try again", file=sys.stderr, flush=True)  
        #                 retVal += 1  
        #             processList.remove(proc)
        #     time.sleep(1)  
        
        ### list local entries
        count += 1
        localList = os.listdir(args.source)

        # print("DEBUG: "+str(localList))
        dirList = []
        for file2Upload in localList:
            # print("DEBUG: "+str(file2Upload))
            fileFullPath=args.source + "/" + file2Upload
            if os.path.isdir(fileFullPath):
                dirList.append(file2Upload)
                if 0 == os.listdir(fileFullPath).__len__():
                    os.removedirs(fileFullPath)
                else:
                    localList.extend([file2Upload +"/"+ f for f in os.listdir(fileFullPath)])
                    # print("DEBUG: "+str(localList))
  
        for d in dirList:  
            localList.remove(d)
        # print("DEBUG: "+str(localList))

        
    if uploadedSoFar == totalUpload: 
        retVal = 0
        if os.path.exists(args.source) and 0 == os.listdir(args.source).__len__():
            os.removedirs(args.source)
        
    
    if 0 != totalUpload:
        print("uploaded "+str(uploadedSoFar)+"/"+str(totalUpload)+" - "+str(int(uploadedSoFar/totalUpload*100))+"%", file=sys.stderr, flush=True)
        
    
    
### App starts here
### ===============    
if __name__=='__main__':

    ### set CLI arg parser
    parser = argparse.ArgumentParser(description='Walkout-Azure storage functionality', conflict_handler='resolve')
    
    subparsers = parser.add_subparsers(title='MODE', dest='mode', help='choose work mode')
    subparsers.required = True
    syncParser = subparsers.add_parser('sync', help='sync local directory to Azure storage container')
    
    syncParser.add_argument('--source', '-s', help='absolute path to local directory to sync to AZ storage', type=str, required=True)
    syncParser.add_argument('--account', '-a', help='retailer storage account', type=str, required=True)
    syncParser.add_argument('--container', '-c', help='branch container', type=str, required=True)
    syncParser.add_argument('--SAS-key', '-S', help='private SAS key to use when loading to AZ cloud', type=str, required=True)
    syncParser.add_argument('--ID', help='cart ID', required=True)
    syncParser.set_defaults(func=runSync)
    
    args = parser.parse_args()    
    
    dateInPath = re.sub(r'(.*/)([0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9])(.*)',r'\2',args.source)
    if dateInPath and (dateInPath != args.source):
        date = dateInPath

    container = args.container.lower()       
    cartID = str(args.ID)
    remoteFilePath = "cart_data/"+date+"/"+container+"/"+cartID+"/"

    args.func(args)               
               
    sys.exit(retVal)
    

