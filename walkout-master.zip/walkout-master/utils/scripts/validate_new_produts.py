import os
import pandas as pd
import argparse
import easygui

FULL_CSV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),'../../ourFirstCNN/guiQt/product_list_demo_latest.csv')
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Validate new products and integrate into list')
    parser.add_argument('--new-csv-file', help='path to new csv file',type=str, required=True)
    parser.add_argument('--old-csv-file', help='path to new csv file',type=str, default=FULL_CSV_PATH)
    parser.add_argument('--images-dir', help='path to images',type=str, required=True)
    args = parser.parse_args()

    assert os.path.exists(args.old_csv_file)
    assert os.path.exists(args.new_csv_file)
    assert os.path.isdir(args.images_dir)
    
    old_products = pd.read_csv(args.old_csv_file, encoding="ISO-8859-1", dtype=str)
    new_products = pd.read_csv(args.new_csv_file, encoding="ISO-8859-1", dtype=str)
    n_new_products = new_products.shape[0]
    image_list = [img for img in os.listdir(args.images_dir) if '.png' in img]
    assert len(image_list)==n_new_products, 'Number of products is different from number of images'
    for prod_idx in range(n_new_products):
        single_prod = new_products.iloc[prod_idx]
        db_sku = single_prod['product_name']
        assert db_sku not in old_products['product_name'], 'Product already exist in current DB'
        english_name = single_prod['english_name']
        image_path = os.path.join(args.images_dir, '%s.png' % db_sku)
        assert os.path.exists(image_path), 'Image not found for the barcode: %s' % db_sku
        scanned_barcode = easygui.enterbox("Enter product barcode of here:\n%s" % english_name, image=image_path)
        n_trials = 0
        while scanned_barcode!=db_sku and n_trials < 3:
            n_trials += 1
            scanned_barcode = easygui.enterbox("Invalid barcode, try again!\nExpected value:%s\nEnter product barcode of here:\n%s" % (db_sku, english_name), image=image_path)
        assert scanned_barcode==db_sku, 'DB barcode was inserted with an error, please check it: %s' % db_sku

    print('Valid List!')