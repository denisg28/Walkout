#!/bin/bash

######Please NOTICE!!!!
######This script opens a reverse tunnel - in order to shut it down please run:
###### kill -9 $(ps -ef | grep 'ssh -fNTR' |cut -d' ' -f6)

SANDBOX='rc-sandbox.francecentral.cloudapp.azure.com'

is_only_con()
{
	####check if someone is listenin on 22088 port
    if [ 0 -eq $(ssh -o "UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" -q -i ~/.ssh/RC-SandBox_key.pem cartRC@${SANDBOX} "netstat -tl" | grep 22088| wc -l) ] 
    then  
        echo 1
    else 
        echo 0
    fi
}

insert_IP_to_hosts_file()
{
    local myIP=`hostname -I| cut -d' ' -f1`

    ####remove old entries of carts on hosts file and insert own IP for developer side verification
    ssh -o "UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" -q -i ~/.ssh/RC-SandBox_key.pem -t cartRC@${SANDBOX} "sudo sed -i '/MyCart/d' /etc/hosts"
    ssh -o "UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" -q -i ~/.ssh/RC-SandBox_key.pem -t cartRC@${SANDBOX} "sudo sed -i -e '\$a${myIP}    MyCart' /etc/hosts"
}

open_con()
{
	####create reverse ssh tunnel from localhost on "Remote Control SandBox"
    ssh -o "UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" -R 22088:localhost:22088 -i ~/.ssh/RC-SandBox_key.pem cartRC@${SANDBOX}
}

main()
{
    if [ 1 -eq $(is_only_con) ]
    then
       insert_IP_to_hosts_file
       open_con
    else 
       echo "Remote connection mechanism in use, please verify no other carts are connected" 1>&2 
       exit 1
    fi
}


###App starts here
main

