import argparse
import os
import json
import pandas as pd
import numpy as np
from movie_parser_time_and_dir import fill_direction, is_valid_in_out_gt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='generate gt csv files from barcode annotation')
    parser.add_argument('--dir', help='path to conversion directory',type=str, required=True)
    parser.add_argument('--dir-policy', help='how to fill direction',type=str, default='in-out')
    parser.add_argument('--offset-in', help='move in event by n frames',type=int, default=10)
    parser.add_argument('--offset-out', help='move out event by n frames',type=int, default=-10)
    args = parser.parse_args()

    assert args.dir_policy in ('empty', 'in-out', 'out-in', 'in', 'out')
    script_files = [f for f in os.listdir(args.dir) if f.endswith('script.json')]
    print('Found %d files to convert' % (len(script_files)))

    all_skus = []
    all_dfs = dict()
    for f in script_files:
        print('Converting %s' % f)
        onboarding_rec = f.startswith('onboarding_')
        with open(os.path.join(args.dir, f)) as f_buffer:
            ann_json = json.load(f_buffer)
        if ann_json[0]==[0, '']:
            ann_json = ann_json[1:]
        ann_list = [dict(product=ann[1], direction=' ', frame=ann[0]) for ann in ann_json if ann[1]!='']
        # Fill direction & apply time offset
        ann_list = fill_direction(ann_list, args.dir_policy, args.offset_in, args.offset_out)
        ann_df = pd.DataFrame(ann_list, columns=['product', 'direction', 'frame'])
        all_dfs[f] = ann_df
        all_skus += ann_df['product'].tolist()
        csv_path = os.path.join(args.dir, f).replace('script.json', '_L.csv')
        if not is_valid_in_out_gt(ann_list) and not onboarding_rec:
            print('\033[91mbarcode annotations does not have a valid in-out order. Please review carefully!\033[00m')
        if not onboarding_rec:
            ann_df.to_csv(csv_path, index=False)
    
    # Check for barcode errors
    unique_skus = list(set(all_skus))
    skus_hist = {sku:0 for sku in unique_skus}
    for rec_name, df in all_dfs.items():
        rec_skus = df['product'].tolist()
        for prod in rec_skus:
            skus_hist[prod] +=1


    expected_n_appearances = np.median(np.array([a for a in skus_hist.values()]))
    outliner_skus = []
    for sku, appearances in skus_hist.items():
        if appearances < expected_n_appearances * 0.1:
            print('\033[91mOutlier SKU:%s. in movies:\033[00m' % sku)
            for rec_name, df in all_dfs.items():
                rec_skus = df['product'].tolist()
                if sku in rec_skus:
                    print('\033[91m%s\033[00m' % rec_name)
 
