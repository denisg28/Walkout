import argparse
import os
import json


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Change direction and timestamp of msco capsules')
    parser.add_argument('--root-dir', help='root directory to change capsules',type=str, required=True)
    parser.add_argument('--gt-postfix', help='extention of gt file of capsules',type=str, default='metadata.json')
    parser.add_argument('--gt-key', help='key of gt to change',type=str, default='direction')
    parser.add_argument('--gt-val', help='val of gt to change',type=str, required=True)
    args = parser.parse_args()

    if args.gt_key=='direction':
        assert args.gt_val in ('in', 'out')

    n_capsules = 0
    for root, dirs, files in os.walk(args.root_dir):
        for fname in files:
            if fname.endswith(args.gt_postfix):
                print('Modifying %s' % fname)
                n_capsules += 1
                with open(os.path.join(root, fname), 'r') as fp:
                    data = json.load(fp)
                    if 'gt' in data:
                        data['gt'][0][args.gt_key] = args.gt_val
                    elif args.gt_key=='direction':
                        # Create gt "unknown: product with middle frame as event
                        event_frame = (data['end_frame'] + data['start_frame']) // 2
                        data['gt'] = [{"product": "UNKNOWN", "direction": args.gt_val, "frame": event_frame}]
                with open(os.path.join(root, fname), 'w') as fp:
                    json.dump(data, fp)
    print('Modified total of %d capsules' % n_capsules)