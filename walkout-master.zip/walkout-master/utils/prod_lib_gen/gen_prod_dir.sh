#!/bin/bash

#ext
pushd webapp/server
rm database.sqlite3
rm -r node_modules 
rm app.log
popd

pushd webapp/client
yarn
yarn build
popd
./install.sh

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
REPO="$(dirname "$(dirname "$DIR")")"

echo "current repo " $REPO
PROD="${REPO}_prod"
echo "copy to prod repo " $PROD


export PYTHONPATH=${REPO}:${REPO}/ourFirstCNN
cd $DIR #utils/prod_lib_gen
FILE=include_auto.txt
echo "generating include files by python script"
python3 module_tree.py > include_auto.txt
rm -rf $PROD
mkdir $PROD
python3 genereate_prod_dir.py --src $REPO --dst $PROD
