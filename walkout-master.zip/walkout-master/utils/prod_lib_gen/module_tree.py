import os
import sys
from modulefinder import ModuleFinder

def get_used_modules():
    rp = os.path.realpath(__file__)
    src_path = os.path.dirname(os.path.dirname(os.path.dirname(rp)))
    fp = os.path.join(src_path,'ourFirstCNN','run_motion_detect.py')

    sys.path.append(os.path.join(src_path,'ourFirstCNN'))
    #use debug > 0 in order to see module tree
    finder = ModuleFinder(debug=0)
    finder.run_script(fp)

    SHOW_INCLUDED = True
    ret_list =[]
    trash = []
    if SHOW_INCLUDED:
        for name, mod in finder.modules.items():
            try:
                if src_path in mod.__file__:
                    ret_list.append(mod.__file__)
                    # print(mod.__file__)
                else:
                    trash.append(name)
            except:
                pass  # modules without files aren't part of walkout package
                trash.append(name)
    else:
        trash2 = []
        for name, mod in finder.badmodules.items():
            try:
                print(name + (': no file' if not hasattr(mod,'__file__') else mod.__file__))
                if src_path in mod.__file__:
                    print(mod.__file__)

                else:
                    trash2.append(name)
            except:
                print(name + ': exeption')
                # trash.append(name)
    return ret_list

if __name__ == '__main__':
    print("\n".join(get_used_modules()))