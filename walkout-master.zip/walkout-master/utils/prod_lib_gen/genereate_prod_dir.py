import argparse
import os
import shutil
import misc

from module_tree import get_used_modules

used_modules = None #None for search, path for txt file i.e 'include_auto.txt'
manual_modules_file = 'include_manual.txt'


def file_to_list(fileName):
    crimefile = open(fileName, 'r')
    files =  [line.replace('\n','') for line in crimefile.readlines()]
    base_dir = os.path.dirname(os.path.realpath(__file__)).split('utils/prod_lib_gen')[0]
    return [os.path.join(base_dir, f) for f in files]

def gen_readme_file(dir):
    file_name = 'README.md'
    file_path = os.path.join(dir,file_name)
    strng = ''
    strng = misc.get_git_branch_name(verbose=False)
    strng += '::'
    strng += misc.get_git_version_name(verbose=False)
    strng += '\n'
    strng += misc.getTimeAndDate()
    print(strng)
    with open(file_path, 'w') as f:
        f.write(strng)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='generate slimmer repo')
    parser.add_argument('--src', '-s', help='Path of source repo', type=str)
    parser.add_argument('--dst', '-d', help='Path to destination', type=str)

    args = parser.parse_args()

    orig_repo = args.src
    prod_repo = args.dst
    if orig_repo is None or prod_repo is None:
        raise IOError("two args are expected")

    manual_srcs = file_to_list(manual_modules_file)
    if used_modules is None:
        print('*** generate new module list from python')
        used_modules = get_used_modules()
    else:
        print('*** generate module list from saved file')
        used_modules = file_to_list(used_modules)

    # print("\n".join(used_modules))
    # print("\n".join(manual_modules))

    to_cp_list = used_modules + manual_srcs
    shutil.rmtree(prod_repo)
    for to_cp in to_cp_list:
        print("copying {}".format(to_cp))
        cp_path = to_cp.replace(orig_repo, prod_repo)
        os.makedirs(os.path.dirname(cp_path), exist_ok=True)
        if os.path.isdir(to_cp):
            shutil.copytree(to_cp,cp_path)
        else:
            shutil.copy(to_cp, cp_path)

    gen_readme_file(prod_repo)

