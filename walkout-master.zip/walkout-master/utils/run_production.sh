#!/bin/bash

source $HOME/py3_env/bin/activate

BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

today=$(date +'%Y_%m_%d') 

function echoerr() {
    printf "${RED}########### there was an error with ${1} can't continue, exit now... ###########\n${NC}"
    exit 1
}

printf "${BLUE}################### Create Production Dir ####################\n${NC}"
./utils/prod_lib_gen/gen_prod_dir.sh
exit_status=$?
if [ $exit_status -ne 0 ]; then
    echoerr "Create Production Dir"
fi
echo "SOFTWARE_VERSION: '$2'" > ../walkout_prod/user_files/config_params.yaml

printf "${BLUE}############### Generate pyarmor Production ##################\n${NC}"
pushd utils/pyarmor_gen
python3 run_pyarmor.py --base-dir $1 --src-dir walkout_prod
exit_status=$?
if [ $exit_status -ne 0 ]; then
    echoerr "Generate pyarmor Production"
fi
popd

printf "${BLUE}################ Create Production artifact ##################\n${NC}"
python utils/gen_destroy_date.py
exit_status=$?
if [ $exit_status -ne 0 ]; then
    echoerr "Create Production destroy date"
fi
mv des.yaml $1/walkout_prod_pyarmor/des.yaml
pushd $1/walkout_prod_pyarmor
zip -r Walkout_artifact_$2.zip *  > /tmp/zip.log
exit_status=$?
if [ $exit_status -ne 0 ]; then
    echoerr "Create Production zip artifact"
fi
rm /tmp/zip.log
aws s3 cp Walkout_artifact_$2.zip s3://walkout-main/RND/artifacts/$today/Walkout_artifact_$2.zip
exit_status=$?
if [ $exit_status -ne 0 ]; then
    echoerr "upload zip artifact"
fi
popd

pushd user_files/production_files
aws s3 sync . s3://walkout-main/RND/artifacts/$today/production_files_$2/
exit_status=$?
if [ $exit_status -ne 0 ]; then
    echoerr "production files for artifact"
fi
popd

printf "${BLUE}################## remove directories ########################\n${NC}"
pushd $1
rm -r walkout_prod_pyarmor
rm -r walkout_prod
popd
printf "${GREEN}####################### DONE!!! ##############################\n${NC}"