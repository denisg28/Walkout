sudo nvpmodel -m 0
sudo jetson_clocks
cd
source ~/py3_env/bin/activate
pushd ~/git_repo/walkout/ourFirstCNN/
python MotionDetect.py 
popd
