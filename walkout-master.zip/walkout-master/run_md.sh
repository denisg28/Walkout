#!/bin/bash

SRC=$HOME/py3_env/bin

#adding current dir to be path to run from
export PYTHONPATH=${PWD}:${PWD}/ourFirstCNN:$PYTHONPATH

# Reset basler usb ports
python cv_blocks/usb/usb_reset.py --name Basler

if [ -d "$SRC" ]; then
  source ${SRC}/activate
  python ourFirstCNN/run_motion_detect.py --config user_files/$mode $data_prefix $video $shop_mod --session-id $session_id
else
  SRC=/usr/local/py3_env/bin
  if [ -d "$SRC" ]; then
    ${SRC}/python ourFirstCNN/run_motion_detect.py --config user_files/$mode $data_prefix $video $shop_mod --session-id $session_id
  else
    echo [Warning]: no virtual env found
    python3 ourFirstCNN/run_motion_detect.py --config user_files/$mode $data_prefix $video $shop_mod --session-id $session_id
  fi
fi

