#!/bin/bash

today=$(date +'%Y-%m-%d %H:%M:%S') 
LIMIT=3
TO_KEEP=-3
ERROR='software update failed, please try again later'

function echoerr() {
    # we get error to print 
    echo "$ERROR" 1>&2 
    exit 1
}

function exec_and_verify(){
    if [[ $1 == *"unzip"* ]]; then
        $1 > /tmp/unzip.log || echoerr
    else
        $1 || echoerr
    fi
}

function check_and_remove(){
    if [ -d "$1" ]; then
        pushd "$1"
        count=$(ls | wc -l)
        if [ "$count" -gt "$LIMIT" ]; then
            folders=$(ls -tr | head "$TO_KEEP")
            for folder in "$folders"
            do
                printf "folder $1/$folder removed!\n"
                rm -rf "$folder"
            done
            else 
                printf "path $1 no exceed limit $LIMIT: not removing models\n"
        fi
        popd
    fi
}

printf "################### Download New WalkOut Artifact ####################\n"

WALKOUT_ARTIFACT=Walkout_artifact_${COMMIT_ID}.zip 
exec_and_verify "aws s3 cp s3://walkout-main/RND/artifacts/${DATE}/${WALKOUT_ARTIFACT} /usr/local/${WALKOUT_ARTIFACT}"
exec_and_verify "aws s3 cp s3://walkout-main/RND/artifacts/${DATE}/production_files_${COMMIT_ID}/${RETAILER}.yaml /usr/local/config_branch.yaml"

# Exit if artifact download failed
if [[ -f "/usr/local/${WALKOUT_ARTIFACT}" && -s "/usr/local/${WALKOUT_ARTIFACT}" ]]; then 
    printf "Successfully Downloaded $WALKOUT_ARTIFACT\n"
else 
    printf "Download of ${WALKOUT_ARTIFACT} failed. Aborting\n"
    echoerr
fi

# Exit if config download failed
if [[ -f "/usr/local/config_branch.yaml" && -s "/usr/local/config_branch.yaml" ]]; then 
    printf "Successfully Downloaded ${COMMIT_ID}/${RETAILER}.yaml\n"
else 
    printf "Download of ${COMMIT_ID}/${RETAILER}.yaml failed. Aborting\n"
    echoerr
fi

pushd /usr/local/
rm -rf walkout_new
printf "################### Extracting WalkOut Artifact ####################\n"
printf "################### Unzip WalkOut Artifact ####################\n"
exec_and_verify "unzip ${WALKOUT_ARTIFACT} -d ./walkout_new"
exec_and_verify "mv config_branch.yaml walkout_new/user_files/"

if [ -d "walkout" ]; then
   ## here its safe to get errors
   cp walkout/user_files/local_list.json walkout_new/user_files/local_list.json
   cp -rp walkout/webapp/server/node_modules walkout_new/webapp/server/node_modules
   cp walkout/webapp/server/database.sqlite3 walkout_new/webapp/server/database.sqlite3
   cp walkout/webapp/server/yarn.lock walkout_new/webapp/server/yarn.lock
   check_and_remove "walkout/ourFirstCNN/tensorrt_lib/models/detector"
   check_and_remove "walkout/ourFirstCNN/tensorrt_lib/models/classifier"
   cp -rp walkout/ourFirstCNN/tensorrt_lib/models walkout_new/ourFirstCNN/tensorrt_lib/models
   check_and_remove "walkout/cv_blocks/calibration/models"
   cp -rp walkout/cv_blocks/calibration/models walkout_new/cv_blocks/calibration/models
   cp -rp walkout/cart_blocks/indications/sound_files walkout_new/cart_blocks/indications/sound_files
   check_and_remove "walkout/cv_blocks/cart_net_classifier/models"
   cp -rp walkout/cv_blocks/cart_net_classifier/models walkout_new/cv_blocks/cart_net_classifier/models
   mkdir --parents walkout_new/cv_blocks/cart_bottom/diff_yolo
   check_and_remove "walkout/cv_blocks/cart_bottom/diff_yolo/models"
   cp -rp walkout/cv_blocks/cart_bottom/diff_yolo/models walkout_new/cv_blocks/cart_bottom/diff_yolo/models
   check_and_remove "walkout/cv_blocks/cart_bottom/event_detector/models"
   cp -rp walkout/cv_blocks/cart_bottom/event_detector/models walkout_new/cv_blocks/cart_bottom/event_detector/models
fi


## here its safe to get errors too
rm ${WALKOUT_ARTIFACT}
rm /tmp/unzip.log

pushd walkout_new/webapp/server
yarn

if [ "$?" -ne 0 ]; then
        popd
        printf "yarn faild, probebly internet connection\n"
        rm -rf walkout_new
        echoerr
    else
        popd
        rm -rf walkout
        mv walkout_new walkout
        echo "$today info: ################### DONE! ####################" >> /usr/local/walkout/webapp/server/app.log
        sudo pkill -f chromium-browser
        sudo reboot
fi