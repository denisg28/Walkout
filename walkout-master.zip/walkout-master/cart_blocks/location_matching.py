from cv_blocks.common.types import BoundingBox2D
import cv2
import numpy as np
from cv_blocks.events.event_logic import EventType
from cv_blocks.events.event_similarity import calc_desc_dists
from config import config
from md_blocks.md_messages import MDMessages
import traceback


class LocationMatching:

    class Config(object):
        # TODO - remove un-needed
        def __init__(self, config):
            assert isinstance(config, dict)
            self.iou_weight = config.get('iou_weight', 0.65)
            self.dist_weight = config.get('dist_weight', 0.175)
            self.scale_weight = config.get('scale_weight', 0.175)
            self.desc_weight = config.get('desc_weight', 0.5)
            self.min_iou = config.get('min_iou', 0.2)
            self.max_dist = config.get('max_dist', 0.15)
            self.min_scale = config.get('min_iou', 0.3)
            self.max_desc_dist = config.get('max_desc_dist', 1.5)
            self.conf_score_th = config.get('conf_score_th', 0.8)
            self.very_conf_score = config.get('very_conf_score', 1.2)
            self.ratio_th = config.get('ratio_th', 1.8)
            self.high_ratio = config.get('high_ratio', 2.5)
            self.very_high_cls_conf_ratio = config.get('very_high_cls_conf_ratio', 8)

    def __init__(self, md_module, config_dict=dict()):
        self.params = self.Config(config_dict)
        self.md_module = md_module
        self.locations = dict()
        self.products_in_cart_info = dict()
        self.not_removed_products = dict()
        self.predictions_history = []
        self.confident_predictions = []
        self.pending_items = []
        self.debug = False
        self.eval_mode = self.md_module.eval_mode
    
    def get_pile_locations(self, cam_name, bbox, mode='adjacent'):
        '''
        Try to find cart locations that can explain a pile location of a bounding box:
        boxes s.t:
        1. top of box is very similar to bottom of other box
        2. horizonal boundries of boxes have significat overlap
        '''
        assert mode in ('adjacent', 'overlap')
        locs = []
        if self.debug:
            print("LocationMatchDebug: check for pile box[%s] for bbox:" % cam_name, bbox, flush=True)
        for event_id, location_in in self.locations.items():
            if location_in[cam_name] is not None:
                cart_bbox = location_in[cam_name]
                if mode=='adjacent':
                    horizontal_ov = min(cart_bbox.x2, bbox.x2) - max(cart_bbox.x1, bbox.x1)
                    if horizontal_ov < 1e-3:
                        continue
                    smaller_item_h = min(cart_bbox.w(), bbox.w())
                    vertical_diff = abs(cart_bbox.y1 - bbox.y2)
                    if vertical_diff < 0.02 and (horizontal_ov / smaller_item_h) > 0.5:
                        locs.append(cart_bbox)
                    if self.debug:
                        print("LocationMatchDebug: pile box candidate:", cart_bbox, flush=True)
                        print("LocationMatchDebug: v_diff=%.2f, h_ov=%.2f, small_h=%.2f:" % (vertical_diff, horizontal_ov, smaller_item_h), flush=True)
                elif mode=='overlap':
                    if BoundingBox2D.iou(cart_bbox, bbox) > 0.4:
                        locs.append(cart_bbox)
                    if self.debug:
                        print("LocationMatchDebug: pile box candidate:", cart_bbox, flush=True)
                        print("LocationMatchDebug: iou=%.2f:" % (BoundingBox2D.iou(cart_bbox, bbox)), flush=True)
        return locs

    def match(self, event_info):
        location_out = self.estimate_location(event_info)
        candidate_predictions = dict()
        for cam in location_out.keys():
            candidate_predictions[cam] = []
        for event_id, location_in in self.locations.items():
            for cam in location_out.keys():
                if location_out[cam] is None or location_in[cam] is None:
                    continue
                if 'sequence_descriptors' in event_info:
                    curr_cam_desc = np.array([desc for mv, desc in zip(event_info['movement_vector_for_saving'], event_info['sequence_descriptors']) \
                        if mv.cam_name==cam])
                iou = BoundingBox2D.iou(location_out[cam], location_in[cam])
                dist = BoundingBox2D.dist(location_out[cam], location_in[cam])
                scale_similarity = BoundingBox2D.scale_similarity(location_out[cam], location_in[cam])
                if iou > self.params.min_iou or (scale_similarity > self.params.min_scale and dist < self.params.max_dist):
                    candidate_predictions[cam].append(dict(prod_id=self.products_in_cart_info[event_id]['prod_id'],
                                                           iou=iou, dist=dist, scale=scale_similarity, event_id=event_id,
                                                           desc_dist=np.nan))
                    if 'sequence_descriptors' in self.products_in_cart_info[event_id] and len(curr_cam_desc):
                        ref_event = self.products_in_cart_info[event_id]
                        ref_cam_desc = np.array([desc for ref_cam, desc in zip(ref_event['descriptor_cams'], ref_event['sequence_descriptors']) \
                            if ref_cam==cam])
                        if len(ref_cam_desc) > 0:
                            candidate_predictions[cam][-1]['desc_dist'] = calc_desc_dists(curr_cam_desc, ref_cam_desc)

        scores = []
        desc_dist = []
        event_ids = []
        for cam in location_out.keys():
            for prediction in candidate_predictions[cam]:
                score = self.calc_location_score(iou=prediction['iou'], dist=prediction['dist'],
                                                 scale=prediction['scale'], desc_dist=prediction['desc_dist'])
                if score > 0:
                    if prediction['event_id'] not in event_ids:
                        scores.append(score)
                        desc_dist.append([prediction['desc_dist']])
                        event_ids.append(prediction['event_id'])
                    else:
                        scores[event_ids.index(prediction['event_id'])] += score
                        desc_dist[event_ids.index(prediction['event_id'])] += [prediction['desc_dist']]

        sorted_indices = np.argsort(scores)[::-1]
        if len(sorted_indices) > 0:  # at least 1 valid prediction
            best_scores = []
            best_desc_dists = []
            best_event_ids = []
            event_frames = []
            prod_ids = []
            for i in range(min(3, len(sorted_indices))):
                best_scores.append(scores[sorted_indices[i]])
                best_desc_dists.append(desc_dist[sorted_indices[i]])
                best_event_ids.append(event_ids[sorted_indices[i]])
                event_frames.append(self.products_in_cart_info[best_event_ids[i]]['frame'])
                prod_ids.append(self.products_in_cart_info[best_event_ids[i]]['prod_id'])
            if self.debug:
                print("LocationMatchDebug: top3 predictions:", flush=True)
                for i, prod_id in enumerate(prod_ids):
                    print("{}. {} - score: {}".format(i + 1, prod_id, best_scores[i]), flush=True)
            self.predictions_history.append(dict(prod_ids=prod_ids, scores=best_scores, desc_dists=best_desc_dists,
                                                 event_in_ids=best_event_ids, event_out_id=event_info['event_id'],
                                                 event_in_frames=event_frames, event_out_frame=event_info['event_frame']))
        else:  # no prediction
            self.predictions_history.append(dict(prod_ids=None, event_in_frames=None,
                                                 event_out_frame=event_info['event_frame']))
            if self.debug:
                print("LocationMatchDebug: Location has no prediction", flush=True)

        return self.predictions_history[-1]

    def resolve_interaction(self, prod_id, event_id):
        try:
            assert event_id in self.products_in_cart_info.keys()
            self.products_in_cart_info[event_id]['prod_id'] = prod_id
            if event_id in self.pending_items:
                if prod_id not in ('UNKNOWN', 'barcode_item_pending', 'plu_item_pending', 'unrecognized_pending'):
                    self.pending_items.pop(self.pending_items.index(event_id))
        except:
            MDMessages.log_md_warning(traceback.format_exc(), source='location_matching')

    def prod_in_cart(self, prod_id, include_unresolved=True):
        all_prods_in_cart = []
        for prod_in_cart_info in self.products_in_cart_info.values():
            if prod_id == prod_in_cart_info['prod_id']:
                return True
            if include_unresolved and prod_in_cart_info['prod_id'] in ('UNKNOWN', 'barcode_item_pending', 'plu_item_pending', 'unrecognized_pending'):
                if prod_id in (prod_in_cart_info['top_probs'][0][0], prod_in_cart_info['top_probs'][1][0]):
                    return True
        return False

    def compare_location_classifier_predictions(self, event_type, top_products, location_predictions):
        location_idx = None
        if location_predictions['prod_ids'] is None:
            return event_type, top_products, location_idx
        top_loc_pred_score = location_predictions['scores'][0]
        top_loc_pred_unresolved = location_predictions['prod_ids'][0] in ('UNKNOWN', 'barcode_item_pending', 'plu_item_pending', 'unrecognized_pending')
        first_second_ratio = 0 if len(location_predictions['scores']) == 1 else \
            location_predictions['scores'][0] / location_predictions['scores'][1]
        valid_top_guess = ((top_loc_pred_score >= self.params.conf_score_th and first_second_ratio >= self.params.ratio_th) or \
                    top_loc_pred_score >= self.params.very_conf_score)
        # ignore when Real-time and match is unresolved
        if valid_top_guess and not self.eval_mode and top_loc_pred_unresolved:
            return event_type, top_products, location_idx

        if event_type == EventType.ProductConfidentEventFirstValid:
            if top_products[0][0] in location_predictions['prod_ids']:
                location_idx = location_predictions['prod_ids'].index(top_products[0][0])
            if valid_top_guess:
                if location_idx is None and not top_loc_pred_unresolved and not self.prod_in_cart(top_products[0][0]) and \
                        top_products[0][1] <= self.params.very_high_cls_conf_ratio * top_products[1][1]:
                    self.add_confident_prediction(location_predictions)
                    location_idx = 0
                    event_type = EventType.ProductConfidentEventFirstValid
                    top_products.insert(0, (location_predictions['prod_ids'][0], 100.0))
                    top_products.pop(-1)
        elif event_type == EventType.ProductConfidentEventSecondValid:
            if top_products[1][0] in location_predictions['prod_ids']:
                location_idx = location_predictions['prod_ids'].index(top_products[1][0])
            if valid_top_guess:
                if location_idx is None and not top_loc_pred_unresolved and not self.prod_in_cart(top_products[1][0]) and \
                        top_products[1][1] <= self.params.very_high_cls_conf_ratio * top_products[2][1]:
                    self.add_confident_prediction(location_predictions)
                    location_idx = 0
                    event_type = EventType.ProductConfidentEventFirstValid
                    top_products.insert(0, (location_predictions['prod_ids'][0], 100.0))
                    top_products.pop(-1)
        elif event_type in (EventType.ClassifierNotConfidentEvent, EventType.NotConfidentEventTriggerUnrecognized, \
                            EventType.LowConfidenceEvent):
            if self.debug:
                print("LocationMatchDebug: unknown case: top1 score: {}, ratio: {}".format(top_loc_pred_score, first_second_ratio), flush=True)
            if valid_top_guess:
                if location_predictions['desc_dists'][0][0] is not None:
                    desc_distances = location_predictions['desc_dists']
                    if len(desc_distances)==1 or np.array(desc_distances[0]).min() < np.array(desc_distances[1]).min() and \
                            not top_loc_pred_unresolved and \
                            self.prod_in_cart(location_predictions['prod_ids'][0], include_unresolved=False):
                            location_idx = 0
                            event_type = EventType.ProductConfidentEventFirstValid
                            top_products.insert(0, (location_predictions['prod_ids'][0], 100.0))
                            top_products.pop(-1)
                            self.add_confident_prediction(location_predictions)
                else:
                    first_conf_score = top_products[1][0] not in location_predictions['prod_ids'] or \
                                    location_predictions['scores'][0] >= self.params.high_ratio * \
                                    location_predictions['scores'][location_predictions['prod_ids'].index(top_products[1][0])]
                    second_conf_score = top_products[0][0] not in location_predictions['prod_ids'] or \
                                        location_predictions['scores'][0] >= self.params.high_ratio * \
                                        location_predictions['scores'][location_predictions['prod_ids'].index(top_products[0][0])]
                    if top_products[0][0] == location_predictions['prod_ids'][0] and first_conf_score:
                        location_idx = 0
                        event_type = EventType.ProductConfidentEventFirstValid
                        self.add_confident_prediction(location_predictions)
                    elif top_products[1][0] == location_predictions['prod_ids'][0] and second_conf_score:
                        location_idx = 0
                        event_type = EventType.ProductConfidentEventSecondValid
                        self.add_confident_prediction(location_predictions)
                    elif top_loc_pred_unresolved:
                        event_in_frame = location_predictions['event_in_frames'][0]
                        in_event = [event for event in self.products_in_cart_info.values() if event['frame'] == event_in_frame]
                        if len(in_event) == 1:
                            in_prods = [top_prob[0] for top_prob in in_event[0]['top_probs'][:2]]
                            out_prods = [top_prob[0] for top_prob in top_products[:2]]
                            if in_prods[0] in out_prods or in_prods[1] in out_prods:
                                location_idx = 0
                                event_type = EventType.ProductConfidentEventFirstValid
                                self.add_confident_prediction(location_predictions)
        if location_idx is not None:
            print("LocationMatchDebug: matched idx: %d, ratio: %.2f" % \
                 (location_idx, first_second_ratio), flush=True)
        return event_type, top_products, location_idx

    def add_confident_prediction(self, prediction, idx=0):
        self.confident_predictions.append(dict(out_frame=prediction['event_out_frame'],
                                               in_frame=prediction['event_in_frames'][idx],
                                               prod_id=prediction['prod_ids'][idx],
                                               out_event_id=prediction['event_out_id'],
                                               in_event_id=prediction['event_in_ids'][idx],
                                               score=prediction['scores'][idx]))

    def remove_product(self, prod_id, location_idx, pending_items_removal=False, pending_event_id=None):
        try:
            if pending_items_removal:
                if pending_event_id in self.pending_items:
                    del self.locations[pending_event_id]
                    del self.products_in_cart_info[pending_event_id]
                    self.pending_items.pop(self.pending_items.index(pending_event_id))
                return
            if location_idx is not None:
                event_id = self.predictions_history[-1]['event_in_ids'][location_idx]
                del self.locations[event_id]
                del self.products_in_cart_info[event_id]
            else:
                optional_events = [event_id for event_id, event_info in self.products_in_cart_info.items() if
                                event_info['prod_id'] == prod_id]
                if len(optional_events) == 1:
                    del self.locations[optional_events[0]]
                    del self.products_in_cart_info[optional_events[0]]
                elif len(optional_events) > 1:
                    if prod_id in self.not_removed_products.keys():
                        self.not_removed_products[prod_id] += 1
                    else:
                        self.not_removed_products[prod_id] = 1
            if prod_id in self.not_removed_products.keys():
                optional_events = [event_id for event_id, event_info in self.products_in_cart_info.items() if
                                event_info['prod_id'] == prod_id]
                if len(optional_events) == self.not_removed_products[prod_id]:
                    del self.not_removed_products[prod_id]
                    for event_id in optional_events:
                        del self.locations[event_id]
                        del self.products_in_cart_info[event_id]
            if self.debug:
                print("LocationMatchDebug: after removal: products events: {} ({}), pending events: {} ({})".
                    format(self.locations.keys(), len(self.locations.keys()), len(self.pending_items),
                            self.pending_items), flush=True)
        except:
            MDMessages.log_md_warning(traceback.format_exc(), source='location_matching')

    def reset(self):
        self.predictions_history = []
        self.confident_predictions = []
        self.pending_items = []
        self.locations = dict()
        self.products_in_cart_info = dict()
        self.not_removed_products = dict()

    def calc_location_score(self, iou, dist, scale, desc_dist):
        """
        Using iou, distance and scale similarity parameters to evaluate location matching score.
        Weight for iou:          0.5 , allowed range: 0.2 : 1
        Weight for distance:     0.25, allowed range: 0   : 0.07
        Weight for scale:        0.25, allowed range: 0.5 : 1
        Weight for desc dist:    0.5 of total, allowed range: 0.2 : 1.5
        """
        iou_score = iou * (iou > self.params.min_iou)
        dist_score = max(0, (self.params.max_dist - dist) / self.params.max_dist)
        scale_score = scale * (scale > self.params.min_scale)
        score = iou_score * self.params.iou_weight + dist_score * self.params.dist_weight + scale_score * self.params.scale_weight
        if desc_dist is not np.nan:
            desc_score = max(0, (self.params.max_desc_dist - dist) / self.params.max_desc_dist)
            # Renormalize score 
            score = desc_score * self.params.desc_weight + (1. - self.params.desc_weight) * score

        return score

    def update_cb_location(self, event_id, bbox_vec):
        for cam, boxes in bbox_vec.items():
            if len(boxes) == 1 and event_id in self.locations:
                self.locations[event_id][cam] = boxes[0][0]
                if self.should_visualize():
                    self.visualize_location(cam=cam, box=boxes[0][0], direction='in')

    def should_visualize(self):
        if self.md_module is not None and config.DISPLAY_ALGO_DETAIL:
            return True
        return False

    def visualize_location(self, cam, box, direction):
        color = (0, 255, 0) if direction == 'in' else (0, 0, 255)
        image = self.md_module.viz_frameL_resized if cam == 'front' else self.md_module.viz_frameB_resized
        shape = image.shape
        cv2.rectangle(image, (int(box.x1 * shape[1]), int(box.y1 * shape[0])),
                      (int(box.x2 * shape[1]), int(box.y2 * shape[0])), color, 5)

    def estimate_location(self, event_info):
        location_per_cam = dict()
        for cam in event_info['bbox_vec'].keys():
            md_boxes = [box[0] for box in event_info['bbox_vec'][cam] if box[3] is not None]
            cb_boxes = [box[0] for box in event_info['bbox_vec'][cam] if box[3] is None]
            if len(cb_boxes) == 1:
                # if CB image exists, use it to determine product location
                location_per_cam[cam] = cb_boxes[0]
            elif cam == event_info['initiating_cam'] or event_info['both_cams_saw_event']:
                # if camera saw event in MD
                if len(md_boxes) == 0:
                    location_per_cam[cam] = None
                else:
                    if event_info['event_direction'] == 'out':
                        bottom_box = event_info['init_coords']
                    else:
                        bottom_box = None
                        for i in range(len(md_boxes)):
                            if event_info['event_direction'] == 'in' and md_boxes[-i-1].get_score() > -1:
                                bottom_box = md_boxes[-i-1]
                                break
                    location_per_cam[cam] = bottom_box
            else:
                # event not seen in MD and CB image does not exist also ==> no information for location
                location_per_cam[cam] = None
        if self.should_visualize():
            for cam in location_per_cam.keys():
                if location_per_cam[cam] is not None:
                    self.visualize_location(cam=cam, box=location_per_cam[cam], direction=event_info['event_direction'])
        return location_per_cam

    def add_product(self, event_info, prediction_product_id, top_products, pending_unrecognized=False):
        location_per_cam = self.estimate_location(event_info)
        self.locations[event_info['event_id']] = location_per_cam
        self.products_in_cart_info[event_info['event_id']] = dict(prod_id=prediction_product_id, top_probs=top_products,
                                                                  frame=event_info['event_frame'])
        if 'sequence_descriptors' in event_info:
            self.products_in_cart_info[event_info['event_id']]['sequence_descriptors'] = event_info['sequence_descriptors']
            desc_cams = [mv.cam_name for mv in event_info['movement_vector_for_saving']]
            self.products_in_cart_info[event_info['event_id']]['descriptor_cams'] = desc_cams

        if pending_unrecognized:
            self.pending_items.append(event_info['event_id'])
        if self.debug:
            print("LocationMatchDebug: id added: {}, products events: {} ({}), pending events: {} ({})".
                  format(event_info['event_id'], self.locations.keys(), len(self.locations.keys()),
                         len(self.pending_items), self.pending_items), flush=True)
            print("LocationMatchDebug: current localized boxes:", self.locations, flush=True)

    def get_state(self):
        ret_dict = dict()
        for k, val in vars(self).items():
            if k in ('params', 'md_module', 'debug'):
                continue
            else:
                ret_dict[k] = val
        
        return ret_dict

    def set_state(self, state):
        for k, val in state.items():
            if k in ('debug',):
                continue
            setattr(self, k, val)