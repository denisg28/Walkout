from math import ceil, pow
from cart_blocks.random_weight.base_parser import BaseRandomWeightParser

CODE_SIZE = 13
NUM_CHECK_DIGITS = 2
DEFAULT_PREFIX_LEN = 2
DEFAULT_PROD_CODE_LEN = 4
DEFAULT_PAYLOAD_LEN = 5

WEIGHT_FACTORS = {'2-': {0:0, 1:2, 2:4, 3:6, 4:8, 5:9, 6:1, 7:3, 8:5, 9:7},
                  '3':  {0:0, 1:3, 2:6, 3:9, 4:2, 5:5, 6:8, 7:1, 8:4, 9:7},
                  '5+': {0:0, 1:5, 2:1, 3:6, 4:2, 5:7, 6:3, 7:8, 8:4, 9:9},
                  '5-': {0:0, 1:5, 2:9, 3:4, 4:8, 5:3, 6:7, 7:2, 8:6, 9:1}
                 }
DEFAULT_PAYLOAD_4_FACTORS = ['2-', '2-', '3', '5-']
DEFAULT_PAYLOAD_5_FACTORS = ['5+', '2-', '5-', '5+', '2-']
DEFAULT_PAYLOAD_FACTORS = {'4':DEFAULT_PAYLOAD_4_FACTORS, '5':DEFAULT_PAYLOAD_5_FACTORS}

class GS1RandomWeightParser(BaseRandomWeightParser):
    """
    Base Object of parsing Random Weight barcodes
    """
    def __init__(self, vald_code_prefix,
                 n_check_digits=NUM_CHECK_DIGITS,
                 prefix_len=DEFAULT_PREFIX_LEN,
                 inv_map_key='5-',
                 include_prefix_in_query=True,
                 ):
        assert inv_map_key in WEIGHT_FACTORS.keys()
        self.vald_code_prefix = vald_code_prefix
        self.n_check_digits = n_check_digits
        self.prefix_len = prefix_len
        self.inv_map_key = inv_map_key
        self.inv_map_payload = {v: k for k, v in WEIGHT_FACTORS[inv_map_key].items()}
        self.include_prefix_in_query = include_prefix_in_query
    
    @staticmethod
    def check_code(code_prefix, cd):
        assert isinstance(code_prefix, str) and len(code_prefix)==DEFAULT_PREFIX_LEN
        reg = dict(prefix=code_prefix)
        assert 'type' in cd and cd['type'] in ('price_embedded', 'weight_embedded')
        reg['type'] = cd['type']
        assert 'prod_code_len' in cd and isinstance(cd['prod_code_len'], int)
        reg['prod_code_len'] = cd['prod_code_len']
        assert 'payload_len' in cd and isinstance(cd['payload_len'], int)
        reg['payload_len'] = cd['payload_len']
        assert 'payload_frac_size' in cd and isinstance(cd['payload_frac_size'], int) and \
            cd['payload_frac_size'] < cd['payload_len']
        reg['payload_frac_size'] = cd['payload_frac_size']
        if 'weight_factors' in cd and isinstance(cd['weight_factors'], (list, tuple)) and \
            len(cd['weight_factors'])==cd['payload_len']:
            reg['weight_factors'] = cd['weight_factors']
        else:
            reg['weight_factors'] = DEFAULT_PAYLOAD_FACTORS[str(reg['payload_len'])]
        
        assert len(code_prefix) + reg['prod_code_len'] + reg['payload_len'] + NUM_CHECK_DIGITS == CODE_SIZE
        return reg

    def expected_bc_len(self):
        return CODE_SIZE
    
    def get(self, barcode, part, code_info=None):
        assert part in ('prefix', 'prod_code', 'payload', 'check_digit', 'payload_check_digit')
        if part=='prefix':
            return barcode[:self.prefix_len]
        if part=='check_digit':
            return barcode[-1]
        assert code_info is not None
        if part=='prod_code':
            return barcode[self.prefix_len:code_info['prod_code_len'] + self.prefix_len]
        elif part=='payload':
            return barcode[-code_info['payload_len'] -1:-1]
        elif part=='payload_check_digit':
            return barcode[code_info['prod_code_len'] + self.prefix_len]
    
    def get_check_payload(self, payload, weight_factors):
        if len(payload)==4:
            return self.get_check_payload4(payload, weight_factors)
        elif len(payload)==5:
            return self.get_check_payload5(payload, weight_factors)
        else:
            raise ValueError

    def get_check_payload4(self, payload, weight_factors):
        '''
        Check digit for 4-digit payload
        https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf section 7.9.3
        '''
        assert BaseRandomWeightParser.is_valid_code(payload, 4)
        sum_digit_after_factor = 0
        for digit_idx, digit in enumerate(payload):
            sum_digit_after_factor += WEIGHT_FACTORS[weight_factors[digit_idx]][int(digit)]
        sum_times_3 = sum_digit_after_factor * 3
        return str(sum_times_3 % 10)

    def get_check_payload5(self, payload, weight_factors):
        '''
        Check digit for 5-digit payload
        https://www.gs1.org/docs/barcodes/GS1_General_Specifications.pdf section 7.9.4
        '''
        assert BaseRandomWeightParser.is_valid_code(payload, 5)
        sum_digit_after_factor = 0
        for digit_idx, digit in enumerate(payload):
            sum_digit_after_factor += WEIGHT_FACTORS[weight_factors[digit_idx]][int(digit)]
        rnd_up_tens = int(ceil(sum_digit_after_factor / 10.0)) * 10
        remaining = rnd_up_tens - sum_digit_after_factor
        check_digit = self.inv_map_payload[remaining]
        return str(check_digit)
    
    def decode(self, barcode, code_info):
        # Checks
        assert BaseRandomWeightParser.is_valid_code(barcode, CODE_SIZE)
        assert self.get(barcode, 'prefix') in self.vald_code_prefix
        assert BaseRandomWeightParser.get_check_GTIN13(barcode[:-1])==self.get(barcode, 'check_digit')
        payload = self.get(barcode, 'payload', code_info=code_info)
        assert self.get_check_payload(payload, code_info['weight_factors'])==self.get(barcode, 'payload_check_digit', code_info=code_info)
        # Values
        product_code = self.get(barcode, 'prod_code', code_info)
        amount = BaseRandomWeightParser.payload_to_float(payload, code_info['payload_frac_size'])

        return product_code, amount

    def encode(self, product_code, payload, code_info):
        # Checks
        assert BaseRandomWeightParser.is_valid_code(code_info['prefix'], self.prefix_len)
        assert code_info['prefix'] in self.vald_code_prefix
        assert BaseRandomWeightParser.is_valid_code(product_code, code_info['prod_code_len'])
        assert isinstance(payload, float) and 0 < payload < pow(10, code_info['payload_len'] - code_info['payload_frac_size'])

        digits_prefix = code_info['prefix']
        digits_prod_code = product_code
        digits_payload = BaseRandomWeightParser.payload_to_str(payload, code_info['payload_frac_size'], code_info['payload_len'])
        digit_check_payload = self.get_check_payload(digits_payload, code_info['weight_factors'])

        digits1_12 = digits_prefix + digits_prod_code + digit_check_payload + digits_payload
        digit13 = BaseRandomWeightParser.get_check_GTIN13(digits1_12)
        return digits1_12 + digit13

if __name__=='__main__':
    my_parser = GS1RandomWeightParser(('27', '10', '21', '22', '23'))
    # Single test
    ean13barcode = '1012340101001' #'0112345010108'  # 13 digits barcode
    codes = {'27':dict(prefix='27', type='price_embedded', prod_code_len=4, payload_len=5, payload_frac_size=2, weight_factors=DEFAULT_PAYLOAD_FACTORS['5']), # Aldi
             '10':dict(prefix='10', type='price_embedded', prod_code_len=4, payload_len=5, payload_frac_size=3, weight_factors=DEFAULT_PAYLOAD_FACTORS['5']), # Sample
             '21':dict(prefix='21', type='price_embedded', prod_code_len=4, payload_len=5, payload_frac_size=2, weight_factors=DEFAULT_PAYLOAD_FACTORS['5']), # Jumbo
             '22':dict(prefix='22', type='price_embedded', prod_code_len=4, payload_len=5, payload_frac_size=2, weight_factors=DEFAULT_PAYLOAD_FACTORS['5']), # Jumbo
             '23':dict(prefix='23', type='price_embedded', prod_code_len=5, payload_len=4, payload_frac_size=2, weight_factors=DEFAULT_PAYLOAD_FACTORS['4']), # Jumbo
             }
    prod_code, amount = my_parser.decode(ean13barcode, codes['10'])
    barcode_encoded = my_parser.encode(prod_code, amount, codes['10'])
    assert ean13barcode==barcode_encoded
    import random
    import string
    import cv2
    for i in range(10000):
        option = codes[random.choice(list(codes.keys()))]
        product_code = ''.join(random.choice(string.digits) for _ in range(option['prod_code_len']))
        payload = random.random() * (10 ** (option['payload_len'] - option['payload_frac_size']))

        barcode = my_parser.encode(product_code, payload, option)
        cv2.imshow('Decoded barcode', BaseRandomWeightParser.visualize(barcode))
        cv2.waitKey(1)
        prod_code, amount = my_parser.decode(barcode, option)
        print ("encode: prefix: {}, prod_code {}, payload: {}, decode: {}".format(option['prefix'],product_code,payload, barcode))

        payload_check = abs(amount-payload)<0.01 if option['payload_frac_size']==2 else abs(amount-payload)<0.001
        check = payload_check and product_code==prod_code
        if not check:
            import ipdb; ipdb.set_trace()