from cart_blocks.random_weight.GS1_parser import GS1RandomWeightParser
from cart_blocks.random_weight.setup1_parser import Setup1RandomWeightParser

class BaseRWParser(object):
    def __init__(self, catalog, codes, parser_logic='default'):
        self.get_parser_logic(parser_logic)
        self.register_codes(codes)
        self.parser_logic = parser_logic
        self.barcode_parser = self.parser(self.valid_prefix)
        self.catalog = catalog
    
    def get_parser_logic(self, parser_logic):
        if parser_logic=='default':
            self.parser = GS1RandomWeightParser
        elif parser_logic=='setup1':
            self.parser = Setup1RandomWeightParser
    
    def register_codes(self, codes):
        assert isinstance(codes, dict)
        self.codes = dict()
        self.valid_prefix = []
        for code_prefix, cd in codes.items():
            self.codes[code_prefix] = self.parser.check_code(code_prefix, cd)
            self.valid_prefix.append(code_prefix)
    
    def is_random_weight(self, barcode):
        # Make sure barcode has valid prefix
        if self.get_rw_barcode_type(barcode) is None:
            return False
        # Check if barcode has a legal structure
        if not self.is_legal_rw_bc(barcode):
            return False
        prefix = self.barcode_parser.get(barcode, 'prefix')
        code_info = self.codes[prefix]
        # Query partial code in catalog
        if self.barcode_parser.include_prefix_in_query:
            query_size = len(prefix) + code_info['prod_code_len']
            partial_code = barcode[:query_size]
        else:
            query_size = code_info['prod_code_len']
            partial_code = barcode[len(prefix):query_size + len(prefix)]
        product_code = self.catalog.query_prod_code_with_partial_barcode(partial_code)
        return product_code is not None

    def is_barcode_product(self, barcode):
        pass

    def encode(self, code_prefix, product_code, payload):
        return self.barcode_parser.encode(product_code, payload, self.codes[code_prefix])

    def get_rw_barcode_type(self, barcode):
        prefix = self.barcode_parser.get(barcode, 'prefix')
        if prefix in self.valid_prefix:
            return self.codes[prefix]['type']
        return None
    
    def is_legal_rw_bc(self, barcode):
        prefix = self.barcode_parser.get(barcode, 'prefix')
        code_info = self.codes[prefix]
        try:
            _, __ = self.barcode_parser.decode(barcode, code_info)
        except:
            return False
        return True

    def get_item_info(self, barcode):
        if not len(barcode)==self.barcode_parser.expected_bc_len():
            return None
        if not self.is_random_weight(barcode):
            return None
         # TODO - is query always done with prefix?
        prefix = self.barcode_parser.get(barcode, 'prefix')
        code_info = self.codes[prefix]
        # query_size = len(prefix) + code_info['prod_code_len']
        if self.barcode_parser.include_prefix_in_query:
            query_size = len(prefix) + code_info['prod_code_len']
            partial_code = barcode[:query_size]
        else:
            query_size = code_info['prod_code_len']
            partial_code = barcode[len(prefix):query_size + len(prefix)]
        barcode_type = code_info['type']
        if barcode_type is None:
            return None
        if barcode_type=='price_embedded':
            # Price-Embedded barcode.
            # 1. Get product code & price from barcode
            short_code, price = self.barcode_parser.decode(barcode, code_info)
            # 2. partial barcode -> product code
            product_code = self.catalog.query_prod_code_with_partial_barcode(partial_code)
            # 3. Query catalog for price per weight unit, extract weight
            # Note - price=price per. weight unit
            product_info = self.catalog.query_prod_info_with_product_code(product_code)
            weight = price / (product_info['price'] + 1e-6) # TODO -remove when prices are set
        elif barcode_type=='weight_embedded':
            # Price-Embedded barcode.
            # 1. Get product code & weight from barcode
            short_code, weight = self.barcode_parser.decode(barcode, code_info)
            # 2. partial barcode -> product code
            product_code = self.catalog.query_prod_code_with_partial_barcode(partial_code)
            # 3. Query catalog for price per weight unit, extract price
            # Note - price=price per. weight unit
            product_info = self.catalog.query_prod_info_with_product_code(product_code)
            price = weight * product_info['price']
            self.catalog.update_single_product(product_code)
        
        return dict(product_code=product_code,
                    price=price,
                    weight=weight,
                    name=self.catalog.get_default_language_product_name(product_code))

if __name__=='__main__':
    from cart_blocks.catalog import Catalog
    my_catalog = Catalog()
    codes = {'27':dict(type='price_embedded', prod_code_len=4, payload_len=5, payload_frac_size=2), # Aldi
             '21':dict(type='price_embedded', prod_code_len=4, payload_len=5, payload_frac_size=2), # Jumbo
             '22':dict(type='price_embedded', prod_code_len=4, payload_len=5, payload_frac_size=2), # Jumbo
             '23':dict(type='price_embedded', prod_code_len=5, payload_len=4, payload_frac_size=2), # Jumbo
             }
    my_parser = BaseRWParser(my_catalog, codes)
    # Test invalid code with good prefix
    invalid_bc = my_parser.encode('27', '9999', 0.01)
    invalid_bc = my_parser.encode('23', '12345', 46.57)
    is_rw = my_parser.is_random_weight(invalid_bc)
    valid_bc = '2707302059139'
    print(my_parser.get_item_info(valid_bc))
