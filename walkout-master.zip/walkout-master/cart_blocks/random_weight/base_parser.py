from math import ceil, modf

class BaseRandomWeightParser(object):
    """
    Base Object of parsing Random Weight barcodes
    """
    def __init__(self):
        raise NotImplementedError
    
    @staticmethod
    def is_valid_code(code, seq_size):
        return isinstance(code,str) and code.isdigit() and len(code)==seq_size
    
    def decode(self, barcode):
        raise NotImplementedError

    def encode(self, product_code, payload):
        raise NotImplementedError

    def expected_bc_len(self):
        raise NotImplementedError

    @staticmethod
    def get_check_GTIN13(bits1_12):
        # https://www.gs1.org/services/how-calculate-check-digit-manually
            assert BaseRandomWeightParser.is_valid_code(bits1_12, 12)
            odd_sum = sum(int(x) for x in bits1_12[0::2])
            even_sum = sum(int(x) for x in bits1_12[1::2])
            a = 3*even_sum+1*odd_sum
            rnd_up_tens = int(ceil(a / 10.0)) * 10
            check_digit = str(rnd_up_tens - a)
            return check_digit
    
    def payload_to_float(payload, fraction_len):
        ret = float(payload[:-fraction_len] + '.' + payload[-fraction_len:])
        return ret
    
    def payload_to_str(payload, fraction_len, total_size):
        num_align = int(payload * (10 ** fraction_len))
        str_align = str(num_align)
        frac_str = (str_align[-fraction_len:]).zfill(fraction_len)
        int_str = (str_align[:-fraction_len]).zfill(total_size - fraction_len)
        return int_str+frac_str

    @staticmethod
    def visualize(barcode):
        import treepoem
        import numpy as np
        import cv2
        barcode_img = treepoem.generate_barcode('ean13', barcode)
        barcode_img = np.array(barcode_img)[:, :, ::-1]
        barcode_txt = 255 * np.ones((40, barcode_img.shape[1], 3), dtype=np.uint8)
        cv2.putText(barcode_txt, barcode, (10, 20), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (0, 0, 0), 1)
        return np.vstack((barcode_img, barcode_txt))