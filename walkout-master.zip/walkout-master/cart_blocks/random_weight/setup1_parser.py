from cart_blocks.random_weight.base_parser import BaseRandomWeightParser
from cart_blocks.random_weight.GS1_parser import GS1RandomWeightParser
from math import ceil, pow

CODE_SIZE = 13
NUM_CHECK_DIGITS = 1
DEFAULT_PREFIX_LEN = 1
DEFAULT_PROD_CODE_LEN = 6
DEFAULT_PAYLOAD_LEN = 5

class Setup1RandomWeightParser(GS1RandomWeightParser):
    """
    Parsing Random Weight barcodes with 1 digit prefix, no payload verification
    """
    def __init__(self, vald_code_prefix,
                 n_check_digits=NUM_CHECK_DIGITS,
                 prefix_len=DEFAULT_PREFIX_LEN,
                 include_prefix_in_query=False,
                 ):
        self.vald_code_prefix = vald_code_prefix
        self.n_check_digits = n_check_digits
        self.prefix_len = prefix_len
        self.include_prefix_in_query = include_prefix_in_query
    
    @staticmethod
    def check_code(code_prefix, cd):
        assert isinstance(code_prefix, str) and len(code_prefix)==DEFAULT_PREFIX_LEN
        reg = dict(prefix=code_prefix)
        assert 'type' in cd and cd['type'] in ('price_embedded', 'weight_embedded')
        reg['type'] = cd['type']
        assert 'prod_code_len' in cd and isinstance(cd['prod_code_len'], int)
        reg['prod_code_len'] = cd['prod_code_len']
        assert 'payload_len' in cd and isinstance(cd['payload_len'], int)
        reg['payload_len'] = cd['payload_len']
        assert 'payload_frac_size' in cd and isinstance(cd['payload_frac_size'], int) and \
            cd['payload_frac_size'] < cd['payload_len']
        reg['payload_frac_size'] = cd['payload_frac_size']
        
        assert len(code_prefix) + reg['prod_code_len'] + reg['payload_len'] + NUM_CHECK_DIGITS == CODE_SIZE
        return reg

    def expected_bc_len(self):
        return CODE_SIZE
    
    def get(self, barcode, part, code_info=None):
        assert part in ('prefix', 'prod_code', 'payload', 'check_digit')
        if part=='prefix':
            return barcode[:self.prefix_len]
        if part=='check_digit':
            return barcode[-1]
        assert code_info is not None
        if part=='prod_code':
            return barcode[self.prefix_len:code_info['prod_code_len'] + self.prefix_len]
        elif part=='payload':
            return barcode[-code_info['payload_len'] -1:-1]
        elif part=='payload_check_digit':
            return barcode[code_info['prod_code_len'] + self.prefix_len]
    
    def get_check_payload(self, payload, weight_factors):
        raise NameError

    
    def decode(self, barcode, code_info):
        # Checks
        assert BaseRandomWeightParser.is_valid_code(barcode, CODE_SIZE)
        assert self.get(barcode, 'prefix') in self.vald_code_prefix
        assert BaseRandomWeightParser.get_check_GTIN13(barcode[:-1])==self.get(barcode, 'check_digit')
        payload = self.get(barcode, 'payload', code_info=code_info)
        # Values
        product_code = self.get(barcode, 'prod_code', code_info)
        amount = BaseRandomWeightParser.payload_to_float(payload, code_info['payload_frac_size'])

        return product_code, amount

    def encode(self, product_code, payload, code_info):
        # Checks
        assert BaseRandomWeightParser.is_valid_code(code_info['prefix'], self.prefix_len)
        assert code_info['prefix'] in self.vald_code_prefix
        assert BaseRandomWeightParser.is_valid_code(product_code, code_info['prod_code_len'])
        assert isinstance(payload, float) and 0 < payload < pow(10, code_info['payload_len'] - code_info['payload_frac_size'])

        digits_prefix = code_info['prefix']
        digits_prod_code = product_code
        digits_payload = BaseRandomWeightParser.payload_to_str(payload, code_info['payload_frac_size'], code_info['payload_len'])

        digits1_12 = digits_prefix + digits_prod_code + digits_payload
        digit13 = BaseRandomWeightParser.get_check_GTIN13(digits1_12)
        return digits1_12 + digit13

if __name__=='__main__':
    my_parser = Setup1RandomWeightParser(('2', ))
    # Single test
    ean13barcode = '2321374017141' #'0112345010108'  # 13 digits barcode
    codes = {'2':dict(prefix='2', type='price_embedded', prod_code_len=6, payload_len=5, payload_frac_size=2), # Tiv-Taam
             }
    prod_code, amount = my_parser.decode(ean13barcode, codes['2'])
    barcode_encoded = my_parser.encode(prod_code, amount, codes['2'])
    assert ean13barcode==barcode_encoded
    import random
    import string
    import cv2
    for i in range(10000):
        option = codes[random.choice(list(codes.keys()))]
        product_code = ''.join(random.choice(string.digits) for _ in range(option['prod_code_len']))
        payload = random.random() * (10 ** (option['payload_len'] - option['payload_frac_size']))

        barcode = my_parser.encode(product_code, payload, option)
        cv2.imshow('Decoded barcode', BaseRandomWeightParser.visualize(barcode))
        cv2.waitKey(1)
        prod_code, amount = my_parser.decode(barcode, option)
        print ("encode: prefix: {}, prod_code {}, payload: {}, decode: {}".format(option['prefix'],product_code,payload, barcode))

        payload_check = abs(amount-payload)<0.01 if option['payload_frac_size']==2 else abs(amount-payload)<0.001
        check = payload_check and product_code==prod_code
        if not check:
            import ipdb; ipdb.set_trace()