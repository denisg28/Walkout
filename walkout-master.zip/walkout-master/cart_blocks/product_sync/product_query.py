
class ProductQueryHandler(object):
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.max_event_req = config.get('max_event_req', 20)
            self.min_test_events = config.get('min_test_events', 1)
            self.est_valid_img_in_event = config.get('est_valid_img_in_event', 10)
            self.train_img_ratio = config.get('train_img_ratio', 0.8)
            self.est_valid_img_in_event = config.get('est_valid_img_in_event', 10)
            self.min_train_img_per_sku = config.get('min_train_img_per_sku', 500)
            self.ave_train_img_per_sku = config.get('ave_train_img_per_sku', 1000)
            self.max_train_img_per_sku = config.get('max_train_img_per_sku', 1500)
            self.min_similar_prod_confusion = config.get('min_similar_prod_confusion', 0.08)
            self.fine_grained_err_penalty = config.get('fine_grained_err_penalty', 5)
            self.regular_err_penalty = config.get('regular_err_penalty', 10)
            self.constant_n_events = config.get('constant_n_events', None)

    def __init__(self, product_classifier, gui, pqh_config=dict()):
        print('Initializing Product Query', flush=True)
        self.params = self.Config(pqh_config)
        self.product_classifier = product_classifier
        self.gui = gui
        self.valid_classifier = hasattr(product_classifier, 'img_count_info') and \
            hasattr(product_classifier, 'sku_accuracy_info')
        if self.params.constant_n_events is not None:
            self.valid_classifier = True # Overwrite
        if not self.valid_classifier:
            print('ProductQueryHandler Debug: Insufficient classifier info, ignoring', flush=True)
        self.debug = False

    def analyze_product_query(self, product_info):
        if self.debug:
            print('ProductQueryHandler Debug: Recieved message:', product_info, flush=True)
        if not self.valid_classifier or 'msg_type' not in product_info \
            or product_info['msg_type']!='sync_query' or 'product_code' not in product_info:
            if self.debug:
                print('ProductQueryHandler Debug: Ignoring due to illegal format:', flush=True)
            return
        if 'prediction_data' not in product_info or \
            not isinstance(product_info['prediction_data'], (list, tuple)) or \
            len(product_info['prediction_data']) < self.params.min_test_events:
            if self.debug:
                print('ProductQueryHandler Debug: Ignoring due to illegal prediction:', flush=True)
            return
        # Return constant number of events if configured
        # ==============================================
        if self.params.constant_n_events is not None:
            msg_payload = dict(msg_type='sync_response',
                            product_code=product_info['product_code'],
                            event_request=int(self.params.constant_n_events),
                            is_classifier_supported=True,
                            )
            msg = dict(cmd='product_sync', payload=msg_payload)
            if self.debug:
                print('ProductQueryHandler Debug: Sending message:', msg, flush=True)

            if self.gui is not None:
                self.gui.send(msg)
            return

        # Get product info from classifier
        # ===============================
        prod_imgs_info = self.product_classifier.img_count_info.get(product_info['product_code'], None)
        prod_acc_info = self.product_classifier.sku_accuracy_info.get(product_info['product_code'], None)
        prod_confusion_info = self.product_classifier.confusion_matrix.get(product_info['product_code'], None)

        if prod_imgs_info is not None:
            is_supported = True
            # Calculate number of missing images
            # ==================================
            train_img_2_event_factor = self.params.est_valid_img_in_event * self.params.train_img_ratio
            imgs_needed_min_count = max(0, self.params.min_train_img_per_sku - int(prod_imgs_info['train']))
            imgs_needed_ave_count = max(0, self.params.ave_train_img_per_sku - int(prod_imgs_info['train']))

            # Analyze Test Event
            # ==================
            total_prediction = dict()
            for single_pred in product_info['prediction_data']:
                for prod_name, score in single_pred.items():
                    if prod_name in total_prediction:
                        total_prediction[prod_name] += score
                    else:
                        total_prediction[prod_name] = score
            total_prediction = {k: v for k, v in sorted(total_prediction.items(), key=lambda item: item[1], reverse=True)}
            top1_prediction = list(total_prediction.keys())[0]
            is_top1_pred = top1_prediction==product_info['product_code']
            is_in_top5_pred = product_info['product_code'] in list(total_prediction.keys())[:5]
            similar_products = [prod_name for prod_name, prob in prod_confusion_info.items() \
                if prob > self.params.min_similar_prod_confusion and prod_name not in (product_info['product_code'], 'aa_hand', 'background')] \
                if prod_confusion_info is not None else []
            is_fine_grained = len(similar_products) > 0

            # Vanilla logic for decision on data events required
            # ==================================================
            num_events_required = 0
            if not is_in_top5_pred:
                num_events_required = self.params.max_event_req
                print('ProductQueryHandler Debug: Product %s not in top-5, Events required: %d' % \
                    (product_info['product_code'], num_events_required), flush=True)
            else:
                if imgs_needed_min_count > 0:
                    num_events_required  = min(imgs_needed_min_count // train_img_2_event_factor, self.params.max_event_req)
                    print('ProductQueryHandler Debug: Product %s has little images, Events required: %d' % \
                        (product_info['product_code'], num_events_required), flush=True)
                elif not is_top1_pred and imgs_needed_min_count> 0:
                    num_events_required  = min(imgs_needed_ave_count // train_img_2_event_factor, self.params.max_event_req)
                    print('ProductQueryHandler Debug: Product %s has not many images and is not top-1, Events required: %d' % \
                        (product_info['product_code'], num_events_required), flush=True)
                elif not is_top1_pred:
                    # Enough images and wrong prediction
                    if is_fine_grained and top1_prediction in similar_products:
                        num_events_required = self.params.fine_grained_err_penalty
                        print('ProductQueryHandler Debug: Product %s is fine-grained and is not top-1, Events required: %d' % \
                            (product_info['product_code'], num_events_required), flush=True)
                    else: 
                        num_events_required = self.params.regular_err_penalty
                        print('ProductQueryHandler Debug: Product %s is not top-1, Events required: %d' % \
                            (product_info['product_code'], num_events_required), flush=True)
                else:
                    num_events_required = 0
                    print('ProductQueryHandler Debug: Product %s is top-1 and has enough images, Events required: %d' % \
                        (product_info['product_code'], num_events_required), flush=True)
        
        else:
            is_supported = False
            num_events_required = self.params.max_event_req
            print('ProductQueryHandler Debug: Product %s has not statistics, Events required: %d' % \
                (product_info['product_code'], num_events_required), flush=True)
        
        # Send message to UI
        # ==================
        msg_payload = dict(msg_type='sync_response',
                           product_code=product_info['product_code'],
                           event_request=num_events_required,
                           is_classifier_supported=is_supported,
                          )
        msg = dict(cmd='product_sync', payload=msg_payload)
        if self.debug:
            print('ProductQueryHandler Debug: Sending message:', msg, flush=True)

        if self.gui is not None:
            self.gui.send(msg)

if __name__=='__main__':
    from cv_blocks.events.event_classifier import EventClassifier

    dummy_gui = None
    model_name='bunting_hands_exp_04_00100_dual_dropout.onnx'
    event_classifier = EventClassifier(None, en_trt=True, sync=False,
                                       model_name=model_name,
                                       use_crop_descriptor=model_name.endswith('dual_dropout.onnx'))
    product_query_handler = ProductQueryHandler(event_classifier.yaaen, dummy_gui)
    example_query = {'cmd':'product_sync',
                     'payload':{'msg_type': 'sync_query',
                               'product_code': '89880',
                               'prediction_data': [{'89880':  20.24, '23244566':  3.6, '22146441_0': 0.22, '22146441_1': 0.22, '22146441_2':  0.22},
                                                   {'89880':  20.24, '23244566':  4.5, '22146441_1': 1.22, '22146441_0': 1.02, '22146441_0':  0.11}]}} 
    example_query = {'cmd':'product_sync',
                     'payload':{'msg_type': 'sync_query',
                               'product_code': '89880',
                               'prediction_data': [{'89880':  2.24, '23244566':  3.6, '22146441_0': 0.22, '22146441_1': 0.22, '22146441_2':  0.22},
                                                   {'89880':  2.24, '23244566':  4.5, '22146441_1': 1.22, '22146441_0': 1.02, '22146441_0':  0.11}]}} 
    product_query_handler.analyze_product_query(example_query['payload'])