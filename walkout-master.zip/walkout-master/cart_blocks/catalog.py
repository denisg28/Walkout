import os
from config import config
import sqlite3
import requests
import time
from cart_blocks.random_weight.base_RW_parser import BaseRWParser

DBBaseURL = "http://localhost:3001/"
LOCAL_DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../webapp/server/database.sqlite3')
CURR_PRODUCT_LIST = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'products.csv')
IGNORED_PRODUCT_NAMES = ('unknown', 'aa_hand', 'low_conf_item')
class Catalog(object):
    def __init__(self, def_language=config.GUI_LANGUAGE, catalog_db_path=LOCAL_DB_PATH, gen_incremental=True,
                 remove_bc_leading_zeros=True, cat_config=dict()):
        self.cat_config = cat_config
        self.default_language = def_language
        self.catalog_db_path = catalog_db_path
        self.gen_incremental = gen_incremental
        self.remove_bc_leading_zeros = remove_bc_leading_zeros
        self.ignore_items = IGNORED_PRODUCT_NAMES
        self.init_db(catalog_db_path)
        if not gen_incremental:
            self.generate_csv_instance()
        # Initialize random weight parser
        if 'rw_parser' in cat_config:
            self.load_random_weight_parser(cat_config['rw_parser'])
         
        try:
            response = requests.get(DBBaseURL)    
            if response.ok:
                print("using REST API for db interactions")
                self.is_valid_product = self.is_valid_product_REST
                self.query_prod_code_with_partial_barcode = self.query_prod_code_with_partial_barcode_REST
                self.query_prod_info_with_product_code = self.query_prod_info_with_product_code_REST
                self.update_single_product = self.update_single_product_REST
                self.update_single_barcode = self.update_single_barcode_REST
            else:
                self.get_product_db_mapping()
                
        except:
            self.get_product_db_mapping()
              

    def load_random_weight_parser(self, rw_config):
        print('\033[93mInitializing Random Weight parser:', rw_config, '\033[00m', flush=True)
        if rw_config['type']=='BaseRWParser':
            parser_logic = rw_config['logic'] if 'logic' in rw_config else 'default'
            self.rw_parser = BaseRWParser(self, rw_config['codes'], parser_logic=parser_logic)
        else:
            raise NameError
    
    def handle_barcode_rw_api_request(self, message):
        assert 'msg_type' in message and message['msg_type']=='request'
        assert 'barcode' in message
        if 'zero_payload' in message:
            assert message['zero_payload']==False # not supporting zero payload at the moment
        # Check if Random weight product
        is_rw_product = False
        if hasattr(self, 'rw_parser'):
            is_rw_product = self.rw_parser.is_random_weight(message['barcode'])
        response_payload = dict(msg_type='response',
                                barcode=message['barcode'],
                                is_rw_product=is_rw_product)
        try:
            if is_rw_product and not message['zero_payload']:
                product_info = self.rw_parser.get_item_info(message['barcode'])
                response_payload['product_code'] = product_info['product_code']
                response_payload['price'] = product_info['price']
                response_payload['weight'] = product_info['weight']
        except:
            # Something went wrong in parsing the barcode(partial, wrong typing, etc.)
            # return empty payload + rw=Flase
            response_payload['is_rw_product'] = False
        return response_payload
        

    def is_valid_barcode(self, barcode):
        # Check if barcode product
        products_with_barcode = self.get_products_with_barcode(barcode)
        if len(products_with_barcode) > 0:
            return True
        # Check if Random weight product
        if hasattr(self, 'rw_parser'):
            return self.rw_parser.is_random_weight(barcode)
        return False

    def is_valid_product(self, prod_code):
        # Check if barcode product
        if prod_code in self.ignore_items:
            return False
        cursor = self.sqliteConnection.cursor()
        cursor.execute("SELECT product_code FROM UPC WHERE product_code=?", (prod_code,))
        query = cursor.fetchone()
        if query is None:
            return False
        return True

        
    def is_valid_product_REST(self, prod_code):
        # Check if barcode product
        if prod_code in self.ignore_items:
            return False
        
        start = time.time()
        response = requests.get(DBBaseURL+"upc/get_upc/"+str(prod_code))
#        print("REST call took %f seconds" % (time.time()-start))
        if (response is None) or (not response.ok):
            return False
        productJson = response.json()
        if 0 == len(productJson):
            return False
        return True

    def get_product_db_mapping(self):
        sqliteConnection = sqlite3.connect(self.catalog_db_path)
        sqliteConnection.text_factory = str
        cursor = sqliteConnection.cursor()
        cursor.execute("PRAGMA table_info (Products)")
        prod_db_map = cursor.fetchall()
        self.prod_info_map = dict()
        for info in prod_db_map:
            self.prod_info_map[info[1]] = info[0]

    def generate_csv_instance(self):
        # Generate product & barcode list for back-compatability purposes
        with open(CURR_PRODUCT_LIST, 'w') as f:
            valid_keys = ('product_name', 'barcode', 'english_name', 'local_name', 'price')
            f.write("%s,%s,%s,%s,%s\n" % valid_keys)
            for _,values in self.product_info.items():
                out_row = tuple([str(values[vk]) for vk in valid_keys])
                f.write("%s,%s,%s,%s,%s\n" % out_row)
    
    def init_db(self, catalog_db_path):
        if not os.path.exists(catalog_db_path) or os.stat(catalog_db_path).st_size == 0 or self.gen_incremental:
            print('Warning - initializing empty catalog')
            self.product_info = dict()
            self.barcode2products = dict()
            self.attribute_dict = dict()
            if self.gen_incremental:
                self.sqliteConnection = sqlite3.connect(catalog_db_path)
                self.sqliteConnection.text_factory = str
                # cursor = self.sqliteConnection.cursor()
        else:
            self.get_product_db_mapping()
            sqliteConnection = sqlite3.connect(catalog_db_path)
            sqliteConnection.text_factory = str
            cursor = sqliteConnection.cursor()
            # Get products
            cursor.execute("SELECT * FROM Products")
            rows = cursor.fetchall()
            assert rows is not None
            self.product_info = dict()
            self.barcode2products = dict()
            self.product_codes = [r[self.prod_info_map['product_code']] for r in rows]
            # Get barcodes
            import tqdm
            for prod_idx, prod_code in enumerate(tqdm.tqdm((self.product_codes))):
                # Get product info
                cursor.execute("SELECT barcode FROM UPC WHERE product_code=?", (prod_code,))
                product_barcode = cursor.fetchone()[0]
                if self.remove_bc_leading_zeros:
                    product_barcode = product_barcode.lstrip("0")
                english_name = rows[prod_idx][self.prod_info_map['en_name']]
                local_name = rows[prod_idx][self.prod_info_map['local_name']]
                price = rows[prod_idx][self.prod_info_map['price']]
                self.product_info[prod_code] = dict(product_name=prod_code,
                                                    barcode=product_barcode,
                                                    english_name=english_name,
                                                    local_name=local_name,
                                                    price=price)
                if product_barcode not in self.barcode2products:
                    self.barcode2products[product_barcode] = [prod_code]
                else:
                    self.barcode2products[product_barcode].append(prod_code)

            # Extra attributes
            self.attribute_dict = dict()
            # TODO - Add size & has_similar product info
            att_keys = ['product_name']
            self.num_products = len(self.product_info)
            for attribute in att_keys:
                # Collect attribute value per product
                self.attribute_dict[attribute] = dict()
                for _, val in self.product_info.items():
                    prod_name = val['product_name']
                    att_val = val[attribute]
                    self.attribute_dict[attribute][prod_name] = att_val
            print('Initialized Product Catalog with %d products' % self.num_products)
    
    def set_attribute(self, att_name, att_dict):
        self.attribute_dict[att_name] = att_dict

    def get_local_name(self,item):
        try:
            return self.product_info[item]['local_name']
        except:
            return item
    
    def query_prod_code_with_partial_barcode(self, partial_barcode):
        cursor = self.sqliteConnection.cursor()
        cursor.execute("SELECT product_code FROM UPC WHERE barcode LIKE ?", (partial_barcode+"%",))
        product_code = cursor.fetchone()
        if product_code is None:
            return None
        return product_code[0]
                
    def query_prod_code_with_partial_barcode_REST(self, partial_barcode):
        start = time.time()
        response = requests.get(DBBaseURL+"upc/get_upc_of_partial_barcode/"+str(partial_barcode))
#        print("REST call took %f seconds" % (time.time()-start))
        if (response is None) or (not response.ok):
            return None
        allProducts = response.json()
        if allProducts is None or len(allProducts)==0:
            return None
        productCode = allProducts[0]
        if 'product_code' not in productCode.keys():
            return None        
        return productCode['product_code']

    def query_prod_info_with_product_code(self, prod_code):
        cursor = self.sqliteConnection.cursor()
        cursor.execute("SELECT * FROM Products WHERE product_code=?", (prod_code,))
        product_row = cursor.fetchone()
        info = {k: product_row[v] for k,v in self.prod_info_map.items()}
        return info

    def query_prod_info_with_product_code_REST(self, prod_code):
        start =time.time()
        response = requests.get(DBBaseURL+"products/get_product/"+str(prod_code))
#        print("REST call took %f seconds" % (time.time()-start))
        if (response is None) or (not response.ok):
            return None
        try:
            data = response.json()['data']
        except:
            data = None
        return data

    def update_single_product(self, single_prod_code):
        if single_prod_code in self.ignore_items:
            return
        cursor = self.sqliteConnection.cursor()
        cursor.execute("SELECT barcode FROM UPC WHERE product_code=?", (single_prod_code,))
        product_barcode = cursor.fetchone()
        if product_barcode is None:
            return
        # Collect all products with same barcode
        cursor.execute("SELECT product_code FROM UPC WHERE barcode=?", (product_barcode[0],))
        product_barcode = product_barcode[0]
        if self.remove_bc_leading_zeros:
            product_barcode = product_barcode.lstrip("0")
        all_proudcts = cursor.fetchall()
        if all_proudcts is None or len(all_proudcts)==0:
            return
        for prod_code in all_proudcts:
            prod_code = prod_code[0]
            cursor.execute("SELECT * FROM Products WHERE product_code=?", (prod_code,))
            product_row = cursor.fetchone()
            if product_row is None:
                return
            english_name = product_row[self.prod_info_map['en_name']]
            local_name = product_row[self.prod_info_map['local_name']]
            price = product_row[self.prod_info_map['price']]
            self.product_info[prod_code] = dict(product_name=prod_code,
                                                barcode=product_barcode,
                                                english_name=english_name,
                                                local_name=local_name,
                                                price=price)
            if product_barcode not in self.barcode2products:
                self.barcode2products[product_barcode] = [prod_code]
            elif prod_code not in self.barcode2products[product_barcode]:
                self.barcode2products[product_barcode].append(prod_code)

    def update_single_product_REST(self, single_prod_code):
        if single_prod_code in self.ignore_items:
            return
        
        start = time.time()
        response = requests.get(DBBaseURL+"upc/get_upc/"+str(single_prod_code))
#        print("REST call took %f seconds" % (time.time()-start))
        if (response is None) or (not response.ok) or (len(response.json()) == 0 ):
            return
        
        product_barcode = response.json()[0]
        start = time.time()
        response = requests.get(DBBaseURL+"upc/get_upc_of_barcode/"+str(product_barcode))
#        print("REST call took %f seconds" % (time.time()-start))
        if (response is None) or (not response.ok):
            return
        allProducts = response.json()
        
        if self.remove_bc_leading_zeros:
            product_barcode = product_barcode.lstrip("0")
        if allProducts is None or len(allProducts)==0:
            return
        
        for prodCode in allProducts:
            prod_code = prodCode['product_code']
            start = time.time()
            response = requests.get(DBBaseURL+"products/get_product/"+str(product_barcode))
#            print("REST call took %f seconds" % (time.time()-start))
            if (response is None) or (not response.ok) or (response.content is None):
                continue
            
            try:
                self.product_info[prod_code] = response.json()
            except Exception as e:
                print("there was some problem reaching the DB: "+str(e))
                pass
            if product_barcode not in self.barcode2products:
                self.barcode2products[product_barcode] = [prod_code]
            elif prod_code not in self.barcode2products[product_barcode]:
                self.barcode2products[product_barcode].append(prod_code)


    def update_single_barcode(self, product_barcode):
        cursor = self.sqliteConnection.cursor()
        cursor.execute("SELECT product_code FROM UPC WHERE barcode=?", (product_barcode,))
        all_proudcts = cursor.fetchall()
        if all_proudcts is None or len(all_proudcts)==0:
            # Try Barcode version without leading zeors
            if product_barcode.startswith("0"):
                product_barcode = product_barcode.lstrip("0")
                cursor.execute("SELECT product_code FROM UPC WHERE barcode=?", (product_barcode,))
                all_proudcts = cursor.fetchall()
                if all_proudcts is None or len(all_proudcts)==0:
                    return
            else:
                return
        for prod_code in all_proudcts:
            prod_code = prod_code[0]
            cursor.execute("SELECT * FROM Products WHERE product_code=?", (prod_code,))
            product_row = cursor.fetchone()
            if product_row is None:
                return
            english_name = product_row[self.prod_info_map['en_name']]
            local_name = product_row[self.prod_info_map['local_name']]
            price = product_row[self.prod_info_map['price']]
            self.product_info[prod_code] = dict(product_name=prod_code,
                                                barcode=product_barcode,
                                                english_name=english_name,
                                                local_name=local_name,
                                                price=price)
            if product_barcode not in self.barcode2products:
                self.barcode2products[product_barcode] = [prod_code]
            elif prod_code not in self.barcode2products[product_barcode]:
                self.barcode2products[product_barcode].append(prod_code)        

    def update_single_barcode_REST(self, product_barcode):
        start = time.time()
        response = requests.get(DBBaseURL+"upc/get_upc_of_barcode/"+str(product_barcode))
#        print("REST call took %f seconds" % (time.time()-start))
        allProducts = response.json()
        if allProducts is None or len(allProducts)==0:
            # Try Barcode version without leading zeors
            if product_barcode.startswith("0"):
                product_barcode = product_barcode.lstrip("0")
                start = time.time()
                response = requests.get(DBBaseURL+"upc/get_upc_of_barcode/"+str(product_barcode))
#                print("REST call took %f seconds" % (time.time()-start))
                allProducts = response.json()
                if allProducts is None or len(allProducts)==0:
                    return
            else:
                return
            
        for prodCode in allProducts:
            prod_code = prodCode['product_code']
            start = time.time()
            response = requests.get(DBBaseURL+"products/get_product/"+str(product_barcode))
#            print("REST call took %f seconds" % (time.time()-start))
            if (response is None) or (not response.ok) or (response.content is None):
                continue
            
            self.product_info[prod_code] = response.json()
            if product_barcode not in self.barcode2products:
                self.barcode2products[product_barcode] = [prod_code]
            elif prod_code not in self.barcode2products[product_barcode]:
                self.barcode2products[product_barcode].append(prod_code)

    def get_english_name(self, item):
        if item not in self.product_info and self.gen_incremental:
            self.update_single_product(item)
        try:
            return self.product_info[item]['english_name']
        except:
            return item

    def get_barcode(self, item):
        if item not in self.product_info and self.gen_incremental:
            self.update_single_product(item)
        try:
            return self.product_info[item]['barcode']
        except:
            return item

    def get_products_with_barcode(self, barcode):
        query_barcode = barcode.lstrip("0") if self.remove_bc_leading_zeros else barcode
        if query_barcode not in self.barcode2products and self.gen_incremental:
            self.update_single_barcode(barcode)
        if query_barcode in self.barcode2products:
            return self.barcode2products[query_barcode]
        else:
            return []

    def has_attribute(self, val):
        # Currently not supported 
        return False

    def get_default_language_product_name(self,item):
        if item not in self.product_info and self.gen_incremental:
            self.update_single_product(item)
        if self.default_language=='English':
            return self.get_english_name(item)
        else:
            return self.get_local_name(item)

    def get_price(self, item):
        if item not in self.product_info and self.gen_incremental:
            self.update_single_product(item)
        try:
            return self.product_info[item]['price']
        except:
            return 0.0

    def get_product_list(self):
        # TODO - remove?
        return None
    
if __name__=='__main__':
    import yaml
    config_data = yaml.load(open('../user_files/production_files/Walkout.yaml', 'r'))
    try:
        cat_config = config_data['ALGO_MODULE_CONFIG']['catalog']
    except:
        cat_config = None
    my_catalog = Catalog(cat_config=cat_config)
    print('Invalid BC', my_catalog.rw_parser.is_random_weight('22115690'))
    print('Valid BC', my_catalog.rw_parser.is_random_weight('2224562002403'))
    
