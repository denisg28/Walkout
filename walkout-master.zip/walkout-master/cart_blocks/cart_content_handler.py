import enum
from cv_blocks.events.event_logic import EventType
from cv_blocks.misc.logger import MarkedEventLogger
from cart_blocks.indications.indication_handler import IndicationHandler
from misc import print_formatted_message
from cart_blocks.location_matching import LocationMatching
from config import config
from md_blocks.barcode.barcode_handler import BarcodeEventState
from md_blocks.barcode.message_parser import BarcodeHandlerEvent
from md_blocks.plu.plu_handler import PLUEventState

# Error types - lower values are more severe errors
class ErrorType(enum.Enum):
    CameraDriverFailure = 0
    ExternalInvalidation = 1
    CamerasOcclusion = 2
    RemovedUnregisteredProduct = 3
    BarocdeEventNonVerified = 4
    WhiteBalanceFailure = 5
    WaitUserResponse = 6

class CartState(enum.Enum):
    Empty = -1
    Valid = 0
    PendingUserInteraction = 1
    DuringBarcodeScan = 2
    UnexplainedRemoval = 3
    InvalidEvent = 4
    InvalidProcess = 5
    InvalidBarcodeEvent = 6
    InvalidPluEvent = 6
    ForceInvalid = 7

class EventApiType(enum.Enum):
    ConfidentEvent = 1
    LowClsConfEvent = 2
    LowDetConfEvent = 3
    InconsistentClsEvent = 4
    BarcodePendingEvent = 5
    BarcodeResolvedEvent = 6
    PluPendingEvent = 7
    PluResolvedEvent = 8
    PluUnresolvedEvent = 9
    UnidentifiedItemEvent = 10
    UnResolvedItemEvent = 11

class EventApiResolve(enum.Enum):
    UserResolveProduct = 7
    UserResolveEventQauntity = 8
    UserResolveTotalQauntity = 9
    UserAnnotateProduct = 10

EventApiDict = dict(ProductConfidentEventFirstValid=EventApiType.ConfidentEvent,
                    ProductConfidentEventSecondValid=EventApiType.ConfidentEvent,
                    # ClassifierNotConfidentEvent=EventApiType.LowClsConfEvent,
                    ClassifierNotConfidentEvent=EventApiType.UnidentifiedItemEvent, # map classifier pop-up to unrecognized
                    # CartBottomOnlyEvent=EventApiType.LowDetConfEvent,
                    CartBottomOnlyEvent=EventApiType.UnidentifiedItemEvent, # map classifier pop-up to unrecognized,
                    # LowConfidenceEvent=EventApiType.LowDetConfEvent,
                    LowConfidenceEvent=EventApiType.UnidentifiedItemEvent, # map classifier pop-up to unrecognized
                    NotConfidentEventTriggerBarcode=EventApiType.BarcodePendingEvent,
                    ProductConfidentBarcodeId=EventApiType.BarcodeResolvedEvent,
                    NotConfidentEventTriggerPlu=EventApiType.PluPendingEvent,
                    ProductConfidentPluId=EventApiType.PluResolvedEvent,
                    NotConfidentEventTriggerUnrecognized=EventApiType.UnidentifiedItemEvent,
                    )

class EventStatus(enum.Enum):
    Valid = 1
    Pending = 2
    Resolved = 3
    Invalid = 4

DEFAULT_IMG_EVENTS = ('ClassifierNotConfidentEvent', 'LowConfidenceEvent', 'NotConfidentEventTriggerBarcode', \
                      'CartBottomOnlyEvent', 'NotConfidentEventTriggerPlu', 'NotConfidentEventTriggerUnrecognized')
class CartContentHandler(object):
    '''
    A module holding current cart state:
    - Products inside cart
    - Products removed from cart
    - Events that require verification
    - Cart Status
    This module is also responsible for sending and recieving infrormation to UI
    '''
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.unknown_item_text = config.get('unknown_item_text', "UNKNOWN")
            self.hand_item_text = config.get('hand_item_text', 'aa_hand')
            self.low_conf_item_text = config.get('low_conf_item_text', 'low_conf_item')
            self.barcode_item_text = config.get('barcode_item_text', 'barcode_item_pending')
            self.plu_item_text = config.get('plu_item_text', 'plu_item_pending')
            self.personal_item_text = config.get('personal_item_text', 'personal_item')
            self.unrecognized_item_text = config.get('unrecognized_item_text', 'unrecognized_pending')
            self.enable_sound = config.get('enable_sound', True)
            self.enable_led = config.get('enable_led', True)
            self.events_with_ui_image = config.get('events_with_ui_image', DEFAULT_IMG_EVENTS)
            self.send_ui_errors = config.get('send_ui_errors', True)
            self.use_location_matching = config.get('use_location_matching', True)
            self.indicate_barcode_scan = config.get('indicate_barcode_scan', False)

    def __init__(self, product_catalog, gui, debug=False, cch_config=dict(), md_module=None, logger=None):
        print('Initializing Cart Content Handler', flush=True)
        self.params = self.Config(cch_config)
        self.product_catalog = product_catalog
        self.gui = gui
        self.cart_content = dict()
        self.events = dict()
        self.pending_shop_events = []
        self.active_barcode_events = dict(user=dict(), internal=dict())
        self.active_plu_events = dict(user=dict(), internal=dict())
        self.illegal_shop_events = []
        self.unexplained_removal_events = []
        self.cart_state = CartState.Empty
        if self.gui is not None and (self.params.enable_led or self.params.enable_sound):
            self.indication_handler = IndicationHandler(enable_sound=self.params.enable_sound,
                                                        enable_led=self.params.enable_led)
        self.debug = debug
        self.initialize_error_state()
        self.indicate_valid_cart()
        self.md_module = md_module
        if self.params.use_location_matching:
            self.location_matching = LocationMatching(md_module)
        self.logger = logger
    
    def __del__(self):
        if hasattr(self, 'indication_handler'):
            self.indication_handler.make_cart_led_blue(make_sound=False)

    
    def initialize_error_state(self):
        self.error_state = dict()
        for err_type in ErrorType:
            self.error_state[err_type.name] = dict(active=False, indication_sent=dict(), event_ids=[])
    
    def add_error(self, err_type, event_id=-1, custom_err_msg=None):
        self.error_state[err_type.name]['active'] = True
        self.error_state[err_type.name]['indication_sent'][event_id] = False
        new_event = event_id not in self.error_state[err_type.name]['event_ids']
        if new_event:
            self.error_state[err_type.name]['event_ids'].append(event_id)
            err_msg = custom_err_msg if custom_err_msg is not None else err_type.name
            self.log_cart_state('cart_status', event_id, err_msg=err_msg)
        # Update indication to user
        self.update_error_indication(custom_err_msg=custom_err_msg)

    def remove_error(self, err_type, event_id=-1):
        if event_id in self.error_state[err_type.name]['event_ids']:
            event_id_idx = self.error_state[err_type.name]['event_ids'].index(event_id)
            self.error_state[err_type.name]['event_ids'].pop(event_id_idx)
            del self.error_state[err_type.name]['indication_sent'][event_id]
            if len(self.error_state[err_type.name]['event_ids'])==0:
                self.error_state[err_type.name]['active'] = False
            # Update indication to user
            self.update_error_indication(make_sound=False, removed_err=err_type)
    
    def update_error_indication(self, custom_err_msg=None, make_sound=True, removed_err=None):
        # Get most severe error
        curr_err = None
        send_indication = False
        for err_type in ErrorType:
            if self.error_state[err_type.name]['active']:
                curr_err = err_type
                last_event = self.error_state[err_type.name]['event_ids'][-1]
                if not self.error_state[curr_err.name]['indication_sent'][last_event]:
                    self.error_state[curr_err.name]['indication_sent'][last_event] = True
                    send_indication = True
                    break
            # Send indication if removed err is non-active
            if removed_err is not None:
                if err_type==removed_err and not self.error_state[err_type.name]['active']:
                    send_indication = True
        # Send err indication
        if self.gui is not None:
            if curr_err is not None and self.params.send_ui_errors and send_indication:
                err_msg = custom_err_msg if custom_err_msg is not None else curr_err.name
                self.gui.make_cart_led_red(err_msg)
                if hasattr(self, 'indication_handler'):
                    self.indication_handler.make_cart_led_red(make_sound=make_sound)
            elif curr_err is None:
                self.indicate_valid_cart()
    
    def add_barcode_error(self, event_id, err_msg):
        self.add_error(ErrorType.BarocdeEventNonVerified, event_id=event_id, custom_err_msg=err_msg)
    
    def remove_barcode_error(self, event_id):
        self.remove_error(ErrorType.BarocdeEventNonVerified, event_id=event_id)
    
    def error_state_empty(self):
        for err_type in ErrorType:
            if self.error_state[err_type.name]['active']:
                return False
        return True
    
    def reset(self):
        self.cart_content = dict()
        self.events = dict()
        self.pending_shop_events = []
        self.illegal_shop_events = []
        self.unexplained_removal_events = []
        self.cart_state = CartState.Empty
        self.initialize_error_state()
        self.active_barcode_events = dict(user=dict(), internal=dict())
        self.active_plu_events = dict(user=dict(), internal=dict())
        if hasattr(self, 'location_matching'):
            self.location_matching.reset()

    def empty_cart(self):
        self.reset()
        if self.gui is not None:
            self.gui.clear_list()
            self.gui.make_cart_led_green()
    
    def indicate_invalid_removal(self, shop_event):
        item_name = shop_event['product_id']
        try:
            item_name = self.product_catalog.get_english_name(item_name)
        except:
            pass
        if self.gui is not None:
            err = ErrorType.RemovedUnregisteredProduct.name
            self.gui.make_cart_led_red(err)

    def indicate_pending_interaction(self):
        message = ErrorType.WaitUserResponse.name
        if hasattr(self, 'indication_handler'):
            # self.gui.make_cart_led_red(message)
            self.indication_handler.make_cart_led_blue()
    
    def indicate_valid_cart(self):
        if self.gui is not None:
            self.gui.make_cart_led_green()
        if hasattr(self, 'indication_handler'):
            self.indication_handler.make_cart_led_green()

    def indicate_invalid_cart(self):
        if hasattr(self, 'indication_handler'):
            self.indication_handler.make_cart_led_red(make_sound=False)

    def indicate_insert_item(self):
        if hasattr(self, 'indication_handler'):
            self.indication_handler.item_inserted()

    def indicate_remove_item(self):
        if hasattr(self, 'indication_handler'):
            self.indication_handler.item_removed()

    def indicate_barcode_scanned(self):
        if hasattr(self, 'indication_handler') and self.params.indicate_barcode_scan:
            self.indication_handler.scanned_barcode()

    def indicate_early_event(self, direction):
        # TODO - different behavior/sound per direction
        if hasattr(self, 'indication_handler'):
            self.indication_handler.event_detected()
    
    def greenify_cart(self):
        '''
        Force valid indication on cart
        '''
        self.cart_state = CartState.Valid
        self.illegal_shop_events = []
        self.unexplained_removal_events = []
        self.pending_shop_events = []
        self.active_barcode_events = dict(user=dict(), internal=dict())
        self.active_plu_events = dict(user=dict(), internal=dict())
        self.initialize_error_state()
        self.indicate_valid_cart()
        print('CartHandler: Greenify Cart', flush=True)
        self.print_cart_state()
    
    def redify_cart(self):
        '''
        Force valid indication on cart
        '''
        self.cart_state = CartState.ForceInvalid
        self.add_error(ErrorType.ExternalInvalidation)
    
    def yellowfy_cart(self):
        '''
        Move cart to pending state
        '''
        self.cart_state = CartState.PendingUserInteraction
        self.indicate_pending_interaction()

    def count_products(self):
        n_products = 0
        for _, prod in self.cart_content.items():
            n_products += prod['quantity']
        return n_products

    def update_cart(self, shop_event, location_idx=None, indication=True):
        # Check for duplicate events
        event_type = shop_event['event_type'] if 'event_type' in shop_event else 'default'
        if shop_event['direction']=='in':
            prod_id = shop_event['product_id']
            has_prod_events = prod_id in self.cart_content and len(self.cart_content[prod_id]['events']) > 0
            if has_prod_events:
                last_prod_event_id = self.cart_content[prod_id]['events'][-1]
                last_prod_event_type = self.cart_content[prod_id]['event_types'][-1]
                last_prod_event_frame = self.cart_content[prod_id]['frames'][-1]
                if abs(shop_event['frameNum'] - last_prod_event_frame) < 60:
                    if last_prod_event_type=='barcode_marked' and event_type=='default':
                        # Marked event came before real event
                        # Reduce quantity by 1
                        self.cart_content[prod_id]['quantity'] -= 1 # TODO - what if marked event has quantity > 1?
                        # Pop last event and replace with real event
                        self.cart_content[prod_id]['events'].pop(-1)
                        self.cart_content[prod_id]['event_types'].pop(-1)
                        self.cart_content[prod_id]['frames'].pop(-1)
                    elif last_prod_event_type=='default' and event_type=='barcode_marked':
                        # Marked event came after real event - ignore marked event
                        return False


        valid_loc_match = location_idx is not None and hasattr(self, 'location_matching')

        if shop_event['product_id'] in self.cart_content.keys() or valid_loc_match:
            quantity_diff = shop_event['quantity'] if shop_event['direction']=='in' else -shop_event['quantity']
            prod_id = shop_event['product_id'] if location_idx is None or not valid_loc_match else \
                self.location_matching.predictions_history[-1]['prod_ids'][location_idx]
            if prod_id in self.cart_content.keys() or shop_event['direction']=='in':
                self.cart_content[prod_id]['quantity'] += quantity_diff
                self.cart_content[prod_id]['events'].append(shop_event['event_id'])
                self.cart_content[prod_id]['frames'].append(shop_event['frameNum'])
                self.cart_content[prod_id]['event_types'].append(event_type)
                # Set weight of last scanned item if product was matched by location
                if valid_loc_match and 'weight' in self.cart_content[prod_id]:
                    # Get event_id and infer correct weight
                    md_event_id_in = self.location_matching.predictions_history[-1]['event_in_ids'][location_idx]
                    shop_event['weight'] = self.events[md_event_id_in]['weight']
                    # shop_event['weight'] = self.cart_content[prod_id]['weight'] # takes total weight of all products of same id in the cart
                if 'weight' in shop_event and shop_event['weight'] is not None:
                    if 'weight' in self.cart_content[prod_id]:
                        weight_diff = shop_event['weight'] if shop_event['direction']=='in' else -shop_event['weight']
                        self.cart_content[prod_id]['weight'] += weight_diff
            else:
                print("\033[91mWarning - location matching connected current removal event to an illegal event "
                      "(unknown / barcode pending without user interaction)\033[00m", flush=True)
            if shop_event['direction'] == 'out' and valid_loc_match:
                self.location_matching.remove_product(prod_id, location_idx)
        else:
            product_type = shop_event['product_type'] if 'product_type' in shop_event else 'default'
            new_product = dict(product_name=shop_event['product_name'],
                               quantity=shop_event['quantity'],
                               price=shop_event['price'],
                               events=[shop_event['event_id']],
                               frames=[shop_event['frameNum']],
                               event_types=[event_type],
                               product_type=product_type,)
            if 'weight' in shop_event and shop_event['weight'] is not None:
                new_product['weight'] = shop_event['weight']
            self.cart_content[shop_event['product_id']] = new_product
        # Indications
        if indication:
            if shop_event['direction']=='in':
                self.indicate_insert_item()
            else:
                self.indicate_remove_item()
        return True
    
    def update_ui_with_insert_barcode_event(self, event_id, barcode):
        '''
        Bypass to update ui with event
        '''
        if self.gui is not None:
            gui_event = EventApiType.BarcodeResolvedEvent.value
            self.gui.insert_item(name=barcode, itemCount=1,event_ID = event_id, event_type=gui_event,\
                top_products=[(barcode, 1.0)])

    def execute_add_event(self, event_info, event_result):
        event_type, top_products = event_result
        if event_type==EventType.ProductConfidentEventSecondValid:
            # zero first product score, otherwise ui will show first product
            top_products[0][1] = 0.0
        event, shop_event, requires_interaction = self.pack_event(event_info, event_result)
        if not requires_interaction:
            # Confident event - add to cart
            tirgger_indication = event_info['early_indication_idx']<0 if 'early_indication_idx' in event_info \
                and event_info['early_indication_idx'] is not None else True
            self.update_cart(shop_event, indication=tirgger_indication)
        else:
            if (not hasattr(self.md_module, 'stream') or not self.md_module.stream.isRealTime) and not config.SHOW_USER_GUI:
                # In regression mode wo gui - insert interactions to cart list and don't wait for user response
                self.update_cart(shop_event)
            else:
                self.pending_shop_events.append(shop_event)
                self.indicate_pending_interaction()
        self.events[event['id']] = event
        if self.gui is not None:
            skip_gui = event_info.get('skip_gui', False)
            gui_event = EventApiDict[event_type.name].value
            if gui_event!=EventApiType.PluPendingEvent and not skip_gui: # don't send this kind of event
                # Send event image in case event type requires it
                event_image = event_info['event_representative_image'] \
                    if event_type.name in self.params.events_with_ui_image else None
                mark_for_validation = event_info['mark_for_validation'] if 'mark_for_validation' in event_info else False
                self.gui.insert_item(name=event['name'], itemCount=1,event_ID = event['id'], event_type=gui_event,\
                    top_products=top_products, mark_for_validation=mark_for_validation, weight=shop_event['weight'], event_image=event_image,\
                        allow_any_product=gui_event!=EventApiType.UnidentifiedItemEvent.value)

    def execute_remove_event(self, event_info, event_result, location_idx):
        event_type, top_products = event_result
        if event_type==EventType.ProductConfidentEventSecondValid:
            # zero first product score, otherwise ui will show first product
            top_products[0] = (top_products[0][0], 0.0)
        event, shop_event, requires_interaction = self.pack_event(event_info, event_result)
        item_in_cart = self.is_item_in_cart(shop_event)
        # TODO: Check if removal keeps the cart in valid state. otherwise - require interaction
        # Currently it will throw a warning
        if not requires_interaction:
            if item_in_cart or location_idx is not None:
                # Confident event - add to cart
                tirgger_indication = event_info['early_indication_idx']<0 if 'early_indication_idx' in event_info \
                    and event_info['early_indication_idx'] is not None else True
                self.update_cart(shop_event, location_idx=location_idx, indication=tirgger_indication)
            else:
                self.unexplained_removal_events.append(shop_event)
                self.add_error(ErrorType.RemovedUnregisteredProduct, event_id=event['id'])
        else:
            # TODO - how to handle unrecognized event with location matching? yuval.f
            if event_type!=EventType.NotConfidentEventTriggerUnrecognized:
                assert location_idx is None
            self.pending_shop_events.append(shop_event)
            self.indicate_pending_interaction()
        self.events[event['id']] = event
        if self.gui is not None:
            skip_gui = event_info.get('skip_gui', False)
            gui_event = EventApiDict[event_type.name].value
            if gui_event!=EventApiType.PluPendingEvent and not skip_gui: # don't send this kind of event
                # Send event image in case event type requires it
                event_image = event_info['event_representative_image'] \
                    if event_type.name in self.params.events_with_ui_image else None
                mark_for_validation = event_info['mark_for_validation'] if 'mark_for_validation' in event_info else False
                self.gui.remove_item(name=event['name'], itemCount=1,event_ID = event['id'], event_type=gui_event,\
                    top_products=top_products, mark_for_validation=mark_for_validation, weight=shop_event['weight'], event_image=event_image,\
                        allow_any_product=gui_event!=EventApiType.UnidentifiedItemEvent.value)
    
    def is_item_in_cart(self, shop_event):
        product_id = shop_event['product_id']
        return product_id in self.cart_content.keys() and self.cart_content[product_id]['quantity'] > 0

    def register_event(self, cls_seq, seq_result, location_idx):
        # Ignore Algo barcode triggers if needed
        # ======================================
        if hasattr(self.md_module, 'barcode_handler') and self.md_module.barcode_handler.params.ignore_algo_trigger:
            if seq_result[0]==EventType.NotConfidentEventTriggerBarcode:
                seq_result = (EventType.ProductConfidentEventFirstValid, seq_result[1])
        
        if seq_result[0]==EventType.ProductConfidentBarcodeId:
            # Remove barcode pending event
            self.remove_barcode_pending_event(cls_seq)
        assert cls_seq['event_direction'] in ('in', 'out')
        if cls_seq['event_direction']=='in':
            self.execute_add_event(cls_seq, seq_result)
        else:
            self.execute_remove_event(cls_seq, seq_result, location_idx)

        # Update cart state & reflect to UI
        self.update_cart_state()

    def pack_event(self, event_info, event_result):
        event_type, top_products = event_result
        ui_event = EventApiDict[event_type.name]
        requires_interaction = ui_event in (EventApiType.LowClsConfEvent, EventApiType.LowDetConfEvent, \
             EventApiType.BarcodePendingEvent, EventApiType.PluPendingEvent, EventApiType.UnidentifiedItemEvent)
        event_status = EventStatus.Pending if requires_interaction else EventStatus.Valid
        product_id, product_name, price, weight = self.query_catalog(event_type, top_products)
        if event_info['event_direction'] == 'in' and hasattr(self, 'location_matching'):
            self.location_matching.add_product(event_info, product_id, top_products,
                                               pending_unrecognized=ui_event in (EventApiType.BarcodePendingEvent,
                                                                                 EventApiType.PluPendingEvent,
                                                                                 EventApiType.UnidentifiedItemEvent))
        event = {
            'name': product_id,
            'alias': product_name,
            'direction': event_info['event_direction'],
            'frameNum': event_info['event_frame'],
            'eventStart': event_info['event_start'],
            'topProb': top_products,
            'id': event_info['event_id'],
            'front_id': event_info['front_id'],
            'back_id': event_info['back_id'],
            'status': event_status,
            'weight': weight,
        }
        shop_event = dict(product_id=product_id,
                          product_name=product_name,
                          direction=event_info['event_direction'],
                          event_id=event_info['event_id'],
                          frameNum=event_info['event_frame'],
                          price=price,
                          weight=weight,
                          quantity=1)
        return event, shop_event, requires_interaction
    
    def query_catalog(self, event_type, top_products):
        if event_type==EventType.ProductConfidentBarcodeId:
            # Check if product barcode accosiated with random weight
            if hasattr(self.product_catalog, 'rw_parser'):
                prod_barcode = top_products[0][0]
                if self.product_catalog.rw_parser.is_random_weight(prod_barcode):
                    product_info = self.product_catalog.rw_parser.get_item_info(prod_barcode)
                    return product_info['product_code'], product_info['name'], product_info['price'], product_info['weight']
            # Else, fall-back to regular flow
            product_id = top_products[0][0]
            product_name = self.product_catalog.get_default_language_product_name(product_id)
            price = self.product_catalog.get_price(product_id)
        elif event_type==EventType.ProductConfidentEventFirstValid:
            product_id = top_products[0][0]
            product_name = self.product_catalog.get_default_language_product_name(product_id)
            price = self.product_catalog.get_price(product_id)
        elif event_type==EventType.ProductConfidentEventSecondValid:
            product_id = top_products[1][0]
            product_name = self.product_catalog.get_default_language_product_name(product_id)
            price = self.product_catalog.get_price(product_id)
        elif event_type==EventType.ClassifierNotConfidentEvent:
            product_id, product_name, price = (self.params.unrecognized_item_text, self.params.unrecognized_item_text, 0.0)
        elif event_type in (EventType.LowConfidenceEvent, EventType.CartBottomOnlyEvent):
            product_id, product_name, price = (self.params.unrecognized_item_text, self.params.unrecognized_item_text, 0.0)
        elif event_type==EventType.NotConfidentEventTriggerBarcode:
            product_id, product_name, price = (self.params.barcode_item_text, self.params.barcode_item_text, 0.0)
        elif event_type==EventType.NotConfidentEventTriggerPlu:
            product_id, product_name, price = (self.params.plu_item_text, self.params.plu_item_text, 0.0)
        elif event_type==EventType.NotConfidentEventTriggerUnrecognized:
            product_id, product_name, price = (self.params.unrecognized_item_text, self.params.unrecognized_item_text, 0.0)
        else:
            raise NameError
        return product_id, product_name, price, None
    
    def resolve_event(self, resolve_data):
        '''
        Update cart state with indications recieved from the user
        example payload accepted:{'event_ID': 27, 'itemCount': -1, 'event_type': 7, 'product': '7290013145857'}
        '''
        resolved_event_id = resolve_data['event_ID']
        if resolved_event_id not in self.events.keys():
            print('CartHandler Debug: Warning - trying to resolve non-existing event id: %d.Ignoring' % resolved_event_id, flush=True)
            return

        if resolve_data['event_type']==EventApiResolve.UserAnnotateProduct.value:
            # log to capsule
            if self.logger is not None and self.logger.should_log('user_marked_event'):
                self.logger.log(MarkedEventLogger.pack(resolved_event_id, 'EventAnnotated', metadata=dict(resolution=resolve_data['product'])), 'user_marked_event')
            return

        unexplained_event_idx = [idx for idx,ev in enumerate(self.unexplained_removal_events) if resolved_event_id==ev['event_id']]
        if len(unexplained_event_idx) > 0:
            print('CartHandler Debug: Warning - trying to resolve unexplained remove: %d.Ignoring' % resolved_event_id, flush=True)
            return

        if self.debug:
            print('CartHandler Debug: Resolving Event:', resolve_data, flush=True)

        if resolve_data['event_type']==EventApiResolve.UserResolveProduct.value:
            # Update location matching with product resolution
            if self.events[resolved_event_id]['direction']=='in' and hasattr(self, 'location_matching'):
                self.location_matching.resolve_interaction(resolve_data['product'], resolved_event_id)
            # if event was sent as "unrecognized" - redicrect it to correct flow
            shop_event_idx = [idx for idx,ev in enumerate(self.pending_shop_events) if resolved_event_id==ev['event_id']]
            # Ignore if event id is not a pending event (maybe it was removed by other process)
            if len(shop_event_idx)!=1:
                print('CartHandler Debug: Warning - trying to resolve non-pending event id: %d.Ignoring' % resolved_event_id, flush=True)
                return
            shop_event_idx = shop_event_idx[0]
            if self.events[resolved_event_id]['name']==self.params.unrecognized_item_text and \
                resolve_data['product'] in (self.params.barcode_item_text, self.params.plu_item_text, self.params.personal_item_text):
                # Change unrecognized to correct event type
                self.pending_shop_events[shop_event_idx]['product_id'] = resolve_data['product']
                if resolve_data['product']==self.params.barcode_item_text:
                    self.events[resolved_event_id]['name'] = self.params.barcode_item_text
                    self.md_module.event_logic.special_item_handler.redirect(resolved_event_id, 'barcode')
                    # Send barcode indication to UI
                    if self.gui is not None:
                        if self.events[resolved_event_id]['direction']=='in':
                            self.gui.insert_item(name=self.params.barcode_item_text, itemCount=1,event_ID=resolved_event_id, \
                                event_type=EventApiType.BarcodePendingEvent.value, top_products=self.events[resolved_event_id]['topProb'])
                        else:
                            self.gui.remove_item(name=self.params.barcode_item_text, itemCount=1,event_ID=resolved_event_id, \
                                event_type=EventApiType.BarcodePendingEvent.value, top_products=self.events[resolved_event_id]['topProb'])
                elif resolve_data['product']==self.params.plu_item_text:
                    self.events[resolved_event_id]['name'] = self.params.plu_item_text
                    self.md_module.event_logic.special_item_handler.redirect(resolved_event_id, 'plu')
                elif resolve_data['product']==self.params.personal_item_text:
                    self.events[resolved_event_id]['name'] = self.params.personal_item_text
                    # Remove personal item from pending items
                    # TODO - should we manage list of personal items?
                    self.pending_shop_events.pop(shop_event_idx)
                # log to capsule
                if self.logger is not None and self.logger.should_log('user_marked_event'):
                    self.logger.log(MarkedEventLogger.pack(resolved_event_id, 'EventRedirected', metadata=dict(resolution=resolve_data['product'])), 'user_marked_event')
            else:
                self.events[resolved_event_id]['status'] = EventStatus.Resolved
                self.events[resolved_event_id]['name'] = resolve_data['product']
                # Close active barcode event, if exists
                if hasattr(self.md_module, 'barcode_handler'):
                    if self.md_module.barcode_handler.get_resolved_event_id()==resolved_event_id:
                        internal_close = {'cmd':'barcode_event_info',
                                          'payload': {'msg_type': 'close_event_request',
                                                      'event_ID': resolved_event_id,
                                                      'reason': 'done'}}
                        self.md_module.barcode_handler.write_message(internal_close)
                # Remove shop event from pending events and add to cart content
                shop_event = self.pending_shop_events.pop(shop_event_idx)
                if resolve_data['product'] not in (None, ''):
                    shop_event['product_id'] = resolve_data['product']
                    shop_event['product_name'] = self.product_catalog.get_default_language_product_name(shop_event['product_id'])
                    item_in_cart = self.is_item_in_cart(shop_event)
                    if item_in_cart or self.events[resolved_event_id]['direction']=='in':
                        # Valid event - add to cart
                        self.update_cart(shop_event)
                    else:
                        self.unexplained_removal_events.append(shop_event)
                        if self.events[resolved_event_id]['direction']=='out' and not item_in_cart:
                            self.add_error(ErrorType.RemovedUnregisteredProduct, event_id=resolved_event_id)
                    # log to capsule
                    if self.logger is not None and self.logger.should_log('user_marked_event'):
                        self.logger.log(MarkedEventLogger.pack(resolved_event_id, 'EventResolved', metadata=dict(resolution=resolve_data['product'])), 'user_marked_event')
                else:
                    #interaction didn't return a valid response
                    # TODO - move to interaction not resolved section
                    pass
        elif resolve_data['event_type'] in (EventApiResolve.UserResolveEventQauntity.value, EventApiResolve.UserResolveTotalQauntity.value):
            # TODO - split between 2 types of events
            if resolved_event_id in self.events:
                assert self.events[resolved_event_id]['name'] not in (self.params.unrecognized_item_text, self.params.barcode_item_text, self.params.plu_item_text, self.params.personal_item_text)
            if resolve_data['product'] not in (None, '') and resolve_data['product'] in self.cart_content:
                # Update the quantity in the cart
                prv_quantity = self.cart_content[resolve_data['product']]['quantity']
                self.cart_content[resolve_data['product']]['quantity'] = resolve_data['quantity']
                # Approximate last event quantity in some cases
                if self.events[resolved_event_id]['direction']=='in' and resolve_data['quantity'] > prv_quantity:
                    self.events[resolved_event_id]['quantity'] = resolve_data['quantity'] - prv_quantity + 1
                elif self.events[resolved_event_id]['direction']=='out' and resolve_data['quantity'] < prv_quantity:
                    self.events[resolved_event_id]['quantity'] = prv_quantity - resolve_data['quantity'] + 1
                # Mark event as multiple quantity
                if 'quantity' in self.events[resolved_event_id]:
                    event_quantity = self.events[resolved_event_id]['quantity']
                    if event_quantity > 1:
                        if self.logger is not None and self.logger.should_log('user_marked_event'):
                            self.logger.log(MarkedEventLogger.pack(resolved_event_id, 'QuantityChange', metadata=dict(quantity=event_quantity)), 'user_marked_event')
        
        # Update cart state & reflect to UI
        self.update_cart_state()
    
    def remove_barcode_pending_event(self, event_info):
        # Remove shop event from pending events and add to cart content
        barcode_pending_event_idx = [idx for idx,ev in enumerate(self.pending_shop_events) \
            if event_info['event_direction']==ev['direction'] and ev['product_id']==self.params.barcode_item_text and \
                event_info['barcode_resolve_event_id']==ev['event_id']]
        if len(barcode_pending_event_idx)==1:
            self.pending_shop_events.pop(barcode_pending_event_idx[0])

    def invalidate_event(self, event_info):
        # Move shop event from pending events to invalid events
        barcode_pending_event_idx = [idx for idx,ev in enumerate(self.pending_shop_events) \
            if event_info['event_direction']==ev['direction'] and ev['product_id']==self.params.barcode_item_text and \
                event_info['event_id']==ev['event_id']]
        if len(barcode_pending_event_idx)==1:
            shop_event = self.pending_shop_events.pop(barcode_pending_event_idx[0])
            self.illegal_shop_events.append(shop_event)
        # Send event to UI
        if self.gui is not None:
            top_prob = [(self.params.unknown_item_text, 1.0)]
            gui_event = EventApiType.ConfidentEvent.value #TODO - better event type
            if event_info['event_direction']=='in':
                self.gui.insert_item(name=self.params.unknown_item_text, itemCount=1,event_ID = event_info['event_id'], event_type=gui_event,\
                    top_products=top_prob, mark_for_validation=True)
            else:
                self.gui.remove_item(name=self.params.unknown_item_text, itemCount=1,event_ID = event_info['event_id'], event_type=gui_event,\
                    top_products=top_prob, mark_for_validation=True)
    
    def send_event_overflow_message(self):
        if self.gui is not None:
            self.gui.events_queue_overflow()
    
    def send_cart_content(self):
        if self.gui is not None:
            self.gui.cart_content_sync(self.cart_content)

    def update_cart_state(self):
        '''
        Run checks that will indicate cart state
        '''
        if self.cart_state == CartState.ForceInvalid:
            return
        num_illeagal_events = len(self.illegal_shop_events)
        num_unexplained_removals = len(self.unexplained_removal_events)
        num_pending_events = len(self.pending_shop_events)
        num_unresolved_barcode_events = len([ev for ev_type in ('user', 'internal') \
            for ev in self.active_barcode_events[ev_type].values() if ev['closed']==True])
        num_unresolved_plu_events = len([ev for ev_type in ('user', 'internal') \
            for ev in self.active_plu_events[ev_type].values() if ev['closed']==True])
        if num_illeagal_events > 0:
             self.cart_state = CartState.InvalidEvent
             self.indicate_invalid_cart()
        elif num_unresolved_barcode_events > 0:
             self.cart_state = CartState.InvalidBarcodeEvent
             self.indicate_invalid_cart()
        elif num_unresolved_plu_events > 0:
             self.cart_state = CartState.InvalidPluEvent
             self.indicate_invalid_cart()
        elif not self.error_state_empty():
             self.cart_state = CartState.InvalidProcess
             self.indicate_invalid_cart()
        elif num_pending_events > 0:
            self.cart_state = CartState.PendingUserInteraction
        elif num_unexplained_removals > 0:
            self.cart_state = CartState.UnexplainedRemoval
            self.indicate_invalid_cart()
        else:
            self.indicate_valid_cart()
            self.cart_state = CartState.Valid
        
        self.print_cart_state()
    
    def print_cart_state(self):
        num_illeagal_events = len(self.illegal_shop_events)
        num_unexplained_removals = len(self.unexplained_removal_events)
        num_pending_events = len(self.pending_shop_events)
        num_products = self.count_products()
        print('CartHandler Update: Cart state:', self.cart_state, 'Product in cart: %d, Illegal:%d, Pending:%d, Unexplained remove:%d' \
            % (num_products, num_illeagal_events, num_pending_events, num_unexplained_removals), flush=True)
        if self.debug:
            print('CartHandler Debug: Cart Content:', self.cart_content, flush=True)
            print('CartHandler Debug: Barcode Events:', self.active_barcode_events, flush=True)
            print('CartHandler Debug: PLU Events:', self.active_plu_events, flush=True)
            print('CartHandler Debug: Error State:', self.error_state, flush=True)
    
    def n_barcode_events(self):
        n_events = 0
        for _, bc_data in self.active_barcode_events.items():
            n_events += len(bc_data)
        return n_events
    
    def init_barcode_event_state(self, event_id, event_type, direction, state):
        if event_type=='user_scan':
            event_type = 'user'
        assert event_id not in self.active_barcode_events[event_type]
        assert state in (BarcodeEventState.PendingOutside, BarcodeEventState.PendingInside)
        self.active_barcode_events[event_type][event_id] = dict(state=state, direction=direction, closed=False)
    
    def close_barcode_event(self, event_id, event_type, err_msg, valid_close):
        if event_type=='user_scan':
            event_type = 'user'
        if event_id not in self.active_barcode_events[event_type]:
            return
        if self.debug:
            print('CartHandler DEBUG: Closing barcode event. event_id: %d, event_type: %s, valid: %r' % \
                (event_id, event_type, valid_close))
        # Find pending shop event
        shop_event_idx = [idx for idx,ev in enumerate(self.pending_shop_events) if event_id==ev['event_id']]
        if len(shop_event_idx)==1 or event_type=='user':
            shop_event = None if event_type=='user' else self.pending_shop_events.pop(shop_event_idx[0])
            # Illegal barcode state - set state as invalid
            self.active_barcode_events[event_type][event_id]['closed'] = True
            if valid_close:
                del self.active_barcode_events[event_type][event_id]
                self.remove_error(ErrorType.BarocdeEventNonVerified, event_id=event_id)
            elif self.active_barcode_events[event_type][event_id]['state']==BarcodeEventState.PendingInside:
                assert self.active_barcode_events[event_type][event_id]['direction']=='in'
                # self.add_error(ErrorType.BarocdeEventNonVerified, event_id=event_id, custom_err_msg=err_msg)
                # if self.gui is not None:
                #     top_prob = [(self.params.unknown_item_text, 1.0)]
                #     self.gui.insert_item(name=self.params.unknown_item_text, itemCount=1,event_ID = event_id, \
                #         event_type=EventApiType.UnResolvedItemEvent.value,\
                #         top_products=top_prob, mark_for_validation=True)
                if shop_event is not None:
                    self.illegal_shop_events.append(shop_event)
            elif self.active_barcode_events[event_type][event_id]['state']==BarcodeEventState.ScannedPendingOutside and \
                self.active_barcode_events[event_type][event_id]['direction']=='in':
                # self.add_error(ErrorType.BarocdeEventNonVerified, event_id=event_id, custom_err_msg=err_msg)
                if shop_event is not None:
                    self.illegal_shop_events.append(shop_event)
            elif self.active_barcode_events[event_type][event_id]['direction']=='out':
                assert shop_event is not None
                # if self.gui is not None:
                #     top_prob = [(self.params.unknown_item_text, 1.0)]
                #     self.gui.remove_item(name=self.params.unknown_item_text, itemCount=1,event_ID = event_id, \
                #         event_type=EventApiType.UnResolvedItemEvent.value,\
                #         top_products=top_prob, mark_for_validation=True)
                self.unexplained_removal_events.append(shop_event)
            self.update_cart_state()
    
    def update_barcode_event_state(self, event_id, event_type, state, barcode=None, product_code=None, send_ui=True):
        if event_type=='user_scan':
            event_type = 'user'
        if event_id not in self.active_barcode_events[event_type]:
            return
        event_direction = self.active_barcode_events[event_type][event_id]['direction']
        self.active_barcode_events[event_type][event_id]['state'] = state
        if state==BarcodeEventState.ScannedPendingOutside:
            self.active_barcode_events[event_type][event_id]['barcode'] = barcode
            if product_code is not None:
                self.active_barcode_events[event_type][event_id]['product_code'] = product_code
            assert barcode is not None
            if send_ui:
                self.md_module.barcode_handler.send_message(BarcodeHandlerEvent.BarcodeScanned)
            self.indicate_barcode_scanned()
        elif state==BarcodeEventState.PendingOutside and event_type=='internal':
            if send_ui:
                self.md_module.barcode_handler.send_message(BarcodeHandlerEvent.ProductRemoved)
        elif state==BarcodeEventState.VerifiedOutside:
            assert event_direction=='out'
            # Update cart content handler with barcode resolution
            if 'product_code' in self.active_barcode_events[event_type][event_id] and \
                self.active_barcode_events[event_type][event_id]['product_code'] is not None:
                product = self.active_barcode_events[event_type][event_id]['product_code']
            else:
                barcode = self.active_barcode_events[event_type][event_id]['barcode']
                # Query product name
                prod_names = self.product_catalog.get_products_with_barcode(barcode)
                # Note - in this case we select the a random product with the same barcode
                product = prod_names[0] if len(prod_names) > 0 else barcode
            resolve_msg = dict(event_ID=event_id,
                                itemCount=-1,
                                event_type=EventApiResolve.UserResolveProduct.value,
                                product=product)
            self.resolve_event(resolve_msg)
            # Send UI close event with product id according to barcode
            if self.gui is not None:
                top_prob = [(product, 1.0)]
                product_id, _ , _ , weight = self.query_catalog(EventType.ProductConfidentBarcodeId, top_prob)
                # TODO - update cart content event with resolved product code
                self.gui.remove_item(name=product_id, itemCount=1,event_ID = event_id, \
                    event_type=EventApiType.BarcodeResolvedEvent.value,\
                    top_products=top_prob, weight=weight)
            # post-update of product name in MD product list
            for ev in reversed(self.md_module.purchaseList):
                if ev['id']==event_id:
                    ev['name'] = product
                    break
        elif state==BarcodeEventState.VerifiedInsideMarked:
            assert event_direction=='in'
            # Update cart content handler with barcode resolution
            if 'product_code' in self.active_barcode_events[event_type][event_id] and \
                self.active_barcode_events[event_type][event_id]['product_code'] is not None:
                product = self.active_barcode_events[event_type][event_id]['product_code']
            else:
                barcode = self.active_barcode_events[event_type][event_id]['barcode']
                # Query product name
                prod_names = self.product_catalog.get_products_with_barcode(barcode)
                # Note - in this case we select the a random product with the same barcode
                product = prod_names[0] if len(prod_names) > 0 else barcode
            # Update cart
            product_name = self.product_catalog.get_default_language_product_name(product)
            price = self.product_catalog.get_price(product)
            top_prob = [(product, 1.0)]
            product_id, _ , _ , weight = self.query_catalog(EventType.ProductConfidentBarcodeId, top_prob)
            shop_event = dict(product_id=product_id,
                    product_name=product_name,
                    direction=event_direction,
                    event_id=None, # Can be None if event wasn't recognized by MD
                    frameNum=self.md_module.global_frame_num,
                    price=price,
                    weight=weight,
                    event_type='barcode_marked',
                    quantity=1)
            registered_event = self.update_cart(shop_event, indication=False)
            # Send UI close event with product id according to barcode
            if self.gui is not None and registered_event:
                # TODO - update cart content event with resolved product code
                self.gui.insert_item(name=product_id, itemCount=1,event_ID = event_id, \
                    event_type=EventApiType.BarcodeResolvedEvent.value,\
                    top_products=top_prob, weight=weight)
            # post-update of product name in MD product list
            for ev in reversed(self.md_module.purchaseList):
                if ev['id']==event_id:
                    ev['name'] = product
                    break
        
        # Remove resolved events
        if state in (BarcodeEventState.VerifiedInside, BarcodeEventState.VerifiedOutside, BarcodeEventState.VerifiedInsideMarked):
            del self.active_barcode_events[event_type][event_id]

    def init_plu_event_state(self, event_id, event_type, direction, state):
        assert event_id not in self.active_plu_events[event_type]
        assert state in (PLUEventState.PendingOutside, PLUEventState.PendingInside)
        self.active_plu_events[event_type][event_id] = dict(state=state, direction=direction, closed=False, md_event_id=None, products=[])
        if event_type=='internal':
            # In internal trigger, event_id==md_event_id
            self.active_plu_events[event_type][event_id]['md_event_id'] = event_id


    def update_plu_event_state(self, event_id, event_type, state, products=None, md_event_id=None):
        assert event_id in self.active_plu_events[event_type]
        self.active_plu_events[event_type][event_id]['state'] = state
        if products is not None:
            self.active_plu_events[event_type][event_id]['products'] = products
        if md_event_id is not None:
            self.active_plu_events[event_type][event_id]['md_event_id'] = md_event_id
    
    def close_plu_event(self, event_id, event_type, valid_close, force_products=False):
        # TODO - send all events if valid / send unknown if invalid
        assert event_id in self.active_plu_events[event_type]
        if self.debug:
            print('CartHandler DEBUG: Closing PLU event. event_id: %d, event_type: %s, valid: %r' % \
                (event_id, event_type, valid_close))
        plu_event = self.active_plu_events[event_type][event_id]
        # Find pending shop event
        md_event_id = self.active_plu_events[event_type][event_id]['md_event_id']
        top_preds = None
        if md_event_id is None:
            # A PLU event that MD didn't recognize
            shop_event = dict(direction=self.active_plu_events[event_type][event_id]['direction'],
                              event_id=event_id)
        else:
            shop_event_idx = [idx for idx,ev in enumerate(self.pending_shop_events) if md_event_id==ev['event_id']]
            # Debug case. TODO - remove
            try:
                assert len(shop_event_idx)==1
            except:
                print(shop_event_idx, flush=True)
                print(self.pending_shop_events, flush=True)
                raise ValueError
            shop_event = self.pending_shop_events.pop(shop_event_idx[0])
            # Update products of md event
            self.events[md_event_id]['name'] = [pp['product_code'] for pp in plu_event['products']]
            top_preds = self.events[md_event_id]['topProb']
        # Valid close when item is inside - add products
        for plu_prod in plu_event['products']:
            # Print shopping event message to log
            data = dict(event_type='shopping', event_id=-1 if md_event_id is None else md_event_id,
                        event_payload=dict(direction=shop_event['direction'],
                                        prediction=plu_prod['product_code'],
                                        top_5_products='plu_resolved',
                                        acceptance_test=config.ACCEPTANCE_TEST,
                                        )
                        )
            if self.gui is not None:
                data['event_payload']['event_type'] = EventApiType.PluResolvedEvent.value
            print_formatted_message(data, bold=False)

            # Update single product
            product_name = self.product_catalog.get_default_language_product_name(plu_prod['product_code'])
            price = self.product_catalog.get_price(plu_prod['product_code'])

            plu_shop_event = dict(product_id=plu_prod['product_code'],
                                    product_name=product_name,
                                    direction=shop_event['direction'],
                                    frameNum=shop_event.get('frameNum', self.md_module.global_frame_num),
                                    event_id=md_event_id, # Can be None if event wasn't recognized by MD
                                    price=price,
                                    quantity=plu_prod['quantity'],
                                    product_type='plu')
            self.update_cart(plu_shop_event, indication=False)

            # Validate plu item with classifier
            valid_visual_cls = True
            if top_preds is not None:
                prod_visual_class = self.md_module.event_classifier.get_visual_class(plu_prod['product_code'])
                if len(prod_visual_class) > 0:
                    top_score = top_preds[0][1]
                    top_pred_cls = [pr[0] for pr in top_preds if pr[1]>top_score/4]
                    pred_intersection = list(set(top_pred_cls) & set(prod_visual_class))
                    valid_visual_cls = len(pred_intersection) > 0
            # Send to UI
            if self.gui is not None:
                mark_for_validation = not valid_visual_cls
                gui_event = EventApiType.PluResolvedEvent.value
                if shop_event['direction']=='in':
                    self.gui.insert_item(name=plu_prod['product_code'], itemCount=plu_prod['quantity'],event_ID = shop_event['event_id'], event_type=gui_event,\
                        top_products=[(plu_prod['product_code'], 1.0)], mark_for_validation=mark_for_validation)
                else:
                    self.gui.remove_item(name=plu_prod['product_code'], itemCount=plu_prod['quantity'],event_ID = shop_event['event_id'], event_type=gui_event,\
                        top_products=[(plu_prod['product_code'], 1.0)], mark_for_validation=mark_for_validation)

        self.active_plu_events[event_type][event_id]['closed'] = True
        if valid_close:
            del self.active_plu_events[event_type][event_id]
        else:
            if self.gui is not None:
                top_prob = [(self.params.unknown_item_text, 1.0)]
                if shop_event['direction']=='in':
                    self.gui.insert_item(name=self.params.unknown_item_text, itemCount=1,event_ID = event_id, \
                        event_type=EventApiType.UnResolvedItemEvent.value,\
                        top_products=top_prob, mark_for_validation=True)
                else:
                    self.gui.remove_item(name=self.params.unknown_item_text, itemCount=1,event_ID = event_id, \
                        event_type=EventApiType.UnResolvedItemEvent.value,\
                        top_products=top_prob, mark_for_validation=True)
        
        # TODO - Add invalid close

        self.update_cart_state()
    
    def gather_product_of_type_in_cart(self, product_type):
        products = dict()
        for prod_id, prod_data in self.cart_content.items():
            if prod_data['product_type']==product_type and prod_data['quantity'] > 0:
                products[prod_id] = prod_data['quantity']
        return products


    def log_cart_state(self, event_type, event_id=-1, err_msg=None):
        cart_status = 'valid' if self.cart_state in (CartState.Empty, CartState.Valid) else 'invalid'
        if err_msg is None:
            err_msg = ''
            for err_type in ErrorType:
                if self.error_state[err_type.name]['active']:
                    err_msg = err_type.name
                    break
        data = dict(event_type=event_type,
                    event_id=event_id,
                    event_payload=dict(status=cart_status,
                                       reason=err_msg,
                                    )
        )
        print_formatted_message(data)
    
    def get_state(self):
        ret_dict = dict()
        for k, val in vars(self).items():
            if k in ('gui', 'indication_handler', 'params', 'md_module', 'debug', 'product_catalog'):
                continue
            elif k=='location_matching':
                ret_dict[k] = val.get_state()
            else:
                ret_dict[k] = val
        
        return ret_dict
    
    def set_state(self, state):
        for k, val in state.items():
            if k=='location_matching' and hasattr(self, 'location_matching'):
                self.location_matching.set_state(val)
            elif k in ('debug', 'product_catalog'):
                continue
            else:
                setattr(self, k, val)