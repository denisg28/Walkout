import subprocess
import re

VERBOSE = 1

class CardNotFoundException(Exception):
    """Base class for other exceptions"""
    pass

class SoundDriver(object):

    def __init__(self,card_name = None):
        """
        initiate an ubutu driver to control different playback devices
        :param card_name: the name of audio card (or part of it) as it is shown in terminal command 'aplay -l'
        """
        self.card_num =  self._get_card_number(card_name)
        self.knobs = self._get_playback_knobs()


    def _get_card_number(self,card_name,verbose=VERBOSE):
        result = subprocess.run(['/usr/bin/aplay','-l'], stdout=subprocess.PIPE)

        exception = CardNotFoundException("no audio card with name {} found. use terminal command 'aplay -l' in order to choose card".format(card_name))

        if card_name==None:
            print("provide audio card name")
            [print(line) for line in str(result.stdout).split('\\n')]
            raise exception
        # extract card#, name
        matched_lines = [line for line in str(result.stdout).split('\\n') if card_name in line]
        if len(matched_lines)==0:
            raise exception
        m = re.match(r'card ([0-9]+):(.*), device ([0-9]+):(.*)', matched_lines[0])

        card_num = int(m.group(1))
        card_full_name = m.group(2)
        device_num = m.group(3)
        if verbose:
            print('card#: {}, card name: {}, device# {}'.format(card_num, card_full_name, device_num))

        return card_num

    def _get_playback_knobs(self,verbose=VERBOSE):
        result = subprocess.run(['/usr/bin/amixer','--card',str(self.card_num),'scontrols'], stdout=subprocess.PIPE)
        knobs = []
        lines = str(result.stdout).split('\\n')
        for line in lines:
            m = re.match(r'.*\'(.*)\'.*', line)
            if m is not None:
                knobs.append(m.group(1))
        if verbose:
            print("knobs to tune volume:",knobs)
        return knobs

    def set_volume(self,value,knob=None,verbose=VERBOSE):
        if value>100 or value<0:
            raise NameError('volume value should be set to 0%-100%')
        if knob==None:
             if 'Master' in self.knobs: #knob "Master" is prefered
                 knob = 'Master'
             elif len(self.knobs)==1: #only single knob exits and it will be used
                 knob = self.knobs[0]
             else:
                 raise NameError('many volume knobs exists, add knob variable, knobs: {}'.format(self.knobs))

        if knob in self.knobs:
            if verbose:
                print('setting {} to {}%'.format(knob,value))
                print(['/usr/bin/amixer', '--card', str(self.card_num), 'set', knob, str(int(value)) + '%'])

            subprocess.run(['/usr/bin/amixer', '--card', str(self.card_num), 'set',knob, str(int(value)) + '%'], stdout=subprocess.PIPE)
        else:
            raise NameError("control knob {} not exits in knob list for card {} : {}".format(knob,self.card_num,self.knobs))




if __name__=="__main__":
    # sd = SoundDriver()
    sd = SoundDriver()
    # sd._get_playback_knobs()
    sd.set_volume(100)#will try to tune Master knob or single knob
    # sd.set_volume(70,knob='Master')
    # sd.set_volume(100,knob='Headphone')
    # sd.set_volume(40,knob='Speaker')

