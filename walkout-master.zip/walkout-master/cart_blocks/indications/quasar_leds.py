from sysfs.gpio import Controller, OUTPUT
from enum import Enum
import time
from multiprocessing import Process

GPIO1 = 298 #pin8 - quasar header
GPIO2 = 480 #pin9 - quasar header
GPIO3 = 486 #pin10 - quasar header

class COLORS(Enum):
    RED = 0
    GREEN = 1
    BLUE = 2

class QuasarLeds(object):

    def __init__(self):
        Controller.available_pins = [GPIO1, GPIO2, GPIO3]
        self.red = self.allocate_pin(GPIO1, OUTPUT)
        self.green = self.allocate_pin(GPIO2, OUTPUT)
        self.blue = self.allocate_pin(GPIO3, OUTPUT)

        self.led_list = [self.red,self.green,self.blue]
        self.current_color = None


    def set_led_on(self,color = None):
        print("color value:{}".format(color))
        if color is not None:
            color_num = color.value
        else:
            color_num = -1
        if color_num not in COLORS._value2member_map_:
            print("not setting color")
            self.set_led_off()
            self.current_color = None
        else:
            self.set_led_off()
            pin = self.led_list[color_num] #enum here is critical
            pin.set()
            self.current_color = color
            print("setting color: {} ".format(COLORS(color_num).name))
    
    def flicker(self):
        color = self.current_color if self.current_color is not None else COLORS.BLUE
        p = Process(target=self._flicker_sequence, args=(color, 1, 0.33))
        p.start()

    def _flicker_sequence(self, color, n_repeat, wait_sec):
        for _ in range(n_repeat):
            self.led_list[color.value].reset()
            time.sleep(wait_sec)
            self.led_list[color.value].set()
            time.sleep(wait_sec)

    def set_led_off(self):
        for led in self.led_list:
            led.reset() # set gpio to 0

    def allocate_pin(self,pin, direction):
        try_num = 1
        try:
            ret = Controller.alloc_pin(pin, direction)
        except PermissionError:
            # for some reason need to allocate twice
            print("caught exception")
            try_num += 1
            time.sleep(0.1)  # need to wait after fault
            ret = Controller.alloc_pin(pin, direction)
        print("pin{} - allocation try num {}".format(pin, try_num))
        return ret

if __name__=='__main__':

    leds = QuasarLeds()
    use = "external_user"

    if use == "external_user":
        leds.set_led_off()
        time.sleep(2)
        leds.set_led_on(COLORS.RED)
        time.sleep(2)
        leds.set_led_on(COLORS.GREEN)
        time.sleep(2)
        leds.set_led_on(COLORS.BLUE)
        time.sleep(2)
        leds.set_led_on()
    if use == "internal_user":
        pin = leds.green
        pin.set()
        time.sleep(2)
        pin.reset()
        time.sleep(2)
    print("run ended")
    #    pin.set()   # Sets pin to high logic level
    #    pin.reset() # Sets pin to low logic level
    #    pin.read()  # Reads pin logic level
    #    # Allocate a pin as simple Input signal
    #    pin = Controller.alloc_pin(1, INPUT)
    #    pin.read()  # Reads pin logic level