import os
from multiprocessing import Process
import subprocess as sp
from playsound import playsound
from cv_blocks.misc.aws_download import download_cart_data,find_and_download
from cart_blocks.indications.sound_driver import SoundDriver, CardNotFoundException


class SoundMaker(object):

    def __init__(self, debug=0):
        self.debug = debug
        # Download all requested files
        self.file_names = dict(error='interaction_beep3.mp3',
                               interaction='interaction_beep3.mp3',
                               barcode='barcode_beep3.mp3',
                               insert='insert_beep3.mp3',
                               remove='insert_beep3.mp3',
                               event='insert_beep3.mp3',
                               checkout='insert_beep3.mp3',
        )
        for sound_name in self.file_names.values():
            self._get_file(sound_name)

        self.init_sound_driver()

    def init_sound_driver(self):

        sd = None
        card_options = ["USB2.0","PCH"] #1st is jetson external USB speaker - 2nd is intel PC
        for card_name in card_options:
            if sd is None:
                try:
                    sd = SoundDriver(card_name)
                except CardNotFoundException:
                    pass
        if sd == None:
            raise CardNotFoundException("sound device not found")

        # sd.set_volume(100,knob='PCM') ['/usr/bin/amixer', '--card', '2', 'set', 'PCM', '100']
        sd.set_volume(100)  # ['/usr/bin/amixer', '--card', '2', 'set', 'PCM', '100']

    def make_error_sound(self):
        sound_name = self.file_names['error']
        print("play error sound")
        self._make_sound(sound_name)

    def make_interaction_sound(self):
        sound_name = self.file_names['interaction']
        print("play interaction sound")
        self._make_sound(sound_name)

    def make_barcode_beep(self):
        sound_name = self.file_names['barcode']
        self._make_sound(sound_name)
    
    def make_insert_beep(self):
        sound_name = self.file_names['insert']
        self._make_sound(sound_name)

    def make_remove_beep(self):
        sound_name = self.file_names['remove']
        self._make_sound(sound_name)

    def make_event_beep(self):
        sound_name = self.file_names['event']
        self._make_sound(sound_name)

    def make_checkout_sound(self):
        sound_name = self.file_names['checkout']
        self._make_sound(sound_name)

    def _make_sound(self,sound_name):
        #get/download file
        file_name = self._get_file(sound_name)
        # p = Process(target=self._play_sound, args=(file_name,))
        # p.start()
        self.make_sound_from_file(file_name)


    def make_sound_from_file(self, file_name):
        if self.debug > 0 :
            print("playing sound : {}".format(file_name))
        sp.Popen(["play", file_name], stdout=sp.DEVNULL, stderr=sp.DEVNULL)



    def _play_sound(self,sound_name):
        playsound(sound_name)

    def _get_file(self, sound_name):
        sound_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sound_files')
        os.makedirs(sound_dir, exist_ok=True)
        if not os.path.exists(os.path.join(sound_dir,sound_name)):
            download_cart_data(os.path.join('RND/sounds', sound_name), sound_dir)
            find_and_download(sound_name, 'RND/sounds', sound_dir)
        return os.path.join(sound_dir,sound_name)



if __name__ == '__main__':
    import time
    sndMkr = SoundMaker()
    sndMkr.make_insert_beep()
    time.sleep(1)
    sndMkr.make_error_sound()
    time.sleep(1)
    sndMkr.make_barcode_beep()

    # sndMkr.make_checkout_sound()