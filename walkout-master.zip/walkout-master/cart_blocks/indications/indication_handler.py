import sys

try:
    from cart_blocks.indications.quasar_leds import QuasarLeds,COLORS
except:
    print('no LED driver is initialized')

try:
    from cart_blocks.indications.sound_maker import SoundMaker
except:
    print('no sound effects driver is initialized')

class IndicationHandler(object):

    def __init__(self, enable_sound=True, enable_led=True):
        self.enable_sound = enable_sound
        self.enable_led = enable_led

        if enable_led and 'cart_blocks.indications.quasar_leds' in sys.modules:
            print('Initializing Indication: Leds', flush=True)
            self.leds = QuasarLeds()

        if enable_sound and 'cart_blocks.indications.sound_maker' in sys.modules:
            print('Initializing Indication: Sound', flush=True)
            self.sound = SoundMaker()

    def make_cart_led_red(self, make_sound=True):
        if hasattr(self,"leds"):
            self.leds.set_led_on(COLORS.RED)
        if hasattr(self,"sound") and make_sound:
            self.sound.make_error_sound()

    def make_cart_led_green(self):
        if hasattr(self,"leds"):
            self.leds.set_led_on(COLORS.GREEN)
        # if hasattr(self, "sound"):
        #     self.sound.make_checkout_sound()

    def make_cart_led_blue(self, make_sound=True):
        if hasattr(self,"leds"):
            self.leds.set_led_on(COLORS.BLUE)
        if hasattr(self,"sound") and make_sound:
            self.sound.make_interaction_sound()

    def make_barcode_beep(self):
        if hasattr(self, "sound"):
            self.sound.make_barcode_beep()
    
    def item_inserted(self):
        if hasattr(self, "sound"):
            self.sound.make_insert_beep()

    def item_removed(self):
        if hasattr(self, "sound"):
            self.sound.make_remove_beep()

    def event_detected(self):
        if hasattr(self, "sound"):
            self.sound.make_event_beep()
        if hasattr(self,"leds"):
            self.leds.flicker()

    def scanned_barcode(self):
        if hasattr(self, "sound"):
            self.sound.make_barcode_beep()

    def close_all(self):
        if hasattr(self,"leds"):
            self.leds.set_led_off()


class IndicationController(object):
    '''
    This module is also responsible for activating led & sound indictions
    according to messages sent from UI
    '''
    class Config(object):
        def __init__(self, config):
            assert isinstance(config, dict)
            self.enable_sound = config.get('enable_sound', True)
            self.enable_led = config.get('enable_led', True)

    def __init__(self, ic_config=dict()):
        print('Initializing Indication Controller', flush=True)
        self.params = self.Config(ic_config)
        self.indication_handler = IndicationHandler(enable_sound=self.params.enable_sound,
                                                    enable_led=self.params.enable_led)
        self.debug = True
    
    def execute(self, msg):
        if self.debug:
            print('IndicationController Debug: Recieved message:', msg, flush=True)

        if not (isinstance(msg, dict) and 'indication_type' in msg and \
            'indication_val' in msg):
            return 
        if msg['indication_type']=='led':
            if msg['indication_val']=='green':
                self.indication_handler.make_cart_led_green()
            elif msg['indication_val']=='blue':
                self.indication_handler.make_cart_led_blue(make_sound=False)
            elif msg['indication_val']=='red':
                self.indication_handler.make_cart_led_red(make_sound=False)
        elif msg['indication_type']=='sound':
            if msg['indication_val']=='insert':
                if hasattr(self.indication_handler,"sound"):
                    self.indication_handler.sound.make_insert_beep()
            elif msg['indication_val']=='interaction':
                if hasattr(self.indication_handler,"sound"):
                    self.indication_handler.sound.make_interaction_sound()
            elif msg['indication_val']=='barcode':
                if hasattr(self.indication_handler,"sound"):
                    self.indication_handler.sound.make_barcode_beep()
